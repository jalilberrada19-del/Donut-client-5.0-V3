package dev.donut.client.blockesp;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

/** Original generated block coordinates, never an assertion about the server's current block. */
public record OreMarker(BlockPos pos, Block block) {
    /** Vanilla dimensions whose terrain BlockESP can reconstruct from the seed. */
    public static boolean supports(ResourceKey<Level> dimension) {
        return dimension.equals(Level.OVERWORLD) || dimension.equals(Level.NETHER) || dimension.equals(Level.END);
    }
}
