package dev.donut.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Named configurations people can save, load and share. A share code is the configuration as gzip'd
 * JSON in URL-safe Base64, so it fits in a chat message. Personal data never leaves the computer:
 * staff lists and per-server sound profiles (they contain server addresses), stream progress and the
 * BlockESP world seed are stripped on export and kept as they are on import.
 */
public final class SharedConfigs {
    public static final String CODE_PREFIX = "DONUT-CFG1:";
    public static final int MAX_NAME = 32, MAX_CONFIGS = 100, MAX_CODE_LENGTH = 1_000_000;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Gson COMPACT = new Gson();

    /** A saved configuration file. */
    public record Entry(String name, Path file, long modified, int modulesOn) { }

    private final Path folder;

    public SharedConfigs(Path folder) { this.folder = folder; }

    public Path folder() { return folder; }

    /** Saved configurations, newest first. Unreadable files are skipped. */
    public List<Entry> list() {
        var result = new ArrayList<Entry>();
        if (!Files.isDirectory(folder)) return result;
        try (var files = Files.list(folder)) {
            for (Path file : files.filter(path -> path.getFileName().toString().endsWith(".json")).toList()) {
                try {
                    var json = JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8)).getAsJsonObject();
                    String name = json.has("name") ? json.get("name").getAsString() : stem(file);
                    var config = parse(json.getAsJsonObject("config"));
                    result.add(new Entry(cleanName(name), file, Files.getLastModifiedTime(file).toMillis(), countOn(config)));
                } catch (RuntimeException | IOException ignored) { }
            }
        } catch (IOException ignored) { }
        result.sort(Comparator.comparingLong(Entry::modified).reversed());
        return result;
    }

    /** Saves the current settings under a name, replacing a config with the same name. */
    public Entry save(String name, ClientConfig current) throws IOException {
        String clean = cleanName(name);
        if (clean.isEmpty()) throw new IOException("Give the config a name first.");
        Files.createDirectories(folder);
        Path file = folder.resolve(fileName(clean));
        if (!Files.exists(file) && list().size() >= MAX_CONFIGS) throw new IOException("You already have " + MAX_CONFIGS + " configs.");
        Files.writeString(file, GSON.toJson(envelope(clean, current)), StandardCharsets.UTF_8);
        return new Entry(clean, file, System.currentTimeMillis(), countOn(current));
    }

    public ClientConfig read(Entry entry) throws IOException {
        try {
            var json = JsonParser.parseString(Files.readString(entry.file(), StandardCharsets.UTF_8)).getAsJsonObject();
            return parse(json.getAsJsonObject("config"));
        } catch (RuntimeException error) { throw new IOException("This config file is damaged.", error); }
    }

    public void delete(Entry entry) throws IOException { Files.deleteIfExists(entry.file()); }

    // ---------------------------------------------------------------- share codes

    public static String shareCode(String name, ClientConfig current) {
        byte[] json = COMPACT.toJson(envelope(cleanName(name), current)).getBytes(StandardCharsets.UTF_8);
        var bytes = new ByteArrayOutputStream();
        try (var gzip = new GZIPOutputStream(bytes)) { gzip.write(json); }
        catch (IOException impossible) { throw new IllegalStateException(impossible); }
        return CODE_PREFIX + Base64.getUrlEncoder().withoutPadding().encodeToString(bytes.toByteArray());
    }

    /** A decoded share code: the config's name and its settings. */
    public record Shared(String name, ClientConfig config) { }

    public static Shared decode(String code) throws IOException {
        String text = code == null ? "" : code.trim();
        int start = text.indexOf(CODE_PREFIX);
        if (start < 0) throw new IOException("That is not a Donut config code.");
        text = text.substring(start + CODE_PREFIX.length()).replaceAll("\\s", "");
        if (text.length() > MAX_CODE_LENGTH) throw new IOException("That config code is too long.");
        try {
            byte[] packed = Base64.getUrlDecoder().decode(text);
            String json;
            try (var gzip = new GZIPInputStream(new ByteArrayInputStream(packed))) {
                // Bound the inflated size so a malicious code cannot exhaust memory.
                byte[] data = gzip.readNBytes(4 * 1024 * 1024 + 1);
                if (data.length > 4 * 1024 * 1024) throw new IOException("That config code is too large.");
                json = new String(data, StandardCharsets.UTF_8);
            }
            var envelope = JsonParser.parseString(json).getAsJsonObject();
            String name = envelope.has("name") ? cleanName(envelope.get("name").getAsString()) : "Shared config";
            return new Shared(name.isEmpty() ? "Shared config" : name, parse(envelope.getAsJsonObject("config")));
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException | com.google.gson.JsonParseException error) {
            throw new IOException("That config code is damaged or incomplete.", error);
        }
    }

    // ---------------------------------------------------------------- applying

    /**
     * Copies every setting from {@code source} into {@code target} in place, so modules that hold a
     * reference to their settings object see the change at once. Personal data in {@code target} stays.
     */
    public static void apply(ClientConfig source, ClientConfig target) {
        var keepRosters = target.staffDetector.rosters;
        var keepProfiles = target.soundDetector.profiles;
        int keepStages = target.progressBar.completedStages, keepBases = target.progressBar.basesFound;
        var keepTimers = target.progressBar.timers;
        String keepSeed = target.blockEsp.seed;
        for (Field field : ClientConfig.class.getFields()) {
            if (Modifier.isStatic(field.getModifiers())) continue;
            try {
                Object value = field.get(source);
                Object current = field.get(target);
                if (value == null) continue;
                if (current != null && isSettingsObject(field.getType())) copyFields(value, current);
                else field.set(target, value);
            } catch (IllegalAccessException error) { throw new IllegalStateException(error); }
        }
        target.staffDetector.rosters = keepRosters;
        target.soundDetector.profiles = keepProfiles;
        target.progressBar.completedStages = keepStages;
        target.progressBar.basesFound = keepBases;
        target.progressBar.timers = keepTimers;
        target.blockEsp.seed = keepSeed;
        target.sanitize();
    }

    private static boolean isSettingsObject(Class<?> type) {
        return !type.isPrimitive() && !type.isArray() && type.getName().startsWith("dev.donut.client.config.");
    }

    private static void copyFields(Object source, Object target) throws IllegalAccessException {
        for (Class<?> type = source.getClass(); type != null && type != Object.class; type = type.getSuperclass()) {
            for (Field field : type.getDeclaredFields()) {
                int modifiers = field.getModifiers();
                if (Modifier.isStatic(modifiers) || Modifier.isFinal(modifiers) || Modifier.isTransient(modifiers)) continue;
                field.setAccessible(true);
                field.set(target, field.get(source));
            }
        }
    }

    // ---------------------------------------------------------------- helpers

    private static JsonObject envelope(String name, ClientConfig current) {
        var copy = parse(GSON.toJsonTree(current).getAsJsonObject());
        copy.staffDetector.rosters = new java.util.LinkedHashMap<>();
        copy.soundDetector.profiles = new java.util.LinkedHashMap<>();
        copy.progressBar.completedStages = 0;
        copy.progressBar.basesFound = 0;
        copy.progressBar.timers = new ProgressBarSettings().timers;
        copy.blockEsp.seed = BlockEspSettings.DEFAULT_SEED;
        var json = new JsonObject();
        json.addProperty("format", "donut-config");
        json.addProperty("version", 1);
        json.addProperty("name", name);
        json.add("config", GSON.toJsonTree(copy));
        return json;
    }

    private static ClientConfig parse(JsonObject json) {
        if (json == null) throw new IllegalArgumentException("Missing settings");
        ClientConfig config = GSON.fromJson(json, ClientConfig.class);
        if (config == null) throw new IllegalArgumentException("Missing settings");
        config.sanitize();
        return config;
    }

    /** Number of modules a config turns on. */
    public static int countOn(ClientConfig config) {
        int count = 0;
        for (Field field : ClientConfig.class.getFields()) {
            try {
                Object value = field.get(config);
                if (value == null || !isSettingsObject(field.getType())) continue;
                for (Class<?> type = value.getClass(); type != null && type != Object.class; type = type.getSuperclass()) {
                    try {
                        Field enabled = type.getDeclaredField("enabled");
                        if (enabled.getType() == boolean.class) { enabled.setAccessible(true); if (enabled.getBoolean(value)) count++; }
                        break;
                    } catch (NoSuchFieldException ignored) { }
                }
            } catch (IllegalAccessException ignored) { }
        }
        return count;
    }

    public static String cleanName(String name) {
        if (name == null) return "";
        String clean = name.replaceAll("[\\p{Cntrl}]", "").replaceAll("\\s+", " ").trim();
        return clean.length() > MAX_NAME ? clean.substring(0, MAX_NAME).trim() : clean;
    }

    private static String fileName(String name) {
        String safe = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]+", "-").replaceAll("(^-+|-+$)", "");
        return (safe.isEmpty() ? "config" : safe) + ".json";
    }

    private static String stem(Path file) {
        String name = file.getFileName().toString();
        return name.endsWith(".json") ? name.substring(0, name.length() - 5) : name;
    }
}
