package dev.donut.client.config;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

/**
 * Vanilla 1.21.11 seed prediction preferences. Any block can be a target; the defaults are
 * deepslate coal, deepslate emerald and ancient debris. Keep seeds as text to preserve all 64 bits in JSON.
 */
public final class BlockEspSettings implements BlockTargetList {
    public static final String DEFAULT_SEED = "6608149111735331168";
    public static final int MAX_TARGETS = 64;
    public static final String EMERALD = "minecraft:deepslate_emerald_ore";
    public static final String COAL = "minecraft:deepslate_coal_ore";
    public static final String DEBRIS = "minecraft:ancient_debris";

    public boolean enabled, favorite;
    public String seed = DEFAULT_SEED;
    public boolean tracers, showHud = true, showMined = true;
    public int radius = 4, opacity = 210, minedColor = 0x8A8F98;
    /** Null until first use: older configurations are migrated from the legacy fields below. */
    public List<Target> targets;

    // Pre-5.1 fields, read once for migration and then cleared so they are no longer written.
    public Boolean emerald, coal, debris;
    public Integer emeraldColor, coalColor, debrisColor;

    public static final class Target {
        public String block;
        public boolean enabled = true;
        public int color;

        public Target() { }
        public Target(String block, boolean enabled, int color) {
            this.block = block;
            this.enabled = enabled;
            this.color = color;
        }
    }

    public static long parseSeed(String text) {
        if (text == null || !text.trim().matches("-?[0-9]{1,19}"))
            throw new IllegalArgumentException("Enter a signed 64-bit numeric world seed.");
        try { return Long.parseLong(text.trim()); }
        catch (NumberFormatException error) { throw new IllegalArgumentException("Seed is outside the signed 64-bit range."); }
    }

    /** Lowercases and adds the minecraft namespace when missing. Returns null for malformed IDs. */
    public static String normalize(String id) {
        if (id == null) return null;
        String value = id.trim().toLowerCase(Locale.ROOT);
        if (value.isEmpty()) return null;
        if (!value.contains(":")) value = "minecraft:" + value;
        return value.matches("[a-z0-9_.-]+:[a-z0-9_./-]+") ? value : null;
    }

    /** A pleasant default color for a newly added block, derived from its ID. */
    public static int defaultColor(String id) {
        return switch (id) {
            case EMERALD -> 0x55EE88;
            case COAL -> 0xA7B7CB;
            case DEBRIS -> 0xD08A5C;
            default -> {
                // Hue from the ID, fixed saturation .55 and value .95 (HSV to RGB without AWT).
                double h = (id.hashCode() & 0xFFFF) / 65535.0 * 6, s = .55, v = .95;
                int sector = (int) h % 6;
                double f = h - Math.floor(h), p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
                double[] rgb = switch (sector) { case 0 -> new double[] {v, t, p}; case 1 -> new double[] {q, v, p};
                    case 2 -> new double[] {p, v, t}; case 3 -> new double[] {p, q, v}; case 4 -> new double[] {t, p, v};
                    default -> new double[] {v, p, q}; };
                yield (int) Math.round(rgb[0] * 255) << 16 | (int) Math.round(rgb[1] * 255) << 8 | (int) Math.round(rgb[2] * 255);
            }
        };
    }

    @Override public List<Target> targets() {
        if (targets == null) migrate();
        return targets;
    }

    @Override public void resetTargets() {
        targets = null;
        emerald = coal = debris = null;
        emeraldColor = coalColor = debrisColor = null;
        migrate();
    }

    @Override public Target find(String id) {
        String key = normalize(id);
        for (Target target : targets()) if (target.block.equals(key)) return target;
        return null;
    }

    @Override public boolean isEnabled(String id) {
        Target target = find(id);
        return target != null && target.enabled;
    }

    /** Adds a block target; returns false if the ID is malformed, already present, or the list is full. */
    @Override public boolean addTarget(String id) {
        String key = normalize(id);
        if (key == null || find(key) != null || targets().size() >= MAX_TARGETS) return false;
        targets.add(new Target(key, true, defaultColor(key)));
        return true;
    }

    @Override public void removeTarget(String id) {
        String key = normalize(id);
        targets().removeIf(target -> target.block.equals(key));
    }

    private void migrate() {
        targets = new ArrayList<>();
        targets.add(new Target(COAL, coal == null || coal, coalColor == null ? defaultColor(COAL) : coalColor));
        targets.add(new Target(EMERALD, emerald == null || emerald, emeraldColor == null ? defaultColor(EMERALD) : emeraldColor));
        targets.add(new Target(DEBRIS, debris == null || debris, debrisColor == null ? defaultColor(DEBRIS) : debrisColor));
        emerald = coal = debris = null;
        emeraldColor = coalColor = debrisColor = null;
    }

    public void sanitize() {
        // Preserve invalid input so the module reports it instead of silently predicting a different world.
        if (seed == null) seed = "";
        seed = seed.trim();
        if (seed.length() > 64) seed = seed.substring(0, 64);
        radius = Math.clamp(radius, 1, 16);
        opacity = Math.clamp(opacity, 0, 255);
        minedColor &= 0xFFFFFF;
        if (targets == null) migrate();
        var seen = new HashSet<String>();
        var clean = new ArrayList<Target>();
        for (Target target : targets) {
            if (target == null) continue;
            String key = normalize(target.block);
            if (key == null || !seen.add(key) || clean.size() >= MAX_TARGETS) continue;
            target.block = key;
            target.color &= 0xFFFFFF;
            clean.add(target);
        }
        targets = clean;
        emerald = coal = debris = null;
        emeraldColor = coalColor = debrisColor = null;
    }
}
