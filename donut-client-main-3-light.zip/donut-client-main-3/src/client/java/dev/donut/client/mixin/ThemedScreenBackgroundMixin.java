package dev.donut.client.mixin;

import dev.donut.client.gui.DonutTheme;
import dev.donut.client.gui.ThemedScreen;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Donut sub-screens keep vanilla's blur, then add the midnight wash on top. */
@Mixin(Screen.class)
abstract class ThemedScreenBackgroundMixin {
    @Inject(method = "renderBackground", at = @At("TAIL"))
    private void donut$themedBackground(GuiGraphics graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if ((Object) this instanceof ThemedScreen themed && themed.themedBackground()) {
            var self = (Screen) (Object) this;
            DonutTheme.background(graphics, self.width, self.height);
        }
    }
}
