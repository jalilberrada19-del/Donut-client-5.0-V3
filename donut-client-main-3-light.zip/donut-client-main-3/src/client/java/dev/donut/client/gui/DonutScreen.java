// Workspace presentation adapted from Spectre 26.2 by 4ldenz (GPL-3.0-only).
// Original Donut module integration retains its existing attribution.
package dev.donut.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.donut.client.config.ClientConfig;
import dev.donut.client.config.ProgressBarSettings;
import dev.donut.client.input.ModuleKeybinds;
import dev.donut.client.autobuild.AutoBuilderController;
import dev.donut.client.fly.FlyController;
import dev.donut.client.progress.CountdownDuration;
import dev.donut.client.progress.ProgressTimers;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

import static dev.donut.client.gui.UiPaint.*;
import static dev.donut.client.gui.WorkspacePaint.text;
import static dev.donut.client.gui.WorkspacePaint.strong;
import static dev.donut.client.gui.WorkspacePaint.smallText;
import static dev.donut.client.gui.WorkspacePaint.right;

/** Spectre's workspace presentation, connected to Donut's existing modules and settings. */
public final class DonutScreen extends Screen {
    private int W = 1320, H = 830;
    // Midnight navy palette with a violet accent.
    private static final int TEXT = 0xFFE6E8F5, MUTED = 0xFFA3A8C3, DIM = 0xFF6E7391;
    private static final int PANEL = 0xFF0B0D1A, RAIL = 0xFF0E1022, CARD = 0xFF131630;
    private static final int BORDER = 0xFF262A4A, FIELD = 0xFF0A0C18, BRAND = 0xFF6C5CFF;
    private static final int LIME = 0xFF7D6FFF, SAGE = 0xFF3DD68C;
    private static final int CONTROL = 0xFF161A36, CONTROL_HOVER = 0xFF1E2246;
    private static final int CONTROL_TEXT = 0xFFE6E8F5, CONTROL_MUTED = 0xFF7B80A0;
    private static final int TRACK = 0xFF262A4A;
    private static final int HEADER = 84;
    private int CX = 210, CW = 728, TOP = 273, BOTTOM = 785;
    private static final int CARD_HEADER = 78;
    private int railW, bodyX, bodyW, columns;
    private int detailX, detailW, detailTop, detailBottom, detailContentHeight;
    private double detailScroll, detailScrollTarget, detailProgress;
    private int selectedModule = -1, previewModule = -1, hoveredModule = -1;
    private float fontScale = 1;
    private int lastCategory = 5;
    private double tabIndicator;
    private double layoutUiScale = -1;
    private int appearanceSurface;
    private static final int[] PALETTE = {0x4C86FF, 0x68B4FF, 0x6DDAC5, 0x7EDD8E, 0xCBDC56,
            0xFFC66B, 0xFF975F, 0xFF707B, 0xEC80B5, 0xBA8CFF, 0xC8D1E8, 0xFFFFFF};

    private final ClientConfig config;
    private final Runnable save;
    private final ClickGuiParticles particles = new ClickGuiParticles();
    private final List<Hit> hits = new ArrayList<>();
    private final Map<String, Double> animations = new HashMap<>();
    private double screenProgress, contentProgress, modalProgress;
    private boolean closing;
    private InputConstants.Key openingKey;
    private float scale = 1;
    private float originX, originY;
    private double mouseX, mouseY;
    private int tab = 5;
    private double scroll;
    private double scrollTarget;
    private long lastFrame;
    private double frameSeconds;
    private int contentHeight;
    private String query = "";
    private boolean searchFocused;
    private boolean enabledOnly;
    private boolean dirty;
    private String basesFoundDraft;
    private boolean replaceBasesFound;
    private int editingTimer = -1;
    private String timerDurationDraft;
    private boolean replaceTimerDuration;
    private int timerError = -1;
    private Hit dragging;
    private String keyboardFocus;
    private ColorEditor colorEditor;
    private boolean scannerMethodMenu;
    private int modeX, modeY, modeW;
    private boolean collectingClip;
    private boolean contentInteractive = true;
    private int clipLeft, clipRight, clipTop, clipBottom;
    private int binding = -1;
    private int hoveredBinding = -1;
    private InputConstants.Key capturedKey;
    // Row coordinates and IDs are scoped to the card currently being rendered.
    private int rowX, rowW;
    private String rowPrefix = "";
    private int settingsCursor;

    public DonutScreen(ClientConfig config, Runnable save) {
        super(Component.literal("Donut Client"));
        this.config = config;
        this.save = save;
    }

    @Override
    protected void init() {
        // Spectre lays out in framebuffer pixels, independently of Minecraft's GUI scale.
        float guiScale = (float) minecraft.getWindow().getGuiScale();
        float displayW = width * guiScale, displayH = height * guiScale;
        float fit = Math.min(1, Math.min(displayW / 960f, displayH / 620f));
        float canvasW = displayW / fit, canvasH = displayH / fit;
        layoutUiScale = config.clickGuiStyle.scale;
        fontScale = (float) (Math.round(Math.clamp(canvasH / 1080f * layoutUiScale, .6, 3.5) * 20) / 20.0);
        float workspaceScale = Math.min(fontScale, Math.min(canvasW / 1000f, canvasH / 620f));
        // Above the reference's 1080p size, enlarge geometry with the type so
        // labels, fixed-height tiles and the header keep their original proportions.
        float zoom = Math.max(1, fontScale);
        W = Math.round(Math.min(canvasW - 32, 1320 * workspaceScale) / zoom);
        H = Math.round(Math.min(canvasH - 32, 830 * workspaceScale) / zoom);
        scale = fit * zoom / guiScale;
        fontScale /= zoom;
        originX = (width - W * scale) / 2f;
        originY = (height - H * scale) / 2f;
        layoutColumns();
        TOP = HEADER + 44;
        BOTTOM = H - 44;
        detailTop = TOP;
        detailBottom = H - 46;
        dragging = null;
        hits.clear();
        KeyMapping open = KeyMapping.get("key.donut.open_gui");
        if (lastFrame == 0 && open != null) {
            InputConstants.Key key = InputConstants.getKey(open.saveString());
            if (key.getType() == InputConstants.Type.KEYSYM
                    && InputConstants.isKeyDown(minecraft.getWindow(), key.getValue())) openingKey = key;
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        if (layoutUiScale != config.clickGuiStyle.scale && dragging == null) init();
        if (!specialTab()) layoutColumns();
        long now = System.nanoTime();
        frameSeconds = lastFrame == 0 ? 1.0 / 60 : Math.min(.1, (now - lastFrame) / 1_000_000_000.0);
        lastFrame = now;
        screenProgress = advance(screenProgress, !closing, closing ? .16 : .24);
        contentProgress = advance(contentProgress, true, .28);
        detailProgress = advance(detailProgress, true, .18);
        modalProgress = advance(modalProgress, colorEditor != null, .18);
        if (closing && screenProgress == 0) return;
        scroll = ease(scroll, scrollTarget, 18);
        detailScroll = ease(detailScroll, detailScrollTarget, 18);
        float open = (float) easeOut(screenProgress);
        originY = (height - H * scale) / 2f + 12 * (1 - open) * scale;
        mouseX = (mx - originX) / scale;
        mouseY = (my - originY) / scale;
        hoveredBinding = -1;
        hoveredModule = -1;
        hits.clear();
        double previousOpacity = pushOpacity(open);
        float previousFontScale = WorkspacePaint.pushScale(fontScale);
        g.pose().pushMatrix();
        try {
            g.fill(0, 0, width, height, withOpacity(alpha(0, config.clickGuiStyle.backgroundDim)));
            if (config.clickGuiParticles) particles.render(g, width, height, originX, originY,
                    W * scale, H * scale, config.accentColor & 0xFFFFFF, frameSeconds * config.clickGuiStyle.animationSpeed);
            g.pose().translate(originX, originY);
            g.pose().scale(scale, scale);
            drawFrame(g);
            drawCategories(g);
            if (tab == 2) drawAppearance(g);
            else if (tab == 8) drawConfigs(g);
            else if (tab == 6) drawHudWorkspace(g);
            else {
                drawWorkspaceHeader(g);
                drawOverview(g);
                if (selectedModule >= 0) drawDetails(g);
            }
            drawFooter(g);
            if ((scannerMethodMenu) && colorEditor == null) drawModeMenu(g);
            if (colorEditor != null) {
                double modalOpacity = pushOpacity(easeOut(modalProgress));
                try { drawColorEditor(g); }
                finally { popOpacity(modalOpacity); }
            }
            if (keyboardFocus != null) {
                hits.stream().filter(h -> h.id.equals(keyboardFocus)).findFirst().ifPresent(h ->
                        outline(g, h.x - 1, h.y - 1, h.w + 2, h.h + 2, 5, alpha(config.accentColor, .85)));
            }
        } finally {
            g.pose().popMatrix();
            WorkspacePaint.popScale(previousFontScale);
            popOpacity(previousOpacity);
        }
    }

    private static final int HAIRLINE = 0x12FFFFFF;
    private boolean listView;

    private void layoutColumns() {
        railW = Math.round(Math.min(220, W * .18f));
        bodyX = railW + 28;
        boolean details = selectedModule >= 0;
        detailW = details ? Math.round(Math.min(360, W * .3f)) : 0;
        detailX = W - detailW - 20;
        bodyW = (details ? detailX - 20 : W - 28) - bodyX;
        CX = bodyX;
        CW = bodyW;
        columns = listView ? 1 : bodyW >= 620 ? 3 : bodyW >= 380 ? 2 : 1;
    }

    private int accent() { return alpha(config.accentColor, 1); }

    /** Accent tinted toward white, for readable accent-colored text on the dark window. */
    private int accentText() { return blend(0xFFFFFFFF, accent(), .7); }

    /** Readable text color on top of a solid accent fill. */
    private int inkOn(int rgb) {
        double luminance = (rgb >> 16 & 255) * .2126 + (rgb >> 8 & 255) * .7152 + (rgb & 255) * .0722;
        return luminance > 160 ? 0xFF0B0D1A : 0xFFFFFFFF;
    }

    // Midnight window: a soft accent glow, full-height sidebar and an open content area.
    private void drawFrame(GuiGraphics g) {
        float r = corner(18);
        for (int i = 6; i >= 1; i--) {
            float spread = 3f * i;
            round(g, -spread, -spread + 6, W + spread * 2, H + spread * 2, r + spread, 0x10000000);
        }
        surface(g, 0, 0, W, H, r, alpha(config.clickGuiStyle.panelsColor, config.clickGuiStyle.panelsOpacity), 0.94f);
        // Subtle accent glow in the content area, like light behind frosted navy glass.
        g.enableScissor(railW, 0, W, H);
        // Many faint layers read as a smooth radial gradient instead of visible rings.
        for (int i = 0; i < 24; i++) {
            float glow = 300 - i * 12;
            round(g, W * .62f - glow, H * .52f - glow, glow * 2, glow * 2, glow, alpha(config.accentColor, .0045));
        }
        g.disableScissor();
        // Floating sidebar card.
        surface(g, 10, 10, railW - 10, H - 20, corner(14), alpha(config.clickGuiStyle.tabBarColor, config.clickGuiStyle.tabBarOpacity), 0.9f);
        outline(g, 10, 10, railW - 10, H - 20, corner(14), HAIRLINE);
        outline(g, 0, 0, W, H, r, chromeBorder());

        // Title: the accent word is slanted, the rest upright.
        String[] title = headerTitle();
        WorkspacePaint.titleItalic(g, font, title[0], bodyX, 20, accentText());
        WorkspacePaint.title(g, font, title[1], bodyX + WorkspacePaint.titleItalicWidth(font, title[0]) + s(6), 20, TEXT);
        smallText(g, font, headerSubtitle(), bodyX, 20 + s(32), DIM);

        int cs = 32, cx = W - 20 - cs, cy = 20;
        double closeHover = animate("closeHover", inside(cx, cy, cs, cs) ? 1 : 0);
        round(g, cx, cy, cs, cs, corner(9), blend(CONTROL, 0xFF3A1E2C, closeHover));
        outline(g, cx, cy, cs, cs, corner(9), HAIRLINE);
        int closeColor = blend(MUTED, 0xFFFF5C7A, closeHover);
        line(g, cx + 11f, cy + 11f, cx + 21f, cy + 21f, closeColor);
        line(g, cx + 21f, cy + 11f, cx + 11f, cy + 21f, closeColor);
        hit("close", cx, cy, cs, cs, this::onClose);
    }

    private String[] headerTitle() {
        return switch (tab) {
            case 2 -> new String[] {"Theme", "Settings"};
            case 6 -> new String[] {"HUD", "Elements"};
            case 8 -> new String[] {"Shared", "Configs"};
            case 0 -> new String[] {"Base Raid", "Modules"};
            case 7 -> new String[] {"Donut", "Modules"};
            case 1 -> new String[] {"Favorite", "Modules"};
            case 3 -> new String[] {"Blatant", "Modules"};
            case 4 -> new String[] {"Streaming", "Modules"};
            default -> new String[] {"All", "Modules"};
        };
    }

    private String headerSubtitle() {
        if (tab == 2) return "Make the workspace yours";
        if (tab == 6) return "Overlays shown while you play";
        if (tab == 8) return "Save, share and load setups";
        int count = 0, on = 0;
        for (int index = ModuleKeybinds.FIRST_MODULE; index < ModuleKeybinds.MODULE_LIMIT; index++) {
            if (!matches(index)) continue;
            count++;
            if (enabled(index)) on++;
        }
        return count + (count == 1 ? " module" : " modules") + "  ·  " + on + " enabled";
    }

    private void switchTab(int target) {
        if (tab == target && query.isEmpty()) return;
        blockDraft = null;
        commitBasesFound();
        if (!commitTimerDuration()) cancelTimerDuration();
        tab = target;
        query = "";
        if (target != 2 && target != 6 && target != 8) lastCategory = target;
        configNameDraft = null;
        armedDelete = null;
        if (target == 8) refreshConfigs();
        contentProgress = 0;
        scroll = scrollTarget = 0;
        detailScroll = detailScrollTarget = 0;
        searchFocused = false;
        keyboardFocus = null;
        dragging = null;
    }

    private void drawCategories(GuiGraphics g) {
        DonutLogo.draw(g, 24, 26, 26, config.clickGuiStyle.animationSpeed);
        strong(g, font, "Donut", 58, 24, TEXT);
        WorkspacePaint.strongItalic(g, font, "Client", 58 + WorkspacePaint.strongWidth(font, "Donut") + s(4), 24, accentText());
        smallText(g, font, "VERSION 5.0", 58, 42, DIM);

        smallText(g, font, "MODULES", 26, 82, DIM);
        int y = 98;
        category(g, "All", y, 5); y += 36;
        category(g, "Base Raid", y, 0); y += 36;
        category(g, "Donut", y, 7); y += 36;
        category(g, "Blatant", y, 3); y += 36;
        category(g, "Streaming", y, 4); y += 36;
        category(g, "Favorites", y, 1); y += 36;
        line(g, 26, y + 10, railW - 16, y + 10, HAIRLINE);
        smallText(g, font, "GENERAL", 26, y + 24, DIM);
        y += 40;
        category(g, "HUD", y, 6); y += 36;
        category(g, "Theme", y, 2); y += 36;
        category(g, "Configs", y, 8);

        int active = 0;
        for (int index = ModuleKeybinds.FIRST_MODULE; index < ModuleKeybinds.MODULE_LIMIT; index++) if (enabled(index)) active++;
        String activeLabel = active + (active == 1 ? " module running" : " modules running");
        int by = H - 58;
        round(g, 20, by, railW - 30, 34, corner(10), alpha(0xFFFFFF, .03));
        round(g, 32, by + 14, 7, 7, 3.5f, active > 0 ? SAGE : 0xFF2C3052);
        if (active > 0) round(g, 30, by + 12, 11, 11, 5.5f, alpha(SAGE, .2 + .1 * Math.sin(System.nanoTime() / 4e8)));
        smallText(g, font, activeLabel, 48, by + 11, active > 0 ? MUTED : DIM);
    }

    private void category(GuiGraphics g, String label, int y, int target) {
        boolean chosen = tab == target;
        int x = 20, w = railW - 30, h = 32;
        double hover = animate("category" + target, inside(x, y, w, h) ? 1 : 0);
        double pick = animate("categoryPick" + target, chosen ? 1 : 0);
        round(g, x, y, w, h, corner(9), alpha(0xFFFFFF, hover * .035 * (1 - pick)));
        if (pick > .01) {
            round(g, x, y, w, h, corner(9), alpha(config.accentColor, .22 * pick));
            outline(g, x, y, w, h, corner(9), alpha(config.accentColor, .25 * pick));
        }
        int tint = blend(0xFF6E7391, accentText(), Math.max(pick, hover * .4));
        int ix = x + 11, iy = y + 8;
        if (target == 5) { outline(g, ix, iy, 7, 7, 2, tint); outline(g, ix + 9, iy, 7, 7, 2, tint);
            outline(g, ix, iy + 9, 7, 7, 2, tint); outline(g, ix + 9, iy + 9, 7, 7, 2, tint); }
        else if (target == 0) { outline(g, ix, iy + 3, 16, 10, 5, tint); outline(g, ix + 5, iy + 5, 6, 6, 3, tint); }
        else if (target == 8) { for (int layer = 0; layer < 3; layer++) outline(g, ix + 1, iy + 2 + layer * 5, 15, 4, 2, tint); }
        else if (target == 7) { outline(g, ix, iy, 16, 16, 8, tint); outline(g, ix + 5, iy + 5, 6, 6, 3, tint); }
        else if (target == 3) caution(g, ix, iy - 1, tint);
        else if (target == 1) star(g, ix + 1, iy, tint);
        else if (target == 6) { outline(g, ix, iy + 1, 17, 13, 3, tint); round(g, ix + 3, iy + 9, 6, 2, 1, tint); }
        else if (target == 2) { outline(g, ix, iy - 1, 17, 17, 8.5f, tint); round(g, ix + 4, iy + 4, 3, 3, 1.5f, tint);
            round(g, ix + 9, iy + 3, 3, 3, 1.5f, tint); round(g, ix + 11, iy + 8, 3, 3, 1.5f, tint); }
        else { outline(g, ix + 1, iy + 2, 15, 12, 3, tint); line(g, ix + 4f, iy + 8f, ix + 13f, iy + 8f, tint); }
        text(g, font, label, x + 38, y + 8, chosen ? TEXT : MUTED);
        if (target != 2 && target != 6 && target != 8) {
            int count = 0;
            for (int index = ModuleKeybinds.FIRST_MODULE; index < ModuleKeybinds.MODULE_LIMIT; index++) {
                if (inTab(index, target) && (!enabledOnly || enabled(index))) count++;
            }
            String badge = Integer.toString(count);
            smallText(g, font, badge, x + w - 12 - WorkspacePaint.smallWidth(font, badge), y + 10, chosen ? accentText() : DIM);
        }
        hit("tab" + target, x, y, w, h, () -> switchTab(target));
    }

    private String categoryTitle() {
        return switch (tab) { case 0 -> "Base Raid"; case 1 -> "Favorites"; case 3 -> "Blatant";
            case 4 -> "Streaming"; case 7 -> "Donut"; default -> "All modules"; };
    }

    private String moduleCategory(int index) {
        return switch (categoryOf(index)) { case 3 -> "Blatant"; case 4 -> "Streaming"; case 7 -> "Donut"; default -> "Base Raid"; };
    }

    private void drawWorkspaceHeader(GuiGraphics g) {
        // Search sits in the title row, left of the close button.
        int h = 32, w = Math.min(280, Math.max(160, (W - bodyX) / 3));
        int x = W - 20 - 32 - 10 - w, y = 20;
        double hover = animate("searchHover", inside(x, y, w, h) || searchFocused ? 1 : 0);
        surface(g, x, y, w, h, corner(9), blend(CONTROL, CONTROL_HOVER, hover * .6), 0.82f);
        outline(g, x, y, w, h, corner(9), searchFocused ? alpha(config.accentColor, .8) : HAIRLINE);
        String shown = query.isEmpty() && !searchFocused ? "Search modules"
                : query + (searchFocused && System.currentTimeMillis() % 1000 < 500 ? "|" : "");
        int iconSpace = 32;
        search(g, x + 12, y + (h - 10) / 2, searchFocused ? accent() : CONTROL_MUTED);
        while (WorkspacePaint.width(font, shown) > w - 14 - iconSpace && !shown.isEmpty()) shown = removeFirstCharacter(shown);
        text(g, font, shown, x + iconSpace, y + (h - s(16)) / 2, query.isEmpty() ? CONTROL_MUTED : CONTROL_TEXT);
        hit("search", x, y, w, h, () -> searchFocused = true);

        // Filter row: chip on the left, list / grid switch on the right.
        int ry = HEADER + 4, rh = 26;
        String chip = "Enabled only";
        int chipW = WorkspacePaint.smallWidth(font, chip) + 34;
        double chipHover = animate("enabledOnlyHover", inside(bodyX, ry, chipW, rh) ? 1 : 0);
        round(g, bodyX, ry, chipW, rh, rh / 2f, enabledOnly ? alpha(config.accentColor, .25) : alpha(0xFFFFFF, .04 + chipHover * .03));
        outline(g, bodyX, ry, chipW, rh, rh / 2f, enabledOnly ? alpha(config.accentColor, .5) : HAIRLINE);
        round(g, bodyX + 12, ry + 10, 6, 6, 3, enabledOnly ? SAGE : 0xFF2C3052);
        smallText(g, font, chip, bodyX + 24, ry + 7, enabledOnly ? TEXT : MUTED);
        hit("enabledOnly", bodyX, ry, chipW, rh, () -> {
            enabledOnly = !enabledOnly;
            contentProgress = 0;
            scroll = scrollTarget = 0;
        });

        int vx = bodyX + bodyW - 58;
        round(g, vx, ry, 58, rh, corner(8), alpha(0xFFFFFF, .03));
        for (int i = 0; i < 2; i++) {
            boolean list = i == 0, chosen = listView == list;
            int bx = vx + 2 + i * 28;
            if (chosen) round(g, bx, ry + 2, 26, rh - 4, corner(7), alpha(config.accentColor, .3));
            int c = chosen ? TEXT : DIM;
            if (list) for (int l = 0; l < 3; l++) round(g, bx + 7, ry + 8 + l * 4, 12, 1.6f, .8f, c);
            else for (int q = 0; q < 4; q++) round(g, bx + 8 + q % 2 * 6, ry + 7 + q / 2 * 6, 4.5f, 4.5f, 1.2f, c);
            hit(list ? "viewList" : "viewGrid", bx, ry, 26, rh, () -> {
                if (listView != list) { listView = list; layoutColumns(); contentProgress = 0; scroll = scrollTarget = 0; }
            });
        }
    }

    private String mascotModule() {
        int index = selectedModule >= 0 ? selectedModule : previewModule;
        return switch (index) {
            case 2 -> "freecam";
            case 3 -> "builder"; case 4 -> "sus-chunk-finder"; case 5 -> "fullbright";
            case 6 -> "fly"; case 7 -> "hud"; case 8 -> "name-protect"; case 9 -> "no-inv-leak";
            default -> "idle";
        };
    }

    private static final int TILE_H = 108, LIST_H = 64, TILE_GAP = 12;

    private int tileHeight() { return listView ? LIST_H : TILE_H; }

    private void drawOverview(GuiGraphics g) {
        int count = 0, th = tileHeight();
        for (int index = ModuleKeybinds.FIRST_MODULE; index < ModuleKeybinds.MODULE_LIMIT; index++) if (matches(index)) count++;
        contentHeight = ((count + columns - 1) / columns) * (th + TILE_GAP) + 10;
        clampScroll();
        beginContent(g);
        int ordinal = 0, tileW = (bodyW - TILE_GAP * (columns - 1)) / columns;
        for (int index = ModuleKeybinds.FIRST_MODULE; index < ModuleKeybinds.MODULE_LIMIT; index++) {
            if (!matches(index)) continue;
            double phase = easeOut(Math.clamp((easeOut(contentProgress) - Math.min(ordinal, 8) * .025) / .8, 0, 1));
            int x = CX + ordinal % columns * (tileW + TILE_GAP);
            int y = TOP + 4 + ordinal / columns * (th + TILE_GAP) - (int) scroll + (int) ((1 - phase) * 10);
            double opacity = pushOpacity(phase);
            try { moduleTile(g, index, x, y, tileW, th); }
            finally { popOpacity(opacity); }
            ordinal++;
        }
        if (count == 0) {
            int cy = TOP + 60;
            search(g, bodyX + bodyW / 2 - 5, cy, DIM);
            String a = "No modules found", b = enabledOnly ? "Try turning off Enabled only." : "Try another name or category.";
            text(g, font, a, bodyX + (bodyW - WorkspacePaint.width(font, a)) / 2, cy + 24, CONTROL_TEXT);
            smallText(g, font, b, bodyX + (bodyW - WorkspacePaint.smallWidth(font, b)) / 2f, cy + 48, CONTROL_MUTED);
        }
        endContent(g);
    }

    /** Text card: bold name and switch on top, short description, a chevron to open settings. */
    private void moduleTile(GuiGraphics g, int index, int x, int y, int w, int h) {
        boolean inView = mouseY >= TOP && mouseY < BOTTOM && colorEditor == null;
        boolean hovered = inView && inside(x, y, w, h);
        boolean active = enabled(index), selected = selectedModule == index;
        double hover = animate("tile" + index, hovered || selected ? 1 : 0);
        double on = animate("tileEnabled" + index, active ? 1 : 0);
        float r = corner(12);
        surface(g, x, y, w, h, r, alpha(config.clickGuiStyle.cardsColor, config.clickGuiStyle.cardsOpacity), 0.86f);
        round(g, x, y, w, h, r, alpha(config.accentColor, .035 * hover + .06 * on));
        if (on > .01) round(g, x + 1, y + h / 2f - 12 * (float) on, 2, 24 * (float) on, 1, accent());
        // Active cards catch a little accent light along their top edge.
        if (on > .01) for (int i = 0; i < 6; i++)
            round(g, x + 1, y + 1, w - 2, s(10) - i, r, alpha(config.accentColor, .025 * on));

        int pad = 14, switchW = 28, switchH = 16, badge = 30;
        int sx = x + w - pad - switchW, sy = y + pad + (badge - switchH) / 2;
        // Icon badge, tinted with the accent while the module runs.
        int bx = x + pad, by = y + (listView ? (h - badge) / 2 : pad);
        round(g, bx, by, badge, badge, corner(9), alpha(config.accentColor, .1 + on * .16 + hover * .04));
        moduleIcon(g, index, bx + (badge - 17) / 2, by + (badge - 17) / 2, blend(0xFF8186A8, accentText(), Math.max(on, hover * .6)));
        int tx = bx + badge + 10, textW = sx - 10 - tx;
        if (listView) {
            strong(g, font, ellipsize(name(index), textW), tx, y + h / 2 - s(17), TEXT);
            smallText(g, font, ellipsizeSmall(description(index), textW), tx, y + h / 2 + s(2), DIM);
        } else {
            strong(g, font, ellipsize(name(index), textW), tx, by + (badge - s(17)) / 2, TEXT);
            smallLines(g, description(index), x + pad, by + badge + 10, w - pad * 2, 2, DIM);
            smallText(g, font, moduleCategory(index).toUpperCase(Locale.ROOT), x + pad, y + h - pad - 10, alpha(0xFF6E7391, .7));
        }
        hit("module" + index, x, y, w, h, () -> selectModule(index), () -> selectModule(index));

        // Switch (AutoBuilder opens its screen instead, shown as a small play arrow).
        boolean switchHover = inView && inside(sx - 6, sy - 6, switchW + 12, switchH + 12);
        double press = animate("tileAction" + index, switchHover ? 1 : 0);
        if (index == 3) {
            round(g, sx + 4, sy - 2, 20, 20, 10, alpha(config.accentColor, .15 + press * .15));
            line(g, sx + 12f, sy + 3f, sx + 18f, sy + 8f, accentText());
            line(g, sx + 18f, sy + 8f, sx + 12f, sy + 13f, accentText());
        } else {
            round(g, sx, sy, switchW, switchH, switchH / 2f, blend(blend(TRACK, 0xFF30355E, press), accent(), on));
            round(g, sx + 2 + (float) on * 12, sy + 2, 12, 12, 6, blend(0xFFB4B8D6, 0xFFFFFFFF, on));
        }
        hit("enable" + index, sx - 6, sy - 6, switchW + 12, switchH + 12, () -> toggleEnabled(index));

        // Chevron: opens settings.
        int cx = x + w - pad - 6, cy = y + h - pad - 6;
        int chevron = blend(0xFF6E7391, accentText(), hover);
        line(g, cx - 2f, cy - 4f, cx + 2f, cy, chevron);
        line(g, cx + 2f, cy, cx - 2f, cy + 4f, chevron);

        outline(g, x, y, w, h, r, selected ? alpha(config.accentColor, .9)
                : blend(HAIRLINE, alpha(config.accentColor, .35), Math.max(hover * .8, on * .5)));
    }

    /** Small text wrapped on word boundaries, at most {@code maxLines}, the last one ellipsized. */
    private void smallLines(GuiGraphics g, String value, int x, int y, int maxWidth, int maxLines, int color) {
        String[] words = value.split(" ");
        int line = 0, i = 0;
        while (i < words.length && line < maxLines) {
            String current = words[i++];
            while (i < words.length && WorkspacePaint.smallWidth(font, current + " " + words[i]) <= maxWidth) current += " " + words[i++];
            if (line == maxLines - 1 && i < words.length) current = ellipsizeSmall(current + " " + String.join(" ", java.util.Arrays.copyOfRange(words, i, words.length)), maxWidth);
            smallText(g, font, ellipsizeSmall(current, maxWidth), x, y + line * s(13), color);
            line++;
        }
    }

    private String ellipsizeSmall(String value, int maxWidth) {
        if (WorkspacePaint.smallWidth(font, value) <= maxWidth) return value;
        while (!value.isEmpty() && WorkspacePaint.smallWidth(font, value + "...") > maxWidth) value = removeLastCharacter(value);
        return value + "...";
    }

    private void selectModule(int index) {
        blockDraft = null;
        commitBasesFound();
        if (!commitTimerDuration()) cancelTimerDuration();
        if (selectedModule != index || previewModule != index) {
            detailProgress = 0;
            detailScroll = detailScrollTarget = 0;
        }
        selectedModule = previewModule = index;
        dragging = null;
        keyboardFocus = null;
    }

    private void closeDetails() {
        blockDraft = null;
        commitBasesFound();
        if (!commitTimerDuration()) cancelTimerDuration();
        selectedModule = previewModule = -1;
        dragging = null;
        keyboardFocus = null;
        scannerMethodMenu = false;
        layoutColumns();
    }

    private void drawDetails(GuiGraphics g) {
        int x = detailX, y = HEADER + 4, w = detailW, h = H - HEADER - 24;
        surface(g, x, y, w, h, corner(16), alpha(config.clickGuiStyle.cardsColor, config.clickGuiStyle.cardsOpacity * .7), 0.93f);
        outline(g, x, y, w, h, corner(16), chromeBorder());
        smallText(g, font, selectedModule == previewModule && previewModule >= 0 ? "MODULE SETTINGS" : "MODULE PREVIEW",
                x + 20, y + 20, DIM);
        int cbx = x + w - 40, cby = y + 12;
        double closeHover = animate("detailClose", inside(cbx, cby, 26, 26) ? 1 : 0);
        round(g, cbx, cby, 26, 26, corner(8), alpha(0xFFFFFF, .04 + closeHover * .06));
        line(g, cbx + 9f, cby + 9f, cbx + 17f, cby + 17f, blend(DIM, TEXT, closeHover));
        line(g, cbx + 17f, cby + 9f, cbx + 9f, cby + 17f, blend(DIM, TEXT, closeHover));
        hit("closeDetails", cbx, cby, 26, 26, this::closeDetails);
        if (previewModule < 0) {
            int cx = x + w / 2, cy = y + 110;
            round(g, cx - 30, cy - 30, 60, 60, 30, alpha(config.accentColor, .12));
            g.pose().pushMatrix();
            try { g.pose().translate(cx, cy); g.pose().scale(1.8f, 1.8f); cube(g, -8, -8, 12, accent(), .9, .18); }
            finally { g.pose().popMatrix(); }
            String t = "Explore your modules";
            text(g, font, t, cx - WorkspacePaint.width(font, t) / 2, cy + 50, TEXT);
            WorkspacePaint.wrapped(g, font, "Hover a card to preview it here. Click it to edit its settings.",
                    x + 24, cy + 78, w - 48, CONTROL_MUTED);
            return;
        }
        int index = previewModule;
        double opacity = pushOpacity(Math.max(.03, easeOut(detailProgress)));
        try {
            int rise = (int) ((1 - easeOut(detailProgress)) * 6);
            int iy = y + 48 + rise;
            boolean active = enabled(index);
            round(g, x + 20, iy, 44, 44, corner(12), alpha(config.accentColor, active ? .22 : .1));
            moduleIcon(g, index, x + 34, iy + 13, active ? blend(0xFFFFFFFF, accent(), .5) : MUTED);
            strong(g, font, ellipsize(name(index), w - 100), x + 76, iy + 4, CONTROL_TEXT);
            String chip = moduleCategory(index).toUpperCase(Locale.ROOT);
            int chipW = WorkspacePaint.smallWidth(font, chip) + 14;
            round(g, x + 76, iy + 26, chipW, 16, 8, alpha(config.accentColor, .16));
            smallText(g, font, chip, x + 83, iy + 28, blend(0xFFFFFFFF, accent(), .6));
            if (index != 3) {
                String state = active ? "ON" : "OFF";
                smallText(g, font, state, x + 76 + chipW + 8, iy + 28, active ? SAGE : DIM);
            }
            int descriptionH = WorkspacePaint.wrapped(g, font, description(index), x + 20, iy + 62, w - 40, CONTROL_MUTED);
            detailTop = Math.max(iy + 62 + descriptionH + 20, y + 150);
            detailBottom = y + h - 12;
            line(g, x + 20, detailTop - 10, x + w - 20, detailTop - 10, HAIRLINE);
            if (index != selectedModule) {
                primaryButton(g, "configureModule", "Configure module", x + 20, detailTop, w - 40, s(36), () -> selectModule(index));
                return;
            }
            clampDetailScroll();
            beginRegion(g, x + 1, detailTop, w - 2, detailBottom - detailTop);
            rowX = x + 20;
            rowW = w - 40;
            rowPrefix = "m" + index + ".";
            settingsCursor = detailTop + 8 - (int) detailScroll;
            String label = index == 3 ? "Open AutoBuilder" : enabled(index) ? "Disable module" : "Enable module";
            if (index != 3 && enabled(index)) button(g, "detailEnable", label, rowX, settingsCursor, rowW, s(36), () -> toggleEnabled(index));
            else primaryButton(g, "detailEnable", label, rowX, settingsCursor, rowW, s(36), () -> toggleEnabled(index));
            settingsCursor += s(52);
            drawModuleSettings(g, index);
            section(g, "Keybind", 0);
            keybindButton(g, index, rowX, settingsCursor, rowW, s(32));
            settingsCursor += s(46);
            section(g, "Configuration", 0);
            settingToggle(g, "favorite", "Favorite", 0, () -> favorite(index), () -> toggleFavorite(index));
            // Preserve the existing binding/favorite control identities for keyboard navigation.
            Hit favoriteHit = hits.isEmpty() ? null : hits.getLast();
            if (favoriteHit != null && favoriteHit.id.equals(rowPrefix + "favorite")) {
                hits.set(hits.size() - 1, new Hit("favorite" + index, favoriteHit.x, favoriteHit.y,
                        favoriteHit.w, favoriteHit.h, favoriteHit.action, null, null, false, null));
            }
            detailContentHeight = settingsCursor + s(20) - detailTop + (int) detailScroll;
            endRegion(g);
            clampDetailScroll();
            drawDetailScrollbar(g);
        } finally { popOpacity(opacity); }
    }

    private int s(float size) { return Math.round(size * fontScale); }

    private float corner(float size) { return (float) (size * config.clickGuiStyle.rounding / 10); }

    private boolean matches(int index) {
        if (enabledOnly && !enabled(index)) return false;
        if (!inTab(index, tab)) return false;
        String words = switch (index) {
            case 2 -> "freecam free camera fly perspective spectator";
            case 4 -> "base finder basefinder chunk finder chunkfinder geode amethyst activity kelp cave vines bamboo cocoa bee nest";
            case 5 -> "fullbright full bright brightness gamma night dark lighting";
            case 6 -> "fly flight vanilla singleplayer single player multiplayer multi player lan server movement creative";
            case 7 -> "progress bar progressbar streaming stream overlay hud hexagon milestone overworld grass nether netherrack end portal";
            case 8 -> "name hider namehider hide username account privacy streamer streaming sidebar scoreboard";
            case 9 -> "hotbar hot bar blur items inventory privacy streamer streaming hud";
            case 11 -> "light debug detector artificial underground denoise lighting";
            case 10 -> "amethyst scanner bypass geode anti-xray palette light anbs crystals";
            case 15 -> "unnatural blocks player placed blocks built base tunnel rotated deepslate planks glass torch sus chunk";
            case 16 -> "block entity esp blockentity chest barrel shulker hopper furnace storage leaked tile entity";
            case 17 -> "spawner notifier spawners mob dungeon trial spawner farm donut";
            case 18 -> "hidden base detector player bypass sky light protected base underground donut";
            case 19 -> "live activity prime chunk light changes redstone below zero active player torch";
            case 20 -> "chunk refresh render distance toggle reload chunks anti xray deepslate";
            case 21 -> "cobbled deepslate cobble tunnel placed blocks base finder stairs slab wall";
            case 22 -> "rtp random teleport biome finder wild auto disconnect cherry mushroom donut";
            case 23 -> "player esp players tracers nearby list staff wallhack radar";
            case 13 -> "sound detector sounddetector audio player activity alarm warning chest piston machine machinery";
            case 14 -> "staff detector staffdetector moderator admin spectator invisible vanish presence roster";
            case 12 -> "blockesp block esp ore ores seed predictor prediction deepslate emerald coal rare ancient debris netherite nether";
            default -> "autobuilder auto builder schematic litematic building materials navigation";
        };
        return words.contains(query.toLowerCase(Locale.ROOT).trim());
    }

    /** Categories: 0 Base Raid, 7 Donut, 3 Blatant, 4 Streaming, 1 Favorites, 5 All. */
    private static int categoryOf(int index) {
        return switch (index) {
            case 3, 6 -> 3;
            case 7, 8, 9 -> 4;
            case 14, 17, 18, 22, 23 -> 7;
            default -> 0;
        };
    }

    private boolean inTab(int index, int category) {
        if (category == 1) return favorite(index);
        return category == 5 || categoryOf(index) == category;
    }

    private void drawModuleSettings(GuiGraphics g, int index) {
        if (index >= 15) drawRaidSettings(g, index);
        else if (index == 14) drawStaffDetectorSettings(g);
        else if (index == 13) drawSoundDetectorSettings(g);
        else if (index == 12) drawBlockEspSettings(g);
        else if (index == 11) drawLightDebugSettings(g);
        else if (index == 10) drawAmethystSettings(g);
        else if (index == 9) drawHotbarSettings(g, 0);
        else if (index == 8) drawNameHiderSettings(g, 0);
        else if (index == 7) drawProgressBarSettings(g, 0);
        else if (index == 6) drawFlySettings(g, 0);
        else if (index == 5) drawFullbrightSettings(g, 0);
        else if (index == 4) drawChunkFinderSettings(g, 0);
        else if (index == 3) drawAutoBuilderSettings(g, 0);
        else if (index == 2) drawFreecamSettings(g, 0);
    }

    private void help(GuiGraphics g, String value) {
        settingsCursor += s(4);
        settingsCursor += WorkspacePaint.smallWrapped(g, font, value, rowX, settingsCursor, rowW, CONTROL_MUTED) + s(10);
    }

    private void clampDetailScroll() {
        int max = Math.max(0, detailContentHeight - (detailBottom - detailTop));
        detailScroll = Math.clamp(detailScroll, 0, max);
        detailScrollTarget = Math.clamp(detailScrollTarget, 0, max);
    }

    private void beginRegion(GuiGraphics g, int x, int y, int w, int h) {
        g.enableScissor(x, y, x + w, y + Math.max(0, h));
        collectingClip = true;
        clipLeft = x;
        clipRight = x + w;
        clipTop = y;
        clipBottom = y + Math.max(0, h);
    }

    private void endRegion(GuiGraphics g) {
        collectingClip = false;
        g.disableScissor();
    }

    private void drawDetailScrollbar(GuiGraphics g) {
        scrollbar(g, "detailScrollbar", detailX + detailW - 8, detailTop, detailBottom - detailTop,
                detailContentHeight, detailScroll, value -> detailScroll = detailScrollTarget = value);
    }

    private void scrollbar(GuiGraphics g, String id, int x, int y, int viewHeight, int total, double position, DoubleConsumer move) {
        int max = Math.max(0, total - viewHeight);
        if (max <= 0 || viewHeight <= 0) return;
        int thumbHeight = Math.max(s(22), viewHeight * viewHeight / total);
        int thumbY = y + (int) (position / max * (viewHeight - thumbHeight));
        round(g, x, thumbY, Math.max(2, s(3)), thumbHeight, s(2), 0x50FFFFFF);
        dragHit(id, x - 3, y, 8, viewHeight,
                value -> move.accept(Math.clamp(value, 0, 1) * max), true);
    }

    private void drawModeMenu(GuiGraphics g) {
        hits.clear();
        int rowH = s(32), h = rowH * 3;
        int y = Math.clamp(modeY, 82, H - 42 - h);
        shadow(g, modeX, y, modeW, h, s(7), 0x80000000);
        surface(g, modeX, y, modeW, h, s(7), CONTROL, 0.9f);
        outline(g, modeX, y, modeW, h, s(7), 0x30FFFFFF);
        if (scannerMethodMenu) {
            var methods = selectedModule == 10 ? dev.donut.client.config.AmethystSettings.METHODS : dev.donut.client.config.ChunkFinderSettings.METHODS;
            for (int i = 0; i < methods.size(); i++) {
                String method = methods.get(i);
                int top = y + i * rowH;
                if (inside(modeX, top, modeW, rowH)) round(g, modeX, top, modeW, rowH, s(5), CONTROL_HOVER);
                text(g, font, method, modeX + s(10), top + s(8), CONTROL_TEXT);
                hit("m" + selectedModule + ".method" + i, modeX, top, modeW, rowH,
                        () -> { change(() -> { if (selectedModule == 10) config.amethyst.method = method; else config.chunkFinder.method = method; }); scannerMethodMenu = false; });
            }
            return;
        }
    }

    private void button(GuiGraphics g, String id, String label, int x, int y, int w, int h, Runnable action) {
        double hover = animate("button" + id, inside(x, y, w, h) ? 1 : 0);
        surface(g, x, y, w, h, corner(10), blend(CONTROL_HOVER, 0xFF262B52, hover), 0.78f);
        outline(g, x, y, w, h, corner(10), alpha(0xFFFFFF, .05 + hover * .05));
        // Soft top highlight, like light catching the edge of the button.
        line(g, x + corner(10), y + 1, x + w - corner(10), y + 1, alpha(0xFFFFFF, .06 + hover * .06));
        String shown = ellipsize(label, w - s(12));
        text(g, font, shown, x + (w - WorkspacePaint.width(font, shown)) / 2, y + (h - s(16)) / 2, CONTROL_TEXT);
        hit(id, x, y, w, h, action);
    }

    private void primaryButton(GuiGraphics g, String id, String label, int x, int y, int w, int h, Runnable action) {
        double hover = animate("button" + id, inside(x, y, w, h) ? 1 : 0);
        round(g, x - s(2), y + s(3), w + s(4), h, corner(10) + s(2), alpha(config.accentColor, .18 + hover * .12));
        surface(g, x, y, w, h, corner(10), blend(accent(), 0xFFFFFFFF, hover * .1), 0.62f);
        line(g, x + corner(10), y + 1, x + w - corner(10), y + 1, alpha(0xFFFFFF, .22));
        String shown = ellipsize(label, w - s(12));
        text(g, font, shown, x + (w - WorkspacePaint.width(font, shown)) / 2, y + (h - s(16)) / 2, inkOn(config.accentColor));
        hit(id, x, y, w, h, action);
    }

    // ---------------------------------------------------------------- shared configs page (tab 8)

    private final dev.donut.client.config.SharedConfigs sharedConfigs = new dev.donut.client.config.SharedConfigs(
            net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("donut-configs"));
    private List<dev.donut.client.config.SharedConfigs.Entry> configEntries;
    private String configNameDraft;
    private String configStatus = "Save your setup, or paste a code someone shared with you.";
    private boolean configStatusError;
    private String armedDelete;
    private double configScroll, configScrollTarget;
    private int configListTop, configListBottom, configListHeight;

    private boolean specialTab() { return tab == 2 || tab == 6 || tab == 8; }

    private void configMessage(String text, boolean error) { configStatus = text; configStatusError = error; }

    private void refreshConfigs() { configEntries = sharedConfigs.list(); }

    private void drawConfigs(GuiGraphics g) {
        if (configEntries == null) refreshConfigs();
        int top = HEADER + 4, h = H - HEADER - 24, pad = s(20);
        detailW = Math.round(Math.min(380 * fontScale, .4f * (W - railW)));
        detailX = W - detailW - 20;
        int listX = bodyX, listW = detailX - 20 - bodyX;
        surface(g, listX, top, listW, h, corner(16), alpha(config.clickGuiStyle.cardsColor, config.clickGuiStyle.cardsOpacity * .5), 0.9f);
        outline(g, listX, top, listW, h, corner(16), chromeBorder());
        surface(g, detailX, top, detailW, h, corner(16), alpha(config.clickGuiStyle.cardsColor, config.clickGuiStyle.cardsOpacity * .7), 0.93f);
        outline(g, detailX, top, detailW, h, corner(16), chromeBorder());

        // Left: saved configs.
        smallText(g, font, "MY CONFIGS  ·  " + configEntries.size(), listX + pad, top + pad, DIM);
        configListTop = top + s(44);
        configListBottom = top + h - pad;
        int rowH = s(64), gap = s(10);
        configListHeight = configEntries.size() * (rowH + gap);
        int maxScroll = Math.max(0, configListHeight - (configListBottom - configListTop));
        configScrollTarget = Math.clamp(configScrollTarget, 0, maxScroll);
        configScroll = ease(configScroll, configScrollTarget, 18);
        beginRegion(g, listX + 1, configListTop, listW - 2, configListBottom - configListTop);
        if (configEntries.isEmpty()) {
            int cy = configListTop + s(40);
            String a = "No saved configs yet", b = "Name your setup on the right and save it.";
            text(g, font, a, listX + (listW - WorkspacePaint.width(font, a)) / 2, cy, CONTROL_TEXT);
            smallText(g, font, b, listX + (listW - WorkspacePaint.smallWidth(font, b)) / 2f, cy + s(24), CONTROL_MUTED);
        }
        int y = configListTop - (int) configScroll;
        var dates = java.time.format.DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm", Locale.ROOT).withZone(java.time.ZoneId.systemDefault());
        for (int i = 0; i < configEntries.size(); i++, y += rowH + gap) {
            var entry = configEntries.get(i);
            int rx = listX + pad, rw = listW - pad * 2;
            if (y + rowH < configListTop || y > configListBottom) continue;
            double hover = animate("configRow" + i, inside(rx, y, rw, rowH) ? 1 : 0);
            surface(g, rx, y, rw, rowH, corner(12), blend(CARD, CONTROL_HOVER, hover * .5), 0.86f);
            outline(g, rx, y, rw, rowH, corner(12), blend(HAIRLINE, alpha(config.accentColor, .4), hover));
            int badge = s(36), bx = rx + s(14), by = y + (rowH - badge) / 2;
            round(g, bx, by, badge, badge, corner(10), alpha(config.accentColor, .16));
            for (int layer = 0; layer < 3; layer++) round(g, bx + s(9), by + s(10) + layer * s(6), s(18), s(3), s(1.5f), accentText());
            int buttonsW = s(64) + s(56) + s(28) + s(16);
            int tx = bx + badge + s(12), textW = rw - (tx - rx) - buttonsW - s(14);
            strong(g, font, ellipsize(entry.name(), textW), tx, y + s(14), TEXT);
            smallText(g, font, ellipsizeSmall(entry.modulesOn() + (entry.modulesOn() == 1 ? " module on" : " modules on") + "  ·  "
                    + dates.format(java.time.Instant.ofEpochMilli(entry.modified())), textW), tx, y + s(37), DIM);
            int bxx = rx + rw - s(14) - s(28), byy = y + (rowH - s(28)) / 2;
            boolean armed = entry.name().equals(armedDelete);
            double removeHover = animate("configRemove" + i, inside(bxx, byy, s(28), s(28)) ? 1 : 0);
            round(g, bxx, byy, s(28), s(28), corner(8), alpha(0xFFFF5C7A, armed ? .45 : .06 + removeHover * .18));
            int xc = armed ? 0xFFFFFFFF : blend(DIM, 0xFFFF5C7A, removeHover);
            line(g, bxx + s(10), byy + s(10), bxx + s(18), byy + s(18), xc);
            line(g, bxx + s(18), byy + s(10), bxx + s(10), byy + s(18), xc);
            hit("configDelete" + i, bxx, byy, s(28), s(28), () -> {
                if (!entry.name().equals(armedDelete)) { armedDelete = entry.name(); configMessage("Click the red cross again to delete \"" + entry.name() + "\".", false); return; }
                armedDelete = null;
                try { sharedConfigs.delete(entry); configMessage("Deleted \"" + entry.name() + "\".", false); }
                catch (java.io.IOException error) { configMessage("Could not delete: " + error.getMessage(), true); }
                refreshConfigs();
            });
            int codeX = bxx - s(8) - s(56);
            button(g, "configCode" + i, "Code", codeX, byy, s(56), s(28), () -> {
                try {
                    minecraft.keyboardHandler.setClipboard(dev.donut.client.config.SharedConfigs.shareCode(entry.name(), sharedConfigs.read(entry)));
                    configMessage("Copied the code for \"" + entry.name() + "\". Paste it anywhere to share it.", false);
                } catch (java.io.IOException error) { configMessage(error.getMessage(), true); }
            });
            primaryButton(g, "configLoad" + i, "Load", codeX - s(8) - s(64), byy, s(64), s(28), () -> {
                try {
                    var loaded = sharedConfigs.read(entry);
                    change(() -> dev.donut.client.config.SharedConfigs.apply(loaded, config));
                    configMessage("Loaded \"" + entry.name() + "\". Your staff lists, seed and stream progress were kept.", false);
                } catch (java.io.IOException error) { configMessage(error.getMessage(), true); }
            });
        }
        endRegion(g);
        scrollbar(g, "configScrollbar", listX + listW - 8, configListTop, configListBottom - configListTop, configListHeight,
                configScroll, value -> configScroll = configScrollTarget = value);

        // Right: actions.
        detailTop = top + s(56);
        detailBottom = top + h - pad;
        smallText(g, font, "SAVE & SHARE", detailX + pad, top + pad, DIM);
        clampDetailScroll();
        beginRegion(g, detailX + pad - 2, detailTop, detailW - pad * 2 + 4, detailBottom - detailTop);
        rowX = detailX + pad;
        rowW = detailW - pad * 2;
        rowPrefix = "";
        settingsCursor = detailTop - (int) detailScroll;
        section(g, "Save my current setup", 0);
        int fy = settingsCursor, fh = s(34);
        boolean editing = configNameDraft != null;
        surface(g, rowX, fy, rowW, fh, corner(9), editing ? FIELD : CONTROL, 0.8f);
        outline(g, rowX, fy, rowW, fh, corner(9), editing ? alpha(config.accentColor, .8) : HAIRLINE);
        String shownName = editing ? configNameDraft + (System.currentTimeMillis() % 1000 < 500 ? "|" : "") : "Config name";
        text(g, font, ellipsize(shownName, rowW - s(20)), rowX + s(12), fy + (fh - s(16)) / 2,
                editing && !configNameDraft.isEmpty() ? CONTROL_TEXT : CONTROL_MUTED);
        hit("configName", rowX, fy, rowW, fh, () -> { if (configNameDraft == null) configNameDraft = ""; searchFocused = false; keyboardFocus = null; });
        settingsCursor += fh + s(10);
        primaryButton(g, "configSave", "Save config", rowX, settingsCursor, rowW, s(36), this::saveConfigDraft);
        settingsCursor += s(46);
        help(g, "Saving with an existing name replaces that config.");
        section(g, "Share", 0);
        button(g, "configCopyCurrent", "Copy my setup as a code", rowX, settingsCursor, rowW, s(34), () -> {
            String name = configNameDraft != null && !configNameDraft.isBlank() ? configNameDraft : "Shared setup";
            minecraft.keyboardHandler.setClipboard(dev.donut.client.config.SharedConfigs.shareCode(name, config));
            configMessage("Copied your setup as a code. Paste it in Discord or anywhere else.", false);
        });
        settingsCursor += s(44);
        button(g, "configImport", "Import a code from clipboard", rowX, settingsCursor, rowW, s(34), this::importConfigCode);
        settingsCursor += s(44);
        help(g, "Imported codes are saved to My configs first, so you can look before you press Load.");
        section(g, "Files", 0);
        button(g, "configFolder", "Open configs folder", rowX, settingsCursor, rowW, s(34), () -> {
            try { java.nio.file.Files.createDirectories(sharedConfigs.folder()); net.minecraft.util.Util.getPlatform().openPath(sharedConfigs.folder()); }
            catch (Exception error) { configMessage("Could not open the folder: " + error.getMessage(), true); }
        });
        settingsCursor += s(44);
        button(g, "configRefresh", "Refresh list", rowX, settingsCursor, rowW, s(34), () -> { refreshConfigs(); configMessage("List refreshed.", false); });
        settingsCursor += s(44);
        help(g, "Config files can also be sent as .json and dropped into this folder.");
        section(g, "What is shared", 0);
        help(g, "All module settings, colors and the theme. Your staff lists, per-server sound profiles, BlockESP seed and stream progress are never included.");
        section(g, "Status", 0);
        settingsCursor += s(6);
        settingsCursor += WorkspacePaint.wrapped(g, font, configStatus, rowX, settingsCursor, rowW, configStatusError ? 0xFFFF7A8C : accentText()) + s(12);
        detailContentHeight = settingsCursor + s(20) - detailTop + (int) detailScroll;
        endRegion(g);
        clampDetailScroll();
        drawDetailScrollbar(g);
    }

    private void saveConfigDraft() {
        String name = configNameDraft == null ? "" : configNameDraft;
        try {
            var entry = sharedConfigs.save(name, config);
            configNameDraft = null;
            configMessage("Saved \"" + entry.name() + "\".", false);
            refreshConfigs();
        } catch (java.io.IOException error) {
            if (configNameDraft == null) configNameDraft = "";
            configMessage(error.getMessage(), true);
        }
    }

    private void importConfigCode() {
        try {
            var shared = dev.donut.client.config.SharedConfigs.decode(minecraft.keyboardHandler.getClipboard());
            String name = shared.name();
            var names = new java.util.HashSet<String>();
            for (var entry : sharedConfigs.list()) names.add(entry.name().toLowerCase(Locale.ROOT));
            for (int n = 2; names.contains(name.toLowerCase(Locale.ROOT)) && n < 100; n++)
                name = dev.donut.client.config.SharedConfigs.cleanName(shared.name() + " (" + n + ")");
            var entry = sharedConfigs.save(name, shared.config());
            refreshConfigs();
            configMessage("Imported \"" + entry.name() + "\" (" + entry.modulesOn() + " modules on). Press Load to use it.", false);
        } catch (java.io.IOException error) { configMessage(error.getMessage(), true); }
    }


    private void drawHudWorkspace(GuiGraphics g) {
        int top = HEADER + 4, h = H - HEADER - 24, pad = s(20);
        detailW = Math.round(Math.min(380 * fontScale, .4f * (W - railW)));
        detailX = W - detailW - 20;
        int previewX = bodyX, previewW = detailX - 20 - bodyX;
        surface(g, previewX, top, previewW, h, corner(16), alpha(config.clickGuiStyle.cardsColor, config.clickGuiStyle.cardsOpacity * .5), 0.9f);
        outline(g, previewX, top, previewW, h, corner(16), chromeBorder());
        surface(g, detailX, top, detailW, h, corner(16), alpha(config.clickGuiStyle.cardsColor, config.clickGuiStyle.cardsOpacity * .7), 0.93f);
        outline(g, detailX, top, detailW, h, corner(16), chromeBorder());
        smallText(g, font, "HUD SETTINGS", detailX + pad, top + pad, DIM);
        smallText(g, font, "Choose an element to edit it.", detailX + pad, top + pad + s(18), CONTROL_MUTED);
        smallText(g, font, "HUD ELEMENTS", previewX + pad, top + pad, DIM);
        int cardW = previewW - pad * 2, y = top + s(48);
        int[] modules = {7, 9};
        for (int module : modules) {
            int cx = previewX + pad, ch = s(76);
            double hover = animate("hudCard" + module, inside(cx, y, cardW, ch) ? 1 : 0);
            surface(g, cx, y, cardW, ch, corner(12), blend(CARD, CONTROL_HOVER, hover), 0.84f);
            outline(g, cx, y, cardW, ch, corner(12), blend(HAIRLINE, 0x30FFFFFF, hover));
            round(g, cx + s(14), y + s(16), s(44), s(44), corner(10), alpha(config.accentColor, enabled(module) ? .22 : .1));
            moduleIcon(g, module, cx + s(14) + (s(44) - 17) / 2, y + s(16) + (s(44) - 17) / 2, enabled(module) ? accent() : MUTED);
            text(g, font, name(module), cx + s(72), y + s(18), CONTROL_TEXT);
            smallText(g, font, ellipsize(description(module), cardW - s(90)), cx + s(72), y + s(42), CONTROL_MUTED);
            hit("hudModule" + module, cx, y, cardW, ch, () -> { switchTab(4); selectModule(module); });
            y += ch + s(12);
        }
        detailTop = top + s(56);
        detailBottom = top + h - pad;
        clampDetailScroll();
        beginRegion(g, detailX + pad, detailTop, detailW - pad * 2, detailBottom - detailTop);
        rowX = detailX + pad;
        rowW = detailW - pad * 2;
        rowPrefix = "";
        settingsCursor = detailTop - (int) detailScroll;
        section(g, "General settings", 0);
        settingToggle(g, "hud", "Array list", 0, () -> config.showHud, () -> config.showHud = !config.showHud);
        section(g, "Progress bar", 0);
        settingToggle(g, "hudProgress", "Show progress bar", 0, () -> config.progressBar.enabled, () -> config.progressBar.enabled = !config.progressBar.enabled);
        button(g, "hudMoveOverlay", "Edit position & size", rowX, settingsCursor, rowW, s(34), () -> {
            flush(); minecraft.setScreen(new ProgressBarEditorScreen(this, config, save));
        });
        settingsCursor += s(48);
        help(g, "Drag the progress overlay in the editor to choose its position.");
        detailContentHeight = settingsCursor + s(20) - detailTop + (int) detailScroll;
        endRegion(g);
        drawDetailScrollbar(g);
    }

    private void surface(GuiGraphics g, float x, float y, float w, float h, float radius, int tint, float frost) {
        if (config.clickGuiStyle.liquidGlass) GlassPanel.draw(g, x, y, w, h, radius, withOpacity(tint), frost);
        else UiPaint.round(g, x, y, w, h, radius, tint);
    }

    private int chromeBorder() { return config.clickGuiStyle.liquidGlass ? 0x26FFFFFF : BORDER; }

    private double easeOut(double value) { return 1 - Math.pow(1 - Math.clamp(value, 0, 1), 3); }

    private String description(int index) {
        return switch (index) {
            case 2 -> "Explore freely with a detached camera";
            case 3 -> "Preview schematics and automate building";
            case 4 -> "Inspect objects, growth formations and light clues";
            case 5 -> "Keep dark places bright and clear";
            case 7 -> "Three manual milestones for your stream";
            case 8 -> "Hide your username in the sidebar scoreboard";
            case 9 -> "Adjust hotbar blur to obscure items";
            case 10 -> "Find amethyst from palette and lighting clues";
            case 11 -> "Highlight underground artificial light";
            case 12 -> "Predict emerald, coal and ancient debris from your world seed";
            case 13 -> "Warn about nearby interactions, players and machinery";
            case 15 -> "Highlight player-placed blocks deep underground";
            case 16 -> "See chests, hoppers, spawners and other block entities through walls";
            case 17 -> "Get a chat ping and a box for every spawner you load";
            case 18 -> "Flag chunks where the server hides an underground base";
            case 19 -> "Flag chunks where light or redstone changes below Y 0";
            case 20 -> "Reload chunks automatically when you go underground";
            case 21 -> "Highlight cobbled deepslate players placed underground";
            case 22 -> "Repeat /rtp until you land in a biome you chose";
            case 23 -> "See players through walls, with tracers and a nearby list";
            case 14 -> "Observe known staff and possible hidden presence";
            default -> "Move through your world with vanilla flight";
        };
    }

    private void moduleIcon(GuiGraphics g, int index, int x, int y, int tint) {
        if (index == 15) {
            outline(g, x, y + 7, 8, 8, 1, tint); outline(g, x + 9, y + 7, 8, 8, 1, tint); outline(g, x + 4, y - 1, 9, 8, 1, tint);
        } else if (index == 16) {
            outline(g, x, y + 4, 17, 12, 2, tint); line(g, x + 1f, y + 9f, x + 16f, y + 9f, tint); round(g, x + 7, y + 7, 3, 4, 1, tint);
        } else if (index == 17) {
            spawner(g, x, y, tint);
        } else if (index == 18) {
            line(g, x, y + 8, x + 8, y + 1, tint); line(g, x + 8, y + 1, x + 16, y + 8, tint);
            outline(g, x + 2, y + 8, 13, 9, 1, tint); round(g, x + 7, y + 11, 3, 6, 1, tint);
        } else if (index == 19) {
            line(g, x, y + 9, x + 4, y + 9, tint); line(g, x + 4, y + 9, x + 7, y + 2, tint); line(g, x + 7, y + 2, x + 10, y + 16, tint);
            line(g, x + 10, y + 16, x + 13, y + 9, tint); line(g, x + 13, y + 9, x + 17, y + 9, tint);
        } else if (index == 23) {
            outline(g, x + 5, y, 7, 7, 3.5f, tint); outline(g, x + 2, y + 8, 13, 9, 3, tint);
        } else if (index == 21) {
            outline(g, x + 1, y + 1, 7, 7, 1, tint); outline(g, x + 9, y + 1, 7, 7, 1, tint);
            outline(g, x + 1, y + 9, 7, 7, 1, tint); outline(g, x + 9, y + 9, 7, 7, 1, tint);
        } else if (index == 22) {
            outline(g, x + 1, y + 1, 15, 15, 7.5f, tint); line(g, x + 8, y - 1, x + 8, y + 18, tint); line(g, x - 1, y + 8, x + 18, y + 8, tint);
        } else if (index == 20) {
            outline(g, x + 1, y + 1, 15, 15, 7.5f, tint); line(g, x + 12, y, x + 16, y + 1, tint); line(g, x + 16, y + 1, x + 15, y + 5, tint);
        } else if (index == 14) {
            outline(g, x, y + 4, 18, 10, 5, tint);
            outline(g, x + 7, y + 7, 4, 4, 2, tint);
        } else if (index == 13) {
            outline(g,x,y+6,5,7,1,tint);
            line(g,x+5,y+6,x+10,y+2,tint);line(g,x+10,y+2,x+10,y+17,tint);line(g,x+10,y+17,x+5,y+13,tint);
            line(g,x+13,y+5,x+17,y+8,tint);line(g,x+17,y+8,x+13,y+13,tint);
        } else if (index == 2) camera(g, x, y, tint);
        else if (index == 3 || index == 4 || index == 12) cube(g, x, y, 12, tint, .85, .14);
        else if (index == 5) {
            outline(g, x + 4, y + 4, 9, 9, 4, tint);
            line(g, x + 8, y, x + 8, y + 2, tint);
            line(g, x + 8, y + 15, x + 8, y + 17, tint);
            line(g, x, y + 8, x + 2, y + 8, tint);
            line(g, x + 15, y + 8, x + 17, y + 8, tint);
        } else if (index == 9) {
            outline(g, x - 1, y + 5, 19, 10, 2, tint);
            for (int slot = 0; slot < 3; slot++) {
                round(g, x + 2 + slot * 5, y + 8, 3, 4, 1, tint);
            }
            line(g, x + 1, y + 17, x + 16, y + 1, tint);
        } else if (index == 8) {
            outline(g, x, y + 4, 17, 10, 5, tint);
            outline(g, x + 6, y + 7, 5, 5, 2, tint);
            line(g, x + 1, y + 17, x + 16, y + 1, tint);
        } else if (index == 7) {
            line(g, x + 8, y, x + 16, y + 4, tint);
            line(g, x + 16, y + 4, x + 16, y + 13, tint);
            line(g, x + 16, y + 13, x + 8, y + 17, tint);
            line(g, x + 8, y + 17, x, y + 13, tint);
            line(g, x, y + 13, x, y + 4, tint);
            line(g, x, y + 4, x + 8, y, tint);
        } else {
            line(g, x + 1, y + 14, x + 8, y + 3, tint);
            line(g, x + 8, y + 3, x + 16, y + 14, tint);
            line(g, x + 8, y + 3, x + 8, y + 17, tint);
        }
    }

    private dev.donut.client.config.RaidSettings.Module raid(int index) {
        return switch (index) {
            case 15 -> config.unnaturalBlocks; case 16 -> config.blockEntityEsp; case 17 -> config.spawnerNotifier;
            case 18 -> config.hiddenBase; case 19 -> config.liveActivity; case 20 -> config.chunkRefresh;
            case 21 -> config.cobbledDeepslate; case 22 -> config.rtpFinder; default -> config.playerEsp;
        };
    }

    private boolean enabled(int index) { if (index >= 15) return raid(index).enabled; return index == 14 ? config.staffDetector.enabled : index == 13 ? config.soundDetector.enabled : index == 12 ? config.blockEsp.enabled : index == 11 ? config.lightDebug.enabled : index == 10 ? config.amethyst.enabled : index == 9 ? config.hotbar.enabled : index == 8 ? config.nameHider.enabled : index == 7 ? config.progressBar.enabled : index == 6 ? FlyController.enabled() : index == 5 ? config.fullbright.enabled : index == 4 ? config.chunkFinder.enabled : index == 3 ? AutoBuilderController.get().isRunning() : index == 2 ? config.freecam.enabled : false; }
    private boolean favorite(int index) { if (index >= 15) return raid(index).favorite; return index == 14 ? config.staffDetector.favorite : index == 13 ? config.soundDetector.favorite : index == 12 ? config.blockEsp.favorite : index == 11 ? config.lightDebug.favorite : index == 10 ? config.amethyst.favorite : index == 9 ? config.hotbar.favorite : index == 8 ? config.nameHider.favorite : index == 7 ? config.progressBar.favorite : index == 6 ? config.fly.favorite : index == 5 ? config.fullbright.favorite : index == 4 ? config.chunkFinder.favorite : index == 3 ? config.autoBuilder.favorite : index == 2 ? config.freecam.favorite : false; }
    private void toggleFavorite(int index) {
        if (index >= 15) raid(index).favorite = !raid(index).favorite;
        else if (index == 14) config.staffDetector.favorite = !config.staffDetector.favorite;
        else if (index == 13) config.soundDetector.favorite = !config.soundDetector.favorite;
        else if (index == 12) config.blockEsp.favorite = !config.blockEsp.favorite;
        else if (index == 11) config.lightDebug.favorite = !config.lightDebug.favorite;
        else if (index == 10) config.amethyst.favorite = !config.amethyst.favorite;
        else if (index == 9) config.hotbar.favorite = !config.hotbar.favorite;
        else if (index == 8) config.nameHider.favorite = !config.nameHider.favorite;
        else if (index == 7) config.progressBar.favorite = !config.progressBar.favorite;
        else if (index == 6) config.fly.favorite = !config.fly.favorite;
        else if (index == 5) config.fullbright.favorite = !config.fullbright.favorite;
        else if (index == 4) config.chunkFinder.favorite = !config.chunkFinder.favorite;
        else if (index == 3) config.autoBuilder.favorite = !config.autoBuilder.favorite;
        else if (index == 2) config.freecam.favorite = !config.freecam.favorite;
        if (tab == 1) contentProgress = 0;
    }
    private void toggleEnabled(int index) {
        if (index >= 15) {
            change(() -> raid(index).enabled = !raid(index).enabled);
        } else if (index == 14) {
            change(() -> config.staffDetector.enabled = !config.staffDetector.enabled);
        } else if (index == 13) {
            change(() -> config.soundDetector.enabled = !config.soundDetector.enabled);
        } else if (index == 12) {
            change(() -> config.blockEsp.enabled = !config.blockEsp.enabled);
        } else if (index == 11) {
            change(() -> config.lightDebug.enabled = !config.lightDebug.enabled);
        } else if (index == 10) {
            change(() -> config.amethyst.enabled = !config.amethyst.enabled);
        } else if (index == 9) {
            change(() -> config.hotbar.enabled = !config.hotbar.enabled);
        } else if (index == 8) {
            change(() -> config.nameHider.enabled = !config.nameHider.enabled);
        } else if (index == 7) {
            change(() -> config.progressBar.enabled = !config.progressBar.enabled);
        } else if (index == 6) {
            FlyController controller = FlyController.getInstance();
            if (controller != null) controller.setEnabled(!FlyController.enabled());
        } else if (index == 5) {
            change(() -> config.fullbright.enabled = !config.fullbright.enabled);
        } else if (index == 4) {
            change(() -> config.chunkFinder.enabled = !config.chunkFinder.enabled);
        } else if (index == 3) {
            if (AutoBuilderController.get().isRunning()) AutoBuilderController.get().pause();
            flush();
            minecraft.setScreen(new AutoBuilderScreen(this, config, save));
        } else if (index == 2) {
            if (config.freecam.enabled || canUseFreecam()) config.freecam.enabled = !config.freecam.enabled;
        }
    }
    private String name(int index) {
        return switch (index) { case 2 -> "Freecam"; case 4 -> "Base Finder"; case 5 -> "Fullbright"; case 6 -> "Fly"; case 7 -> "Progress Bar"; case 8 -> "Name Hider"; case 9 -> "Hotbar"; case 10 -> "Amethyst Scanner"; case 11 -> "Light Debug"; case 12 -> "BlockESP"; case 13 -> "Sound Detector"; case 14 -> "Staff Detector";
            case 15 -> "Unnatural Blocks"; case 16 -> "Block Entity ESP"; case 17 -> "Spawner Notifier"; case 18 -> "Hidden Base Detector";
            case 19 -> "Live Activity"; case 20 -> "Chunk Refresh";
            case 21 -> "Cobbled Deepslate"; case 22 -> "RTP Biome Finder"; case 23 -> "Player ESP"; default -> "AutoBuilder"; };
    }

    private void drawHotbarSettings(GuiGraphics g, int ignored) {
        section(g, "Hotbar privacy", 0);
        settingToggle(g, "hideHeldItems", "Hide held items", 0,
                () -> config.hotbar.hideHeldItems, () -> config.hotbar.hideHeldItems = !config.hotbar.hideHeldItems);
        help(g, "Show empty hands in first person and on your local avatar. Item use stays normal.");
        help(g, "Local display only. Other players still see your real equipment.");
        slider(g, "blurAmount", "Blur amount", 0, () -> config.hotbar.blurPercent,
                value -> config.hotbar.blurPercent = (int) Math.round(value), 0, dev.donut.client.config.HotbarSettings.MAX_BLUR_PERCENT, 1, "%");
        help(g, "Choose 0% for a clear hotbar or 140% for the strongest blur.");
        help(g, "Blurs item names, hotbar items, counts and the offhand slot.");
    }

    private void drawNameHiderSettings(GuiGraphics g, int ignored) {
        section(g, "Sidebar privacy", 0);
        settingToggle(g, "blurScoreboard", "Blur entire scoreboard", 0,
                () -> config.nameHider.blurScoreboard, () -> config.nameHider.blurScoreboard = !config.nameHider.blurScoreboard);
        help(g, config.nameHider.blurScoreboard ? "Blurs the whole sidebar, including every name, title and score."
                : "Hides your username in sidebar titles, rows and scores.");
        help(g, "Disable the module to restore the original scoreboard.");
    }

    private void drawProgressBarSettings(GuiGraphics g, int ignored) {
        section(g, "Overlay style", 0);
        slider(g, "overlayScale", "Overlay size", 0, () -> config.progressBar.scale,
                value -> config.progressBar.scale = value,
                ProgressBarSettings.MIN_SCALE, ProgressBarSettings.MAX_SCALE, .05, "%");
        settingToggle(g, "shinyOutline", "Shiny outline", 0, () -> config.progressBar.shinyOutline,
                () -> config.progressBar.shinyOutline = !config.progressBar.shinyOutline);
        help(g, "Animated frame on; empty background off.");
        section(g, "Base counter", 0);
        basesFoundRow(g, 0);
        section(g, "Countdowns", 0);
        for (int stage = 0; stage < 3; stage++) timerRow(g, stage, 0);
        help(g, timerError >= 0 ? "Use HH:MM:SS, from 00:00:01 to 99:59:59."
                : "Set HH:MM:SS, for example 01:00:00 for one hour.");
        section(g, "Manual progress", 0);
        String[] labels = {"Overworld", "Nether", "End"};
        for (int i = 0; i < 3; i++) {
            int stage = i + 1;
            settingToggle(g, "stage" + stage, stage + "  " + labels[i], 0,
                    () -> config.progressBar.completedStages >= stage,
                    () -> config.progressBar.completedStages = config.progressBar.completedStages >= stage ? stage - 1 : stage);
        }
        help(g, "Select a milestone; select a marked one to undo it.");
        button(g, "m7.moveOverlay", "Move overlay", rowX, settingsCursor, rowW, s(32), () -> {
            flush();
            minecraft.setScreen(new ProgressBarEditorScreen(this, config, save));
        });
        settingsCursor += s(42);
        button(g, "m7.resetProgress", "Reset progress", rowX, settingsCursor, rowW, s(32),
                () -> change(() -> config.progressBar.completedStages = 0));
        settingsCursor += s(42);
    }

    private void timerRow(GuiGraphics g, int stage, int ignored) {
        String[] names = {"Overworld", "Nether", "End"};
        boolean running = ProgressTimers.isRunning(config, stage);
        long remaining = ProgressTimers.remainingMillis(config, stage);
        int y = settingsCursor;
        text(g, font, names[stage], rowX, y, CONTROL_TEXT);
        right(g, font, ProgressTimers.formattedTime(config, stage), rowX + rowW, y,
                remaining == 0 ? 0xFFFF818A : CONTROL_MUTED);
        y += s(24);
        int x = rowX, durationW = Math.min(s(116), rowW * 38 / 100);
        int gap = s(8), actionW = (rowW - durationW - gap * 2) / 2;
        boolean focused = editingTimer == stage;
        surface(g, x, y, durationW, s(30), s(7), CONTROL, 0.78f);
        outline(g, x, y, durationW, s(30), s(7), alpha(timerError == stage ? 0xFF818A : config.accentColor, focused ? .8 : .15));
        if (focused && replaceTimerDuration) round(g, x + s(6), y + s(4), durationW - s(12), s(21), s(3), alpha(config.accentColor, .25));
        String value = focused ? timerDurationDraft : CountdownDuration.format(config.progressBar.timers[stage].durationSeconds);
        if (focused && !replaceTimerDuration && System.currentTimeMillis() % 1000 < 500) value += "|";
        text(g, font, value, x + s(8), y + s(7), CONTROL_TEXT);
        hit("m7.timerDuration" + stage, x, y, durationW, s(30), () -> {
            editingTimer = stage;
            timerDurationDraft = CountdownDuration.format(config.progressBar.timers[stage].durationSeconds);
            replaceTimerDuration = true;
            timerError = -1;
            keyboardFocus = "m7.timerDuration" + stage;
        });
        String action = running ? "Pause" : remaining == 0 ? "Restart"
                : remaining < config.progressBar.timers[stage].durationSeconds * 1000L ? "Resume" : "Start";
        button(g, "m7.timerStart" + stage, action, x + durationW + gap, y, actionW, s(30), () -> change(() -> {
            if (ProgressTimers.isRunning(config, stage)) ProgressTimers.pause(config, stage);
            else ProgressTimers.start(config, stage);
        }));
        button(g, "m7.timerReset" + stage, "Reset", x + durationW + actionW + gap * 2, y, actionW, s(30),
                () -> change(() -> ProgressTimers.reset(config, stage)));
        settingsCursor += s(74);
    }

    private boolean commitTimerDuration() {
        if (editingTimer < 0) return true;
        var duration = CountdownDuration.parse(timerDurationDraft);
        if (duration.isEmpty()) { timerError = editingTimer; return false; }
        int stage = editingTimer, seconds = duration.getAsInt();
        cancelTimerDuration();
        timerError = -1;
        if (config.progressBar.timers[stage].durationSeconds != seconds) {
            change(() -> ProgressTimers.setDurationSeconds(config, stage, seconds));
        }
        return true;
    }

    private void cancelTimerDuration() {
        editingTimer = -1;
        timerDurationDraft = null;
        replaceTimerDuration = false;
    }

    private void basesFoundRow(GuiGraphics g, int ignored) {
        int y = settingsCursor;
        text(g, font, "Bases found", rowX, y, CONTROL_TEXT);
        y += s(24);
        int side = s(30), gap = s(8), valueX = rowX + side + gap, valueW = rowW - 2 * (side + gap);
        for (int direction : new int[] {-1, 1}) {
            int x = direction < 0 ? rowX : rowX + rowW - side;
            button(g, "m7.basesFound" + (direction < 0 ? "Minus" : "Plus"), direction < 0 ? "-" : "+",
                    x, y, side, side, () -> change(() -> config.progressBar.basesFound = Math.clamp(
                            config.progressBar.basesFound + direction, 0, ProgressBarSettings.MAX_BASES_FOUND)));
        }
        boolean focused = basesFoundDraft != null;
        surface(g, valueX, y, valueW, side, s(7), CONTROL, 0.78f);
        if (focused) outline(g, valueX, y, valueW, side, s(7), alpha(config.accentColor, .85));
        String shown = focused ? basesFoundDraft : Integer.toString(config.progressBar.basesFound);
        if (focused && replaceBasesFound) round(g, valueX + s(6), y + s(4), valueW - s(12), s(21), s(3), alpha(config.accentColor, .25));
        shown = ellipsize(shown, valueW - s(22));
        if (focused && !replaceBasesFound && System.currentTimeMillis() % 1000 < 500) shown += "|";
        text(g, font, shown, valueX + s(10), y + s(7), CONTROL_TEXT);
        hit("m7.basesFound", valueX, y, valueW, side, () -> {
            basesFoundDraft = Integer.toString(config.progressBar.basesFound);
            replaceBasesFound = true;
            keyboardFocus = "m7.basesFound";
        });
        settingsCursor += s(70);
    }

    private int enteredBasesFound() {
        if (basesFoundDraft == null || basesFoundDraft.isEmpty()) return 0;
        return (int) Math.clamp(Long.parseLong(basesFoundDraft), 0, ProgressBarSettings.MAX_BASES_FOUND);
    }

    private void commitBasesFound() {
        if (basesFoundDraft == null) return;
        int next = enteredBasesFound();
        basesFoundDraft = null;
        replaceBasesFound = false;
        if (config.progressBar.basesFound != next) change(() -> config.progressBar.basesFound = next);
    }

    private void drawFlySettings(GuiGraphics g, int ignored) {
        section(g, "Vanilla flight", 0);
        help(g, "Vanilla flight");
        section(g, "Your controls", 0);
        controlHint(g, "Move", keyName(minecraft.options.keyUp) + " / " + keyName(minecraft.options.keyLeft)
                + " / " + keyName(minecraft.options.keyDown) + " / " + keyName(minecraft.options.keyRight), 0);
        controlHint(g, "Up / down", keyName(minecraft.options.keyJump) + " / " + keyName(minecraft.options.keyShift), 0);
        controlHint(g, "Sprint", keyName(minecraft.options.keySprint), 0);
        help(g, "Server rules may restrict flight.");
    }

    private void drawFullbrightSettings(GuiGraphics g, int ignored) {
        section(g, "Brightness", 0);
        controlHint(g, "Gamma", "1000", 0);
    }

    private void soundButton(GuiGraphics g, String id, String label, Runnable action) {
        button(g,"m13."+id,label,rowX,settingsCursor,rowW,s(32),action);
        settingsCursor+=s(40);
    }

    private void drawSoundDetectorSettings(GuiGraphics g) {
        var value=config.soundDetector;
        section(g,"Detection",0);
        soundButton(g,"preset","Preset: "+value.preset,()->change(()->{
            var presets=dev.donut.client.config.SoundDetectorSettings.PRESETS;
            value.applyPreset(presets.get((presets.indexOf(value.preset)+1)%presets.size()));
        }));
        slider(g,"range","Received-event range",0,()->value.range,next->value.range=next,0,512,1," blocks");
        help(g,"Filters received events only. Villager sounds are normally nearby; block events can reach farther.");
        slider(g,"threshold","Warning threshold",0,()->value.warningThreshold,next->{value.warningThreshold=(int)next;value.criticalThreshold=Math.max(value.criticalThreshold,value.warningThreshold);},1,100,1," points");
        if(value.warningThreshold<100)slider(g,"critical","Critical threshold",0,()->value.criticalThreshold,next->value.criticalThreshold=(int)next,value.warningThreshold,100,1," points");
        else help(g,"Critical threshold: 100 points.");
        settingToggle(g,"playersOnly","Require identified player",0,()->value.playersOnly,()->value.playersOnly=!value.playersOnly);
        settingToggle(g,"self","Filter own actions",0,()->value.suppressSelf,()->value.suppressSelf=!value.suppressSelf);
        settingToggle(g,"probableSelf","Filter probable own actions",0,()->value.suppressProbableSelf,()->value.suppressProbableSelf=!value.suppressProbableSelf);
        settingToggle(g,"nonPlayers","Filter known mobs",0,()->value.ignoreNonPlayers,()->value.ignoreNonPlayers=!value.ignoreNonPlayers);
        settingToggle(g,"clientDerived","Include client-derived sounds",0,()->value.includeClientDerived,()->value.includeClientDerived=!value.includeClientDerived);
        help(g,"An unknown sound never receives a player name based on proximity.");
        section(g,"Sources",0);
        for(String category:dev.donut.client.config.SoundDetectorSettings.CATEGORIES)
            settingToggle(g,"source."+category,SoundSettingsScreen.label(category),0,()->value.categoryEnabled(category),()->value.categories.put(category,!value.categoryEnabled(category)));
        section(g,"Warning delivery",0);
        settingToggle(g,"popup","Warning cards",0,()->value.popup,()->value.popup=!value.popup);
        settingToggle(g,"chime","Local warning chime",0,()->value.chime,()->value.chime=!value.chime);
        settingToggle(g,"chat","Chat notices",0,()->value.chat,()->value.chat=!value.chat);
        settingToggle(g,"markers","World markers",0,()->value.worldMarkers,()->value.worldMarkers=!value.worldMarkers);
        slider(g,"duration","Card duration",0,()->value.durationSeconds,next->value.durationSeconds=next,1,60,1," sec");
        slider(g,"maxCards","Visible cards",0,()->value.maxCards,next->value.maxCards=(int)next,1,5,1,"");
        slider(g,"cooldown","Source cooldown",0,()->value.cooldownSeconds,next->value.cooldownSeconds=next,.1,60,.1," sec");
        settingToggle(g,"menus","Show while in menus",0,()->value.showInMenus,()->value.showInMenus=!value.showInMenus);
        settingToggle(g,"respectHud","Respect global HUD toggle",0,()->value.respectHud,()->value.respectHud=!value.respectHud);
        section(g,"Preview and appearance",0);
        soundButton(g,"previewWarning","Preview warning / move alert",()->{flush();minecraft.setScreen(new SoundAlertEditorScreen(this,config,save,false));});
        soundButton(g,"previewCritical","Preview critical alert",()->{flush();minecraft.setScreen(new SoundAlertEditorScreen(this,config,save,true));});
        slider(g,"scale","Card scale",0,()->value.scale,next->value.scale=next,.5,2,.05,"%");
        slider(g,"opacity","Background opacity",0,()->value.opacity,next->value.opacity=next,.05,1,.01,"%");
        colorRow(g,"Warning accent",0,()->value.warningColor,next->value.warningColor=next);
        colorRow(g,"Critical accent",0,()->value.criticalColor,next->value.criticalColor=next);
        colorRow(g,"Card top",0,()->value.topColor,next->value.topColor=next);
        colorRow(g,"Card bottom",0,()->value.bottomColor,next->value.bottomColor=next);
        slider(g,"volume","Chime volume",0,()->value.volume,next->value.volume=next,0,1,.01,"%");
        soundButton(g,"allSettings","All appearance, audio and behavior controls",()->{flush();minecraft.setScreen(new SoundSettingsScreen(this,config,save));});
        section(g,"Rules, history and profiles",0);
        soundButton(g,"rules","Custom rules / expected areas",()->{flush();minecraft.setScreen(new SoundRulesScreen(this,config,save));});
        soundButton(g,"history","Activity history and evidence",()->{flush();minecraft.setScreen(new SoundHistoryScreen(this,config));});
        soundButton(g,"mute","Mute notifications for 60 seconds",()->{var controller=dev.donut.client.sound.SoundDetectorController.get();if(controller!=null){controller.mute(60);soundStatus="Notifications muted for 60 seconds. Observation continues.";}});
        soundButton(g,"saveProfile","Save current server profile",()->{var controller=dev.donut.client.sound.SoundDetectorController.get();if(controller!=null){controller.saveProfile();save.run();soundStatus="Saved current server preferences.";}});
        soundButton(g,"loadProfile","Load current server profile",()->{var controller=dev.donut.client.sound.SoundDetectorController.get();if(controller!=null){boolean loaded=controller.loadProfile();save.run();soundStatus=loaded?"Loaded this server's saved preferences.":"No saved preferences for this server.";}});
        section(g,"Diagnostics",0);
        soundButton(g,"exportCatalog","Export full block / sound coverage",()->{var controller=dev.donut.client.sound.SoundDetectorController.get();if(controller!=null)try{soundStatus="Exported "+controller.exportCatalog().getFileName();}catch(Exception e){soundStatus="Export failed: "+e.getMessage();}});
        soundButton(g,"advanced","Advanced preferences / import / export",()->{flush();minecraft.setScreen(new SoundSettingsJsonScreen(this,config,save));});
        help(g,soundStatus);
    }

    private void drawStaffDetectorSettings(GuiGraphics g) {
        var value = config.staffDetector;
        section(g, "Staff identity", 0);
        button(g, "m14.roster", "Staff list / evidence", rowX, settingsCursor, rowW, s(34), () -> {
            flush(); minecraft.setScreen(new StaffRosterScreen(this, config, save));
        });
        settingsCursor += s(44);
        help(g, "Add usernames or UUIDs for the current server. Usernames bind to UUIDs when observed.");
        section(g, "Observations", 0);
        settingToggle(g, "spectatorAlerts", "Spectator alerts", 0, () -> value.spectatorAlerts, () -> value.spectatorAlerts = !value.spectatorAlerts);
        settingToggle(g, "invisibilityAlerts", "Invisible nearby alerts", 0, () -> value.invisibilityAlerts, () -> value.invisibilityAlerts = !value.invisibilityAlerts);
        settingToggle(g, "anySpectator", "Alert for any spectator", 0, () -> value.anySpectator, () -> value.anySpectator = !value.anySpectator);
        help(g, "Reports every player the server shows in spectator mode, not only the staff in your list. Nearby spectators also count as hidden presence.");
        slider(g, "nearbyRange", "Nearby range", 0, () -> value.nearbyRange, next -> value.nearbyRange = (int) next, 8, 256, 1, " blocks");
        settingToggle(g, "completionChecks", "Check /msg completions", 0, () -> value.completionChecks, () -> value.completionChecks = !value.completionChecks);
        help(g, "Sends completion requests only. Repeated tab discrepancies suggest possible hidden presence. Suggestions can be filtered or stale.");
        if (value.completionChecks) {
            slider(g, "completionIntervalSeconds", "Check interval", 0, () -> value.completionIntervalSeconds, next -> value.completionIntervalSeconds = (int) next, 6, 120, 1, "s");
            slider(g, "requiredSamples", "Matching samples", 0, () -> value.requiredSamples, next -> value.requiredSamples = (int) next, 2, 10, 1, "");
        }
        settingToggle(g, "rosterAlerts", "Roster removal alerts", 0, () -> value.rosterAlerts, () -> value.rosterAlerts = !value.rosterAlerts);
        help(g, "Removal hints wait 8 seconds. Logouts, transfers and vanish remain indistinguishable.");
        settingToggle(g, "watchSelf", "Test mode: include myself", 0, () -> value.watchSelf, () -> value.watchSelf = !value.watchSelf);
        help(g, "Normally you never watch yourself. Turn this on to try the module alone in single-player (for example, /gamemode spectator), then turn it off.");
        section(g, "Display", 0);
        settingToggle(g, "showHud", "Presence HUD", 0, () -> value.showHud, () -> value.showHud = !value.showHud);
        settingToggle(g, "chatAlerts", "Chat alerts", 0, () -> value.chatAlerts, () -> value.chatAlerts = !value.chatAlerts);
        slider(g, "maxHudRows", "HUD staff rows", 0, () -> value.maxHudRows, next -> value.maxHudRows = (int) next, 1, 8, 1, "");
        slider(g, "evidenceSeconds", "Hint lifetime", 0, () -> value.evidenceSeconds, next -> value.evidenceSeconds = (int) next, 10, 180, 1, "s");
        slider(g, "alertCooldownSeconds", "Alert cooldown", 0, () -> value.alertCooldownSeconds, next -> value.alertCooldownSeconds = (int) next, 10, 300, 1, "s");
        var controller = dev.donut.client.staff.StaffDetectorController.get();
        help(g, controller != null && controller.uses(config) ? controller.status() : "Hidden presence is unknown. No signal proves someone is watching you.");
    }

    private String soundStatus = "Capture received activity. Range does not request distant sounds.";


    private void drawBlockEspSettings(GuiGraphics g) {
        var value = config.blockEsp;
        section(g, "World seed", 0);
        button(g, "m12.seed", "Edit world seed", rowX, settingsCursor, rowW, s(34), () -> {
            flush(); minecraft.setScreen(new BlockEspSeedScreen(this, config, save));
        });
        settingsCursor += s(44);
        help(g, value.seed + " | Vanilla Java 1.21.11");
        blockList(g, value, "m12");

        section(g, "Display", 0);
        slider(g, "radius", "Prediction radius", 0, () -> value.radius, next -> value.radius = (int) next, 1, 16, 1, " chunks");
        if (value.radius > 8) help(g, "Large radius: " + (value.radius * 2 + 1) * (value.radius * 2 + 1) + " chunks to predict. The first scan of an area can take a few minutes; nearest chunks come first.");
        slider(g, "opacity", "Opacity", 0, () -> value.opacity, next -> value.opacity = (int) next, 0, 255, 1, "");
        settingToggle(g, "tracers", "Tracers", 0, () -> value.tracers, () -> value.tracers = !value.tracers);
        settingToggle(g, "showHud", "Coordinates / distance HUD", 0, () -> value.showHud, () -> value.showHud = !value.showHud);
        settingToggle(g, "showMined", "Show already-mined spots", 0, () -> value.showMined, () -> value.showMined = !value.showMined);
        if (value.showMined) colorRow(g, "Mined spot color", 0, () -> value.minedColor, next -> value.minedColor = next);
        help(g, "When the server shows air where an ore was predicted, it was mined or the prediction is off. These spots stay as small grey boxes instead of vanishing.");
        section(g, "Predictions", 0);
        var controller = dev.donut.client.blockesp.BlockEspController.get();
        help(g, controller == null ? "Enable BlockESP in a world to predict blocks." : controller.status());
        button(g, "m12.rescan", "Rescan predictions", rowX, settingsCursor, rowW, s(34), () -> {
            var current = dev.donut.client.blockesp.BlockEspController.get();
            if (current != null) current.rescan();
        });
        settingsCursor += s(44);
        help(g, "Predicts where each target block was originally generated in the Overworld, Nether or End. Match the version that generated the chunks. Blocks may already be mined; common blocks show only the nearest " + dev.donut.client.blockesp.BlockEspController.MAX_SHOWN_MARKERS + ".");
    }

    private String blockDraft;
    private static final int MAX_SUGGESTIONS = 6;

    private static String targetId(String block) {
        return switch (block) {
            case dev.donut.client.config.BlockEspSettings.EMERALD -> "emerald";
            case dev.donut.client.config.BlockEspSettings.COAL -> "coal";
            case dev.donut.client.config.BlockEspSettings.DEBRIS -> "debris";
            default -> "target." + block;
        };
    }

    private static String blockLabel(String id) {
        var block = dev.donut.client.blockesp.BlockEspController.resolve(id);
        return block == null ? id + " (unknown)" : block.getName().getString();
    }

    /** One target: color swatch, block name, on/off switch and a remove button. */
    /** Block list shared by BlockESP and Unnatural Blocks: rows, an add field and a reset button. */
    private void blockList(GuiGraphics g, dev.donut.client.config.BlockTargetList list, String prefix) {
        pickerList = list;
        biomePicker = false;
        section(g, "Target blocks", 0);
        var targets = list.targets();
        for (int i = 0; i < targets.size(); i++) targetRow(g, targets.get(i));
        if (targets.isEmpty()) help(g, "No blocks yet. Add any block below.");
        blockPicker(g);
        button(g, prefix + ".resetTargets", "Restore default blocks", rowX, settingsCursor, rowW, s(32),
                () -> change(list::resetTargets));
        settingsCursor += s(42);
    }

    private dev.donut.client.config.BlockTargetList pickerList;

    private void targetRow(GuiGraphics g, dev.donut.client.config.BlockEspSettings.Target target) {
        int y = settingsCursor, rowH = s(44), id0 = 0;
        String id = targetId(target.block);
        double hover = animate("settingHover" + rowPrefix + id, inside(rowX, y, rowW, rowH) ? 1 : 0);
        round(g, rowX - s(8), y + s(2), rowW + s(16), rowH - s(4), corner(10), alpha(0xFFFFFF, .035 * hover));
        int sw = s(18), sy = y + (rowH - sw) / 2;
        round(g, rowX, sy, sw, sw, corner(6), alpha(target.color, 1));
        outline(g, rowX, sy, sw, sw, corner(6), alpha(0xFFFFFF, inside(rowX, sy, sw, sw) ? .45 : .15));
        hit(rowPrefix + "color" + id, rowX, sy, sw, sw, () -> {
            colorEditor = new ColorEditor(blockLabel(target.block), () -> target.color, next -> target.color = next);
            modalProgress = 0; keyboardFocus = null; scannerMethodMenu = false;
        });
        int removeW = s(24), toggleW = s(38), toggleX = rowX + rowW - removeW - s(6) - toggleW;
        String label = ellipsize(blockLabel(target.block), toggleX - rowX - sw - s(18));
        text(g, font, label, rowX + sw + s(10), y + (rowH - s(16)) / 2, target.enabled ? CONTROL_TEXT : CONTROL_MUTED);
        double on = animate("settingToggle" + rowPrefix + id, target.enabled ? 1 : 0);
        int trackH = s(20), trackY = y + (rowH - trackH) / 2;
        surface(g, toggleX, trackY, toggleW, trackH, trackH / 2f, blend(TRACK, accent(), on), 0.62f);
        float r = 7f * fontScale, knobX = toggleX + s(10) + (float) on * s(18), knobY = trackY + trackH / 2f;
        round(g, knobX - r, knobY - r, r * 2, r * 2, r, blend(0xFFB4B8D6, 0xFFFFFFFF, on));
        hit(rowPrefix + id, rowX + sw + s(4), y, toggleX + toggleW - rowX - sw - s(4), rowH, () -> change(() -> target.enabled = !target.enabled));
        int rx = rowX + rowW - removeW, ry = y + (rowH - removeW) / 2;
        double removeHover = animate("remove" + rowPrefix + id, inside(rx, ry, removeW, removeW) ? 1 : 0);
        round(g, rx, ry, removeW, removeW, corner(7), alpha(0xFFFF5C7A, .06 + removeHover * .18));
        int xc = blend(DIM, 0xFFFF5C7A, removeHover);
        line(g, rx + removeW * .35f, ry + removeW * .35f, rx + removeW * .65f, ry + removeW * .65f, xc);
        line(g, rx + removeW * .65f, ry + removeW * .35f, rx + removeW * .35f, ry + removeW * .65f, xc);
        hit(rowPrefix + "remove." + id, rx, ry, removeW, removeW, () -> { var owner = pickerList; change(() -> owner.removeTarget(target.block)); });
        settingsCursor += rowH + id0;
    }

    /** Search field plus clickable registry suggestions for adding any block. */
    private void blockPicker(GuiGraphics g) {
        int y = settingsCursor + s(4), h = s(34);
        boolean editing = blockDraft != null;
        surface(g, rowX, y, rowW, h, corner(9), editing ? FIELD : CONTROL, 0.8f);
        outline(g, rowX, y, rowW, h, corner(9), editing ? alpha(config.accentColor, .8) : HAIRLINE);
        int px = rowX + s(14), py = y + h / 2;
        line(g, px - 5f, py, px + 5f, py, editing ? accent() : CONTROL_MUTED);
        line(g, px, py - 5f, px, py + 5f, editing ? accent() : CONTROL_MUTED);
        String shown = !editing ? (biomePicker ? "Add a biome (name or ID)" : "Add a block (name or ID)")
                : blockDraft + (System.currentTimeMillis() % 1000 < 500 ? "|" : "");
        text(g, font, ellipsize(shown, rowW - s(40)), rowX + s(30), y + (h - s(16)) / 2,
                editing && !blockDraft.isEmpty() ? CONTROL_TEXT : CONTROL_MUTED);
        hit(rowPrefix + "addBlock", rowX, y, rowW, h, () -> { blockDraft = ""; keyboardFocus = null; searchFocused = false; });
        settingsCursor += h + s(10);
        if (!editing) return;
        var suggestions = blockSuggestions(blockDraft);
        if (suggestions.isEmpty()) {
            help(g, blockDraft.isEmpty() ? (biomePicker ? "Type to search every biome." : "Type to search every block in the game.")
                    : biomePicker ? "No matching biome." : "No matching block.");
            return;
        }
        for (int i = 0; i < suggestions.size(); i++) {
            String id = suggestions.get(i);
            int sy = settingsCursor, sh = s(30);
            boolean hover = inside(rowX, sy, rowW, sh);
            if (hover || i == 0) round(g, rowX, sy, rowW, sh, corner(8), alpha(config.accentColor, hover ? .2 : .1));
            text(g, font, ellipsize(biomePicker ? dev.donut.client.rtp.RtpBiomeFinder.label(id) : blockLabel(id), rowW / 2), rowX + s(10), sy + (sh - s(16)) / 2, CONTROL_TEXT);
            String raw = id.startsWith("minecraft:") ? id.substring(10) : id;
            String rawShown = ellipsizeSmall(raw, rowW / 2 - s(20));
            smallText(g, font, rawShown, rowX + rowW - s(10) - WorkspacePaint.smallWidth(font, rawShown), sy + s(9), DIM);
            hit(rowPrefix + "suggest" + i, rowX, sy, rowW, sh, () -> addBlock(id));
            settingsCursor += sh + s(2);
        }
        settingsCursor += s(8);
        help(g, biomePicker ? "Enter adds the highlighted biome. Esc cancels." : "Enter adds the highlighted block. Esc cancels.");
    }

    /** Every biome as a toggle chip: click as many as you like. The field filters the grid. */
    private void biomeGrid(GuiGraphics g, dev.donut.client.config.RaidSettings.RtpFinder value) {
        biomePicker = true;
        pickerList = null;
        int count = value.biomes.size();
        String summary = count == 0 ? "Click biomes to select them" : count + (count == 1 ? " biome selected" : " biomes selected");
        smallText(g, font, summary, rowX, settingsCursor + s(4), count == 0 ? DIM : accentText());
        if (count > 0) {
            String clear = "Clear all";
            int cw = WorkspacePaint.smallWidth(font, clear) + s(16), cx = rowX + rowW - cw;
            double hover = animate("biomeClear", inside(cx, settingsCursor, cw, s(20)) ? 1 : 0);
            round(g, cx, settingsCursor, cw, s(20), s(10), alpha(0xFFFF5C7A, .08 + hover * .16));
            smallText(g, font, clear, cx + s(8), settingsCursor + s(4), blend(MUTED, 0xFFFF7A8C, hover));
            hit(rowPrefix + "biomeClear", cx, settingsCursor, cw, s(20), () -> change(value.biomes::clear));
        }
        settingsCursor += s(28);

        // Filter field (shares the picker's text input).
        int fy = settingsCursor, fh = s(32);
        boolean editing = blockDraft != null;
        surface(g, rowX, fy, rowW, fh, corner(9), editing ? FIELD : CONTROL, 0.8f);
        outline(g, rowX, fy, rowW, fh, corner(9), editing ? alpha(config.accentColor, .8) : HAIRLINE);
        search(g, rowX + s(12), fy + (fh - 10) / 2, editing ? accent() : CONTROL_MUTED);
        String shown = editing ? blockDraft + (System.currentTimeMillis() % 1000 < 500 ? "|" : "") : "Filter biomes";
        text(g, font, ellipsize(shown, rowW - s(44)), rowX + s(32), fy + (fh - s(16)) / 2,
                editing && !blockDraft.isEmpty() ? CONTROL_TEXT : CONTROL_MUTED);
        hit(rowPrefix + "addBlock", rowX, fy, rowW, fh, () -> { if (blockDraft == null) blockDraft = ""; keyboardFocus = null; searchFocused = false; });
        settingsCursor += fh + s(10);

        // Chips, wrapped to the panel width; selected biomes are filled with the accent.
        String filter = blockDraft == null ? "" : blockDraft.trim().toLowerCase(Locale.ROOT);
        int chipH = s(26), gap = s(6), x = rowX, y = settingsCursor, shownChips = 0;
        for (String id : dev.donut.client.rtp.RtpBiomeFinder.allBiomes()) {
            String label = dev.donut.client.rtp.RtpBiomeFinder.label(id);
            if (!filter.isEmpty() && !label.toLowerCase(Locale.ROOT).contains(filter) && !id.contains(filter.replace(' ', '_'))) continue;
            boolean on = value.biomes.contains(id);
            int w = Math.min(rowW, WorkspacePaint.smallWidth(font, label) + s(on ? 30 : 20));
            if (x + w > rowX + rowW) { x = rowX; y += chipH + gap; }
            double hover = animate("biomeChip" + id, inside(x, y, w, chipH) ? 1 : 0);
            double pick = animate("biomeOn" + id, on ? 1 : 0);
            round(g, x, y, w, chipH, chipH / 2f, blend(blend(CONTROL, CONTROL_HOVER, hover), accent(), pick * .85));
            outline(g, x, y, w, chipH, chipH / 2f, blend(alpha(0xFFFFFF, .06 + hover * .08), alpha(0xFFFFFF, .25), pick));
            int tx = x + s(10);
            if (on) {
                int cx = x + s(9), cy = y + chipH / 2;
                line(g, cx, cy, cx + s(3), cy + s(3), inkOn(config.accentColor));
                line(g, cx + s(3), cy + s(3), cx + s(8), cy - s(3), inkOn(config.accentColor));
                tx = x + s(20);
            }
            smallText(g, font, label, tx, y + (chipH - s(11)) / 2f, on ? inkOn(config.accentColor) : MUTED);
            hit(rowPrefix + "biome." + id.substring(id.indexOf(':') + 1), x, y, w, chipH,
                    () -> change(() -> { if (!value.biomes.remove(id)) value.addBiome(id); }));
            x += w + gap;
            shownChips++;
        }
        settingsCursor = y + (shownChips == 0 ? 0 : chipH) + s(10);
        if (shownChips == 0) help(g, "No biome matches \"" + filter + "\".");
        help(g, "Select every biome you are happy with: the search stops at the first one it finds.");
    }

    /** True while the shared picker adds biomes (RTP Biome Finder) instead of blocks. */
    private boolean biomePicker;

    private List<String> biomeSuggestions(String q) {
        var scored = new ArrayList<Map.Entry<String, Integer>>();
        for (String id : dev.donut.client.rtp.RtpBiomeFinder.allBiomes()) {
            if (config.rtpFinder.biomes.contains(id)) continue;
            String path = id.substring(id.indexOf(':') + 1), name = dev.donut.client.rtp.RtpBiomeFinder.label(id).toLowerCase(Locale.ROOT);
            int score;
            if (path.equals(q) || name.equals(q)) score = 0;
            else if (path.startsWith(q.replace(' ', '_')) || name.startsWith(q)) score = 1;
            else if (path.contains(q.replace(' ', '_')) || name.contains(q)) score = 2;
            else continue;
            scored.add(Map.entry(id, score * 1000 + path.length()));
        }
        scored.sort(Map.Entry.comparingByValue());
        var result = new ArrayList<String>();
        for (int i = 0; i < Math.min(MAX_SUGGESTIONS, scored.size()); i++) result.add(scored.get(i).getKey());
        return result;
    }

    private List<String> blockSuggestions(String query) {
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return List.of();
        if (biomePicker) return biomeSuggestions(q);
        var scored = new ArrayList<Map.Entry<String, Integer>>();
        for (var block : net.minecraft.core.registries.BuiltInRegistries.BLOCK) {
            if (block == net.minecraft.world.level.block.Blocks.AIR) continue;
            String id = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(block).toString();
            if (pickerList != null && pickerList.find(id) != null) continue;
            String path = id.substring(id.indexOf(':') + 1), name = block.getName().getString().toLowerCase(Locale.ROOT);
            int score;
            if (path.equals(q) || name.equals(q) || id.equals(q)) score = 0;
            else if (path.startsWith(q) || name.startsWith(q)) score = 1;
            else if (path.contains(q.replace(' ', '_')) || name.contains(q)) score = 2;
            else continue;
            scored.add(Map.entry(id, score * 1000 + path.length()));
        }
        scored.sort(Map.Entry.comparingByValue());
        var result = new ArrayList<String>();
        for (int i = 0; i < Math.min(MAX_SUGGESTIONS, scored.size()); i++) result.add(scored.get(i).getKey());
        return result;
    }

    private void addBlock(String id) {
        if (biomePicker) change(() -> config.rtpFinder.addBiome(id));
        else if (pickerList != null) change(() -> pickerList.addTarget(id));
        blockDraft = null;
    }

    private void commitBlockDraft() {
        if (blockDraft == null) return;
        var suggestions = blockSuggestions(blockDraft);
        if (!suggestions.isEmpty()) addBlock(suggestions.getFirst());
    }

    /** Settings for the Base Raid / Donut detection modules (15-20). */
    private void drawRaidSettings(GuiGraphics g, int index) {
        var engine = dev.donut.client.raid.RaidModules.get();
        switch (index) {
            case 15 -> {
                var value = config.unnaturalBlocks;
                section(g, "How it works", 0);
                help(g, "Marks blocks that terrain generation does not place deep underground, like rotated deepslate, planks, glass and torches. Mineshafts, ancient cities and trial chambers can still show a few.");
                section(g, "Where to look", 0);
                slider(g, "maxY", "Only below Y", 0, () -> value.maxY, next -> value.maxY = (int) next, -64, 320, 1, "");
                slider(g, "radius", "Scan radius", 0, () -> value.radius, next -> value.radius = (int) next, 2, 16, 1, " chunks");
                settingToggle(g, "rotatedDeepslate", "Rotated deepslate", 0, () -> value.rotatedDeepslate, () -> value.rotatedDeepslate = !value.rotatedDeepslate);
                colorRow(g, "Rotated deepslate color", 0, () -> value.color, next -> value.color = next);
                blockList(g, value, "m15");
                raidAlerts(g, value, false, true);
                status(g, engine == null ? "Join a world to scan." : engine.unnaturalCount() + " unnatural blocks found nearby.");
            }
            case 16 -> {
                var value = config.blockEntityEsp;
                section(g, "How it works", 0);
                help(g, "Draws every block entity the server sends you: chests, hoppers, furnaces, spawners and more, even through walls.");
                section(g, "Filter", 0);
                button(g, "m16.depth", "Show: " + value.depth, rowX, settingsCursor, rowW, s(34), () -> change(() -> {
                    var depths = dev.donut.client.config.RaidSettings.BlockEntityEsp.DEPTHS;
                    value.depth = depths.get((depths.indexOf(value.depth) + 1) % depths.size());
                }));
                settingsCursor += s(44);
                for (var group : dev.donut.client.config.RaidSettings.EntityGroup.values()) {
                    settingToggle(g, "group." + group.id(), group.label, 0, () -> value.groupEnabled(group),
                            () -> value.groups.put(group.id(), !value.groupEnabled(group)));
                    if (value.groupEnabled(group)) colorRow(g, group.label + " color", 0, () -> value.groupColor(group),
                            next -> value.colors.put(group.id(), next & 0xFFFFFF));
                }
                section(g, "Display", 0);
                slider(g, "opacity", "Opacity", 0, () -> value.opacity, next -> value.opacity = (int) next, 0, 255, 1, "");
                settingToggle(g, "tracers", "Tracers", 0, () -> value.tracers, () -> value.tracers = !value.tracers);
                status(g, engine == null ? "Join a world to scan." : engine.entityCount() + " block entities loaded.");
            }
            case 17 -> {
                var value = config.spawnerNotifier;
                section(g, "How it works", 0);
                help(g, "Every time a spawner loads, you get a chat message with its mob, coordinates and distance, plus a box around it.");
                section(g, "Spawners", 0);
                settingToggle(g, "trialSpawners", "Include trial spawners", 0, () -> value.trialSpawners, () -> value.trialSpawners = !value.trialSpawners);
                settingToggle(g, "render", "Box around spawners", 0, () -> value.render, () -> value.render = !value.render);
                raidAlerts(g, value, true, true);
                status(g, engine == null ? "Join a world to scan." : engine.spawnerCount() + " spawners loaded.");
            }
            case 18 -> {
                var value = config.hiddenBase;
                section(g, "How it works", 0);
                help(g, "Some servers, like DonutSMP, blank the sky light under protected bases. This module flags each chunk where that happens, shown as a red column. Vanilla servers rarely trigger it.");
                section(g, "Alerts", 0);
                settingToggle(g, "showCoordinates", "Coordinates in chat", 0, () -> value.showCoordinates, () -> value.showCoordinates = !value.showCoordinates);
                raidAlerts(g, value, true, true);
                status(g, engine == null ? "Join a world to scan." : engine.hiddenBaseCount() + " chunks flagged.");
                button(g, "m18.clear", "Clear flagged chunks", rowX, settingsCursor, rowW, s(32), () -> { if (engine != null) engine.clearFlags(); });
                settingsCursor += s(42);
            }
            case 19 -> {
                var value = config.liveActivity;
                section(g, "How it works", 0);
                help(g, "Flags chunks where something changes below Y 0 while you watch: a torch placed or broken, or redstone switching. That usually means a player is there right now.");
                section(g, "Signals", 0);
                settingToggle(g, "lightChanges", "Light changes", 0, () -> value.lightChanges, () -> value.lightChanges = !value.lightChanges);
                if (value.lightChanges) slider(g, "minLight", "Minimum light level", 0, () -> value.minLight, next -> value.minLight = (int) next, 1, 15, 1, "");
                settingToggle(g, "redstone", "Redstone changes", 0, () -> value.redstone, () -> value.redstone = !value.redstone);
                settingToggle(g, "ignoreOwnArea", "Ignore chunks around me", 0, () -> value.ignoreOwnArea, () -> value.ignoreOwnArea = !value.ignoreOwnArea);
                slider(g, "keepSeconds", "Keep flags for", 0, () -> value.keepSeconds, next -> value.keepSeconds = (int) next, 10, 3600, 10, " sec");
                raidAlerts(g, value, true, true);
                status(g, engine == null ? "Join a world to scan." : engine.activityCount() + " active chunks.");
                button(g, "m19.clear", "Clear flagged chunks", rowX, settingsCursor, rowW, s(32), () -> { if (engine != null) engine.clearFlags(); });
                settingsCursor += s(42);
            }
            case 21 -> {
                var value = config.cobbledDeepslate;
                section(g, "How it works", 0);
                help(g, "Cobbled deepslate does not generate on its own: it appears where players mined deepslate and placed it back, like filled tunnels, stairs and base walls. Ancient cities use it naturally and are skipped.");
                section(g, "Where to look", 0);
                slider(g, "maxY", "Only below Y", 0, () -> value.maxY, next -> value.maxY = (int) next, -64, 320, 1, "");
                slider(g, "radius", "Scan radius", 0, () -> value.radius, next -> value.radius = (int) next, 2, 16, 1, " chunks");
                settingToggle(g, "variants", "Include stairs, slabs and walls", 0, () -> value.variants, () -> value.variants = !value.variants);
                settingToggle(g, "ignoreAncientCities", "Ignore ancient cities", 0, () -> value.ignoreAncientCities, () -> value.ignoreAncientCities = !value.ignoreAncientCities);
                section(g, "Display", 0);
                colorRow(g, "Highlight color", 0, () -> value.color, next -> value.color = next);
                settingToggle(g, "tracers", "Tracers", 0, () -> value.tracers, () -> value.tracers = !value.tracers);
                status(g, engine == null ? "Join a world to scan." : engine.cobbledCount() + " cobbled deepslate blocks found nearby.");
            }
            case 22 -> {
                var value = config.rtpFinder;
                var finder = dev.donut.client.rtp.RtpBiomeFinder.get();
                section(g, "How it works", 0);
                help(g, "Turn the module on: it types the command below, waits for the teleport, checks the biome under you and tries again after the cooldown until it lands in one of your biomes. It sends the command like you would and never faster than the cooldown.");
                section(g, "Command", 0);
                button(g, "m22.command", "/" + value.command, rowX, settingsCursor, rowW, s(34), () -> change(() -> {
                    var commands = dev.donut.client.config.RaidSettings.RtpFinder.COMMANDS;
                    value.command = commands.get((commands.indexOf(value.command) + 1) % commands.size());
                }));
                settingsCursor += s(44);
                help(g, "Click to switch between /rtp, /rtp overworld, /wild and /randomtp. Pick the one your server uses.");
                section(g, "Biomes to find", 0);
                biomeGrid(g, value);
                section(g, "Timing", 0);
                slider(g, "cooldown", "Wait between attempts", 0, () -> value.cooldownSeconds, next -> value.cooldownSeconds = (int) next, 3, 300, 1, " s");
                help(g, "Set this to your server's /rtp cooldown or a little more.");
                slider(g, "maxAttempts", "Maximum attempts", 0, () -> value.maxAttempts, next -> value.maxAttempts = (int) next, 1, 500, 1, "");
                slider(g, "timeout", "Teleport timeout", 0, () -> value.timeoutSeconds, next -> value.timeoutSeconds = (int) next, 5, 120, 1, " s");
                section(g, "When a biome is found", 0);
                settingToggle(g, "disconnectOnFind", "Disconnect automatically", 0, () -> value.disconnectOnFind, () -> value.disconnectOnFind = !value.disconnectOnFind);
                settingToggle(g, "chat", "Chat message for each attempt", 0, () -> value.chat, () -> value.chat = !value.chat);
                settingToggle(g, "sound", "Sound when found", 0, () -> value.sound, () -> value.sound = !value.sound);
                status(g, finder == null ? "Join a server to search." : finder.status());
            }
            case 23 -> {
                var value = config.playerEsp;
                section(g, "How it works", 0);
                help(g, "Draws a box around every player the server sends you, through walls, with an optional line from your crosshair. Players in your Staff Detector list can get their own red color.");
                section(g, "Players", 0);
                slider(g, "range", "Range", 0, () -> value.range, next -> value.range = (int) next, 16, 512, 8, " blocks");
                settingToggle(g, "includeInvisible", "Include invisible and spectators", 0, () -> value.includeInvisible, () -> value.includeInvisible = !value.includeInvisible);
                settingToggle(g, "staffColor", "Staff in red", 0, () -> value.staffColor, () -> value.staffColor = !value.staffColor);
                section(g, "Display", 0);
                colorRow(g, "Player color", 0, () -> value.color, next -> value.color = next);
                settingToggle(g, "tracers", "Tracers", 0, () -> value.tracers, () -> value.tracers = !value.tracers);
                settingToggle(g, "showList", "Nearby players list", 0, () -> value.showList, () -> value.showList = !value.showList);
                if (value.showList) slider(g, "listRows", "Players in the list", 0, () -> value.listRows, next -> value.listRows = (int) next, 1, 12, 1, "");
            }
            case 20 -> {
                var value = config.chunkRefresh;
                section(g, "How it works", 0);
                help(g, "When you go below the trigger height, your render distance drops for half a second and comes back. The server then resends nearby chunks, which can reveal blocks that anti-xray hid on the first load.");
                section(g, "Trigger", 0);
                slider(g, "triggerY", "Trigger below Y", 0, () -> value.triggerY, next -> value.triggerY = (int) next, -64, 320, 1, "");
                slider(g, "lowDistance", "Low render distance", 0, () -> value.lowDistance, next -> value.lowDistance = (int) next, 2, 8, 1, " chunks");
                settingToggle(g, "chat", "Chat message", 0, () -> value.chat, () -> value.chat = !value.chat);
                button(g, "m20.now", "Refresh chunks now", rowX, settingsCursor, rowW, s(34), () -> { if (engine != null) engine.refreshNow(minecraft); });
                settingsCursor += s(44);
            }
        }
    }

    /** Chat, sound, tracer and color controls shared by the detection modules. */
    private void raidAlerts(GuiGraphics g, dev.donut.client.config.RaidSettings.Module value, boolean alerts, boolean color) {
        section(g, alerts ? "Alerts and display" : "Display", 0);
        if (alerts) {
            settingToggle(g, "chat", "Chat message", 0, () -> value.chat, () -> value.chat = !value.chat);
            settingToggle(g, "sound", "Sound ping", 0, () -> value.sound, () -> value.sound = !value.sound);
        }
        settingToggle(g, "tracers", "Tracers", 0, () -> value.tracers, () -> value.tracers = !value.tracers);
        if (color && alerts) colorRow(g, "Highlight color", 0, () -> value.color, next -> value.color = next);
    }

    private void status(GuiGraphics g, String value) {
        section(g, "Status", 0);
        help(g, value);
    }


    private void drawLightDebugSettings(GuiGraphics g) {
        var value = config.lightDebug;
        section(g, "Underground light", 0);
        slider(g,"radius","Render radius",0,()->value.radius,next->value.radius=(int)next,1,16,1," chunks");
        slider(g,"minLight","Minimum light",0,()->value.minLight,next->value.minLight=(int)next,1,15,1,"");
        settingToggle(g,"denoise","Denoise",0,()->value.denoise,()->value.denoise=!value.denoise);
        colorRow(g,"Highlight color",0,()->value.color&0xFFFFFF,next->value.color=(value.color&0xFF000000)|(next&0xFFFFFF));
        slider(g,"opacity","Opacity",0,()->(value.color>>>24),next->value.color=((int)next<<24)|(value.color&0xFFFFFF),0,255,1,"");
        help(g,"Spectre Light Debug: block light below Y 0, brighter than skylight. Denoise removes weak isolated light fields.");
    }

    private void drawAmethystSettings(GuiGraphics g) {
        var value = config.amethyst;
        section(g, "Amethyst detection", 0);
        int y = settingsCursor, x = rowX + s(88), w = rowW - s(88);
        text(g,font,"Method",rowX,y+s(10),CONTROL_TEXT);
        button(g,"m10.method",value.method+"  v",x,y,w,s(34),()->{
            scannerMethodMenu=!scannerMethodMenu;
            modeX=x; modeY=y+s(38); modeW=w;
        });
        settingsCursor+=s(44);
        if(value.method.equals("ANBS+ Scan")) slider(g,"minCells","Min Cells",0,()->value.minCells,
                next->value.minCells=(int)next,1,100,1,"");
        settingToggle(g,"tracer","Tracer",0,()->value.tracer,()->value.tracer=!value.tracer);
        help(g,value.method.equals("Bypass") ? "Uses received chunk palettes to mark possible hidden geodes."
                : value.method.equals("Light") ? "Looks for hidden-bud lighting beside amethyst blocks."
                : "Finds the ANBS+ block-light signature in loaded chunks.");
    }

    private void drawChunkFinderSettings(GuiGraphics g, int ignored) {
        var s = config.chunkFinder;
        section(g, "Detection", 0);
        int y = settingsCursor, x = rowX + s(88), w = rowW - s(88);
        text(g, font, "Method", rowX, y + s(10), CONTROL_TEXT);
        button(g, "m4.method", s.method + "  v", x, y, w, s(34), () -> {
            scannerMethodMenu = !scannerMethodMenu;

            modeX = x; modeY = y + s(38); modeW = w;
        });
        settingsCursor += s(44);
        if (!s.method.equals("Activity clues")) {
            slider(g, "simulationDistance", "Simulation distance", 0, () -> s.simulationDistance,
                    value -> s.simulationDistance = (int) value, 2, 16, 1, " chunks");
            slider(g, "sensitivity", "Sensitivity", 0, () -> s.sensitivity,
                    value -> s.sensitivity = (int) value, 1, 20, 1, "");
            help(g, "Minimum clue points. Lower values are more sensitive.");
        } else {
            slider(g, "clueThreshold", "Bee clue points", 0, () -> s.clueThreshold,
                    value -> s.clueThreshold = (int) value, 1, 8, 1, "");
        }
        slider(g, "objectRange", "Object / inspect range", 0, () -> s.objectRange,
                value -> s.objectRange = (int) value, 16, 256, 16, " blocks");
        settingToggle(g, "inspectPanel", "Look-to-inspect panel", 0, () -> s.inspectPanel,
                () -> s.inspectPanel = !s.inspectPanel);
        section(g, "Discovery panel", 0);
        colorRow(g,"Panel top color",0,()->s.panelTopColor,value->s.panelTopColor=value);
        colorRow(g,"Panel bottom color",0,()->s.panelBottomColor,value->s.panelBottomColor=value);
        slider(g,"panelOpacity","Panel opacity",0,()->s.panelOpacity,value->s.panelOpacity=value,.2,1,.05,"%");
        section(g,"Object outlines",0);
        slider(g, "alpha", "Outline opacity", 0, () -> s.alpha,
                value -> s.alpha = (int) value, 0, 255, 1, "");
        section(g, "Growth and geodes", 0);
        settingToggle(g, "smartAdjustment", "Include short / immature growth", 0, () -> !s.smartAdjustment,
                () -> s.smartAdjustment = !s.smartAdjustment);
        slider(g, "kelpLength", "Minimum kelp length", 0, () -> s.kelpLength,
                value -> s.kelpLength = (int) value, 2, 64, 1, "");
        slider(g, "vineLength", "Minimum vine length", 0, () -> s.vineLength,
                value -> s.vineLength = (int) value, 2, 64, 1, "");
        slider(g, "caveVineLength", "Minimum cave vine length", 0, () -> s.caveVineLength,
                value -> s.caveVineLength = (int) value, 2, 64, 1, "");
        slider(g, "bambooLength", "Minimum bamboo height", 0, () -> s.bambooLength,
                value -> s.bambooLength = (int) value, 2, 32, 1, "");
        slider(g, "matureClusters", "Minimum mature crystals", 0, () -> s.matureClusters,
                value -> s.matureClusters = (int) value, 2, 128, 1, "");
        slider(g, "maturePercent", "Minimum mature crystal %", 0, () -> s.maturePercent,
                value -> s.maturePercent = (int) value, 10, 100, 5, "%");
        section(g, "Clue filters", 0);
        settingToggle(g, "kelp", "Kelp", 0, () -> s.kelp, () -> s.kelp = !s.kelp);
        settingToggle(g, "caveVines", "Cave vines", 0, () -> s.caveVines, () -> s.caveVines = !s.caveVines);
        settingToggle(g, "vines", "Vines", 0, () -> s.vines, () -> s.vines = !s.vines);
        settingToggle(g, "amethyst", "Amethyst", 0, () -> s.amethyst, () -> s.amethyst = !s.amethyst);
        settingToggle(g, "bamboo", "Bamboo", 0, () -> s.bamboo, () -> s.bamboo = !s.bamboo);
        settingToggle(g, "cocoa", "Cocoa", 0, () -> s.cocoa, () -> s.cocoa = !s.cocoa);
        settingToggle(g, "beeNest", "Bee nests / hives", 0, () -> s.beeNest, () -> s.beeNest = !s.beeNest);
        section(g, "Objects and colors", 0);
        for (var category : dev.donut.client.chunkfinder.SuspectObjects.Category.values()) {
            settingToggle(g, "objects-" + category.id(), category.label, 0, () -> s.categoryEnabled(category),
                    () -> s.objects.put(category.id(), !s.categoryEnabled(category)));
            colorRow(g, category.label + " color", 0, () -> s.categoryColor(category),
                    value -> s.objectColors.put(category.id(), value & 0xFFFFFF));
        }
        help(g, "Loaded objects and natural growth are clues, not proof of a base.");
    }

    private void drawAutoBuilderSettings(GuiGraphics g, int ignored) {
        section(g, "Schematics", 0);
        help(g, ".litematic + .schem previews and automatic building");
        help(g, "Select a file, position it, then choose Start.");
        button(g, "openAutoBuilder", "Open AutoBuilder", rowX, settingsCursor, rowW, s(34), () -> toggleEnabled(3));
        settingsCursor += s(44);
        settingToggle(g,"spectreCreative","Spectre Creative engine",0,()->config.autoBuilder.spectreCreative,()->config.autoBuilder.spectreCreative=!config.autoBuilder.spectreCreative);
        help(g, "Spectre Creative is single-player only. Turn it off to use the existing Survival and multiplayer engine.");
        help(g, "Includes material and shulker plans, saved placements, world ghosts and walking navigation.");
    }
    private boolean canUseFreecam() { return minecraft.level != null && minecraft.player != null; }

    private void freecamToggle(GuiGraphics g, String id, int x, int y) {
        if (!config.freecam.enabled && !canUseFreecam()) {
            round(g, x, y, 23, 12, 6, BORDER);
            round(g, x + 2, y + 2, 8, 8, 4, DIM);
            return;
        }
        toggle(g, id, x, y, config.freecam.enabled, () -> toggleEnabled(2));
    }


    private void drawFreecamSettings(GuiGraphics g, int ignored) {
        var value = config.freecam;
        section(g, "Movement", 0);
        slider(g, "freecamSpeed", "Camera speed", 0, () -> value.speed, v -> value.speed = v, .1, 5, .1, " blocks/tick");
        slider(g, "freecamBoost", "Sprint boost", 0, () -> value.boostMultiplier, v -> value.boostMultiplier = v, 1, 10, .1, "x");
        section(g, "Your controls", 0);
        controlHint(g, "Move", keyName(minecraft.options.keyUp) + " / " + keyName(minecraft.options.keyLeft)
                + " / " + keyName(minecraft.options.keyDown) + " / " + keyName(minecraft.options.keyRight), 0);
        controlHint(g, "Up / down", keyName(minecraft.options.keyJump) + " / " + keyName(minecraft.options.keyShift), 0);
        controlHint(g, "Speed boost", keyName(minecraft.options.keySprint), 0);
        help(g, canUseFreecam() ? "Close this menu to fly. Disable to return." : "Join a world to enable Freecam.");
    }

    private String keyName(KeyMapping key) { return key.getTranslatedKeyMessage().getString(); }

    private void keybindButton(GuiGraphics g, int index, int x, int y, int w, int h) {
        KeyMapping mapping = ModuleKeybinds.mapping(index);
        if (mapping == null) return;
        boolean capturing = binding == index;
        w = Math.min(w, s(180));
        boolean hovered = inside(x, y, w, h) && (!collectingClip || mouseY >= clipTop && mouseY < clipBottom);
        if (hovered) hoveredBinding = index;
        boolean conflict = !conflicts(index).isEmpty();
        surface(g, x, y, w, h, s(7), capturing ? alpha(config.accentColor, .55) : hovered ? CONTROL_HOVER : CONTROL, 0.78f);
        String value = capturing ? "Press a key..." : (conflict ? "! " : "") + (mapping.isUnbound() ? "None" : keyName(mapping));
        text(g, font, ellipsize(value, w - s(16)), x + s(8), y + s(7), capturing ? CONTROL_TEXT : conflict ? 0xFFFFC66B : CONTROL_TEXT);
        hit("keybind" + index, x, y, w, h, () -> {
            binding = index;
            dragging = null;
            searchFocused = false;
            keyboardFocus = null;
        });
    }

    private String conflicts(int index) {
        KeyMapping mapping = ModuleKeybinds.mapping(index);
        if (mapping == null || mapping.isUnbound()) return "";
        List<String> names = new ArrayList<>();
        for (KeyMapping other : minecraft.options.keyMappings) {
            if (other != mapping && mapping.same(other)) names.add(Component.translatable(other.getName()).getString());
        }
        return String.join(", ", names);
    }

    private void drawFooter(GuiGraphics g) {
        if (specialTab()) return;
        String message = binding >= 0 ? "Press a key. Delete clears. ESC cancels." : "";
        if (hoveredBinding >= 0 && binding < 0) {
            String conflict = conflicts(hoveredBinding);
            message = conflict.isEmpty() ? "Click to assign a key or mouse button." : "Also used by: " + conflict;
        }
        if (!message.isEmpty()) {
            int mw = WorkspacePaint.smallWidth(font, message) + 24, mx = bodyX + (bodyW - mw) / 2;
            round(g, mx, H - 34, mw, 22, 11, alpha(config.accentColor, .18));
            smallText(g, font, ellipsize(message, bodyW - 24), mx + 12, H - 29, CONTROL_TEXT);
        }
    }

    private String ellipsize(String value, int maxWidth) {
        if (WorkspacePaint.width(font, value) <= maxWidth) return value;
        while (!value.isEmpty() && WorkspacePaint.width(font, value + "...") > maxWidth) value = removeLastCharacter(value);
        return value + "...";
    }

    private void controlHint(GuiGraphics g, String label, String keys, int ignored) {
        int y = settingsCursor;
        text(g, font, label, rowX, y + s(10), CONTROL_TEXT);
        int labelW = WorkspacePaint.width(font, label);
        right(g, font, ellipsize(keys, Math.max(s(60), rowW - labelW - s(16))), rowX + rowW, y + s(10), CONTROL_MUTED);
        settingsCursor += s(38);
    }

    private void clampScroll() {
        int maxScroll = Math.max(0, contentHeight - (BOTTOM - TOP));
        scroll = Math.clamp(scroll, 0, maxScroll);
        scrollTarget = Math.clamp(scrollTarget, 0, maxScroll);
    }

    private void beginContent(GuiGraphics g) {
        beginRegion(g, CX, TOP, CW, BOTTOM - TOP);
    }

    private Clip pushClip(GuiGraphics g, int x, int y, int w, int h) {
        Clip previous = new Clip(clipLeft, clipRight, clipTop, clipBottom);
        clipLeft = Math.max(clipLeft, x);
        clipRight = Math.min(clipRight, x + w);
        clipTop = Math.max(clipTop, y);
        clipBottom = Math.min(clipBottom, y + h);
        g.enableScissor(x, y, x + w, y + Math.max(0, h));
        return previous;
    }

    private void popClip(GuiGraphics g, Clip previous) {
        g.disableScissor();
        clipLeft = previous.left;
        clipRight = previous.right;
        clipTop = previous.top;
        clipBottom = previous.bottom;
    }

    private void endContent(GuiGraphics g) {
        endRegion(g);
        scrollbar(g, "scrollbar", CX + CW + 1, TOP, BOTTOM - TOP, contentHeight, scroll,
                value -> scroll = scrollTarget = value);
    }

    private void section(GuiGraphics g, String title, int ignored) {
        settingsCursor += s(18);
        String label = title.toUpperCase(Locale.ROOT);
        round(g, rowX, settingsCursor + s(4), s(4), s(4), s(2), alpha(config.accentColor, .9));
        smallText(g, font, label, rowX + s(9), settingsCursor, DIM);
        // A hairline after the title separates blocks of settings without boxing them in.
        int lineX = rowX + s(9) + WorkspacePaint.smallWidth(font, label) + s(10);
        if (lineX < rowX + rowW) line(g, lineX, settingsCursor + s(6), rowX + rowW, settingsCursor + s(6), HAIRLINE);
        settingsCursor += s(19);
    }

    private void group(GuiGraphics g, String id, String title, int ignored, boolean open, Runnable action) {
        int y = settingsCursor;
        smallText(g, font, title, rowX, y + s(16), CONTROL_MUTED);
        text(g, font, open ? "-" : "+", rowX + rowW - s(14), y + s(12), CONTROL_MUTED);
        hit(rowPrefix + id, rowX, y, rowW, s(40), action);
        settingsCursor += s(40);
    }



    private void slider(GuiGraphics g, String id, String label, int ignored, DoubleSupplier getter,
                        DoubleConsumer setter, double min, double max, double step, String unit) {
        int y = settingsCursor;
        double value = getter.getAsDouble();
        String display = unit.equals("%") ? Math.round(value * (step < 1 ? 100 : 1)) + "%"
                : step >= 1 ? Math.round(value) + unit : String.format(Locale.ROOT, "%.1f%s", value, unit);
        int pillW = WorkspacePaint.smallWidth(font, display) + s(16), pillH = s(21);
        text(g, font, ellipsize(label, rowW - pillW - s(8)), rowX, y + s(10), CONTROL_TEXT);
        surface(g, rowX + rowW - pillW, y + s(7), pillW, pillH, pillH / 2f, CONTROL, 0.78f);
        smallText(g, font, display, rowX + rowW - pillW + s(8), y + s(11), CONTROL_MUTED);
        int trackX = rowX + s(7), trackW = rowW - s(14), trackY = y + s(45);
        double t = Math.clamp((value - min) / (max - min), 0, 1);
        boolean hovered = inside(rowX, y + s(36), rowW, s(18));
        float r = (hovered ? 8 : 6.5f) * fontScale;
        float knobX = trackX + (float) (trackW * t);
        // Thicker track, the filled part lighter toward the knob, and a white knob with an accent ring.
        round(g, trackX, trackY - s(2.5f), trackW, s(5), s(2.5f), TRACK);
        int filled = Math.max(s(5), (int) (trackW * t));
        round(g, trackX, trackY - s(2.5f), filled, s(5), s(2.5f), accent());
        round(g, trackX + filled * .5f, trackY - s(2.5f), filled * .5f, s(5), s(2.5f), alpha(0xFFFFFF, .12));
        if (hovered) round(g, knobX - r - s(4), trackY - r - s(4), 2 * (r + s(4)), 2 * (r + s(4)), r + s(4), alpha(config.accentColor, .22));
        round(g, knobX - r - s(1.5f), trackY - r - s(1.5f), 2 * (r + s(1.5f)), 2 * (r + s(1.5f)), r + s(1.5f), accent());
        round(g, knobX - r + s(1), trackY - r + s(1), 2 * (r - s(1)), 2 * (r - s(1)), r - s(1), 0xFFF5F6F8);
        dragHit(rowPrefix + id, trackX, y + s(36), trackW, s(18), position -> {
            double next = Math.round((min + Math.clamp(position, 0, 1) * (max - min)) / step) * step;
            setter.accept(Math.clamp(next, min, max)); dirty = true;
        }, false, direction -> { setter.accept(Math.clamp(getter.getAsDouble() + direction * step, min, max)); dirty = true; flush(); });
        settingsCursor += s(64);
    }

    private void settingToggle(GuiGraphics g, String id, String label, int ignored, BooleanSupplier value, Runnable action) {
        int y = settingsCursor, rowH = s(44), x = rowX + rowW - s(38);
        double hover = animate("settingHover" + rowPrefix + id, inside(rowX, y, rowW, rowH) ? 1 : 0);
        round(g, rowX - s(8), y + s(2), rowW + s(16), rowH - s(4), corner(10), alpha(0xFFFFFF, .035 * hover));
        text(g, font, ellipsize(label, rowW - s(52)), rowX, y + (rowH - s(16)) / 2, CONTROL_TEXT);
        double on = animate("settingToggle" + rowPrefix + id, value.getAsBoolean() ? 1 : 0);
        int trackH = s(20), trackY = y + (rowH - trackH) / 2;
        if (on > .01) round(g, x - s(3), trackY - s(3), s(44), trackH + s(6), (trackH + s(6)) / 2f, alpha(config.accentColor, .16 * on));
        surface(g, x, trackY, s(38), trackH, trackH / 2f, blend(TRACK, accent(), on), 0.62f);
        float r = 7f * fontScale, knobX = x + s(10) + (float) on * s(18), knobY = trackY + trackH / 2f;
        round(g, knobX - r, knobY - r + fontScale, r * 2, r * 2, r, 0x30000000);
        round(g, knobX - r, knobY - r, r * 2, r * 2, r, blend(0xFFB4B8D6, 0xFFFFFFFF, on));
        hit(rowPrefix + id, rowX, y, rowW, rowH, () -> change(action));
        settingsCursor += rowH;
    }

    private void toggle(GuiGraphics g, String id, int x, int y, boolean on, Runnable action) {
        double position = animate("toggle" + id, on ? 1 : 0);
        round(g, x, y, 23, 12, 6, blend(BORDER, config.accentColor, position));
        round(g, x + 2 + (float) (11 * position), y + 2, 8, 8, 4, blend(DIM, 0xFFFFFFFF, position));
        hit(id, x - 3, y - 4, 29, 20, action);
    }

    private void colorRow(GuiGraphics g, String label, int ignored, IntSupplier getter, IntConsumer setter) {
        int y = settingsCursor, x = rowX + rowW - s(44);
        text(g, font, ellipsize(label, rowW - s(60)), rowX, y + s(15), CONTROL_TEXT);
        round(g, x, y + s(11), s(44), s(24), s(7), alpha(getter.getAsInt(), 1));
        outline(g, x, y + s(11), s(44), s(24), s(7), alpha(0xFFFFFF, inside(x, y, s(44), s(46)) ? .4 : .15));
        hit(rowPrefix + "color" + label, x, y + s(11), s(44), s(24),
                () -> { colorEditor = new ColorEditor(label, getter, setter); modalProgress = 0; keyboardFocus = null; scannerMethodMenu = false; });
        settingsCursor += s(46);
    }

    private void drawAppearance(GuiGraphics g) {
        var style = config.clickGuiStyle;
        int top = HEADER + 4, panelH = H - HEADER - 24, pad = s(20);
        detailW = Math.round(Math.min(380 * fontScale, .4f * (W - railW)));
        detailX = W - detailW - 20;
        int previewX = bodyX, previewW = detailX - 20 - bodyX;
        surface(g, previewX, top, previewW, panelH, corner(16), alpha(config.clickGuiStyle.cardsColor, config.clickGuiStyle.cardsOpacity * .5), 0.9f);
        outline(g, previewX, top, previewW, panelH, corner(16), chromeBorder());
        surface(g, detailX, top, detailW, panelH, corner(16), alpha(config.clickGuiStyle.cardsColor, config.clickGuiStyle.cardsOpacity * .7), 0.93f);
        outline(g, detailX, top, detailW, panelH, corner(16), chromeBorder());
        smallText(g, font, "THEME", detailX + pad, top + pad, DIM);
        smallText(g, font, "Make the workspace yours.", detailX + pad, top + pad + s(18), CONTROL_MUTED);
        String[] surfaces = {"Global", "Window", "Cards", "Sidebar"};
        int segmentY = top + pad + s(44), segmentW = (detailW - pad * 2) / 4;
        round(g, detailX + pad, segmentY, detailW - pad * 2, s(34), corner(10), FIELD);
        for (int i = 0; i < surfaces.length; i++) {
            int item = i, sx = detailX + pad + segmentW * i;
            if (appearanceSurface == i) round(g, sx + s(3), segmentY + s(3), segmentW - s(6), s(28), corner(8), accent());
            smallText(g, font, surfaces[i], sx + (segmentW - WorkspacePaint.smallWidth(font, surfaces[i])) / 2f, segmentY + s(12),
                    appearanceSurface == i ? inkOn(config.accentColor) : CONTROL_MUTED);
            hit("surface" + i, sx, segmentY, segmentW, s(34), () -> { appearanceSurface = item; detailScroll = detailScrollTarget = 0; });
        }
        int sampleW = Math.min(s(440), previewW - s(48)), sampleH = s(appearanceSurface == 3 ? 92 : 250);
        int sampleX = previewX + (previewW - sampleW) / 2, sampleY = top + (panelH - sampleH) / 2;
        int sampleColor = appearanceSurface == 1 ? style.panelsColor : appearanceSurface == 3 ? style.tabBarColor : style.cardsColor;
        double sampleOpacity = appearanceSurface == 1 ? style.panelsOpacity : appearanceSurface == 3 ? style.tabBarOpacity : style.cardsOpacity;
        shadow(g, sampleX, sampleY, sampleW, sampleH, s((float) style.rounding), 0x70000000);
        surface(g, sampleX, sampleY, sampleW, sampleH, s((float) style.rounding), alpha(sampleColor, sampleOpacity), 0.88f);
        outline(g, sampleX, sampleY, sampleW, sampleH, s((float) style.rounding), 0x26FFFFFF);
        text(g, font, appearanceSurface == 3 ? "Modules     HUD     Appearance" : "Module preview", sampleX + s(20), sampleY + s(20), CONTROL_TEXT);
        if (appearanceSurface != 3) {
            text(g, font, "A live preview of your theme", sampleX + s(20), sampleY + s(52), CONTROL_MUTED);
            round(g, sampleX + s(12), sampleY + s(90), sampleW - s(24), s(34), s(7), alpha(config.accentColor, .14));
            text(g, font, "Selected module", sampleX + s(22), sampleY + s(99), CONTROL_TEXT);
            text(g, font, "Inactive module", sampleX + s(22), sampleY + s(146), CONTROL_MUTED);
            round(g, sampleX + s(22), sampleY + sampleH - s(37), sampleW - s(44), s(3), s(2), CONTROL);
            round(g, sampleX + s(22), sampleY + sampleH - s(37), (sampleW - s(44)) * .6f, s(3), s(2), alpha(config.accentColor, 1));
            round(g, sampleX + s(22) + (sampleW - s(44)) * .6f - s(5), sampleY + sampleH - s(41), s(10), s(10), s(5), CONTROL_TEXT);
        }
        smallText(g, font, "LIVE PREVIEW", previewX + pad, top + pad, DIM);
        detailTop = segmentY + s(46);
        detailBottom = top + panelH - pad;
        clampDetailScroll();
        beginRegion(g, detailX + pad - 2, detailTop, detailW - pad * 2 + 4, detailBottom - detailTop);
        rowX = detailX + pad;
        rowW = detailW - pad * 2;
        rowPrefix = "";
        settingsCursor = detailTop - (int) detailScroll;
        if (appearanceSurface == 0) {
            section(g, "Presets", 0);
            int[] accents = {0x6C5CFF, 0x2B4BFF, 0x56DCCB, 0x78A8FF, 0xBB9AF7, 0xF38BA8, 0xFAB387, 0xCBDC56};
            int stride = Math.min(s(40), rowW / accents.length);
            for (int i = 0; i < accents.length; i++) {
                int accent = accents[i], px = rowX + i * stride;
                round(g, px + s(3), settingsCursor + s(3), s(22), s(22), s(11), alpha(accent, 1));
                if (config.accentColor == accent) outline(g, px, settingsCursor, s(28), s(28), s(14), CONTROL_TEXT);
                hit("preset" + i, px, settingsCursor, s(28), s(28), () -> change(() -> config.accentColor = accent));
            }
            settingsCursor += s(42);
            button(g, "resetTheme", "Reset to default theme", rowX, settingsCursor, rowW, s(34), () -> change(() -> {
                var defaults = new dev.donut.client.config.ClickGuiStyle();
                style.panelsColor = defaults.panelsColor; style.cardsColor = defaults.cardsColor;
                style.tabBarColor = defaults.tabBarColor; style.panelsOpacity = defaults.panelsOpacity;
                style.cardsOpacity = defaults.cardsOpacity; style.tabBarOpacity = defaults.tabBarOpacity;
                style.rounding = defaults.rounding; style.liquidGlass = defaults.liquidGlass;
                config.accentColor = 0x6C5CFF;
            }));
            settingsCursor += s(44);
            section(g, "Colors", 0);
            colorRow(g, "Accent color", 0, () -> config.accentColor, value -> config.accentColor = value);
            section(g, "Layout", 0);
            slider(g, "rounding", "Corner radius", 0, () -> style.rounding, value -> style.rounding = value, 0, 16, 1, "");
            slider(g, "backgroundDim", "Background dim", 0, () -> style.backgroundDim, value -> style.backgroundDim = value, 0, .8, .05, "%");
            section(g, "Interface", 0);
            settingToggle(g, "liquidGlass", "Frosted liquid glass", 0,
                    () -> style.liquidGlass, () -> style.liquidGlass = !style.liquidGlass);
            slider(g, "uiScale", "UI scale", 0, () -> style.scale, value -> style.scale = value, .75, 1.5, .05, "%");
            slider(g, "animationSpeed", "Animation speed", 0, () -> style.animationSpeed, value -> style.animationSpeed = value, 0, 2, .1, "x");
            settingToggle(g, "particles", "Ambient particles", 0, () -> config.clickGuiParticles, () -> config.clickGuiParticles = !config.clickGuiParticles);
        } else {
            section(g, surfaces[appearanceSurface], 0);
            colorRow(g, "Color", 0, () -> appearanceSurface == 1 ? style.panelsColor : appearanceSurface == 2 ? style.cardsColor : style.tabBarColor,
                    value -> { if (appearanceSurface == 1) style.panelsColor = value; else if (appearanceSurface == 2) style.cardsColor = value; else style.tabBarColor = value; });
            slider(g, "surfaceOpacity", "Opacity", 0,
                    () -> appearanceSurface == 1 ? style.panelsOpacity : appearanceSurface == 2 ? style.cardsOpacity : style.tabBarOpacity,
                    value -> { if (appearanceSurface == 1) style.panelsOpacity = value; else if (appearanceSurface == 2) style.cardsOpacity = value; else style.tabBarOpacity = value; }, .2, 1, .05, "%");
        }
        detailContentHeight = settingsCursor + s(20) - detailTop + (int) detailScroll;
        endRegion(g);
        clampDetailScroll();
        drawDetailScrollbar(g);
    }

    private void drawColorEditor(GuiGraphics g) {
        // Modal hit testing replaces the underlying settings' controls.
        hits.clear();
        round(g, 0, 0, W, H, corner(20), 0xB00A0E11);
        int w = 318, h = 252, x = (W - w) / 2, y = (H - h) / 2;
        shadow(g, x, y, w, h, 14, 0x70000000);
        surface(g, x, y, w, h, 14, 0xFF101823, 1f);
        outline(g, x, y, w, h, 14, chromeBorder());
        strong(g, font, colorEditor.title, x + 18, y + 17, TEXT);
        text(g, font, "Choose a color", x + 18, y + 35, MUTED);
        round(g, x + w - 53, y + 16, 33, 33, 8, alpha(colorEditor.getter.getAsInt(), 1));
        for (int i = 0; i < PALETTE.length; i++) {
            int px = x + 18 + i * 24;
            int color = PALETTE[i];
            round(g, px, y + 61, 18, 18, 5, alpha(color, 1));
            if (colorEditor.getter.getAsInt() == color) outline(g, px - 2, y + 59, 22, 22, 6, TEXT);
            hit("swatch" + i, px - 2, y + 59, 22, 22, () -> { colorEditor.set(color); flush(); });
        }
        colorChannel(g, "Red", 16, 0xFFF17886, x, y + 99);
        colorChannel(g, "Green", 8, 0xFF84DCB3, x, y + 133);
        colorChannel(g, "Blue", 0, 0xFF81AEFF, x, y + 167);
        surface(g, x + 18, y + 210, 141, 27, 6, colorEditor.hexFocused ? BORDER : CARD, 0.8f);
        String value = "#" + colorEditor.hex + (colorEditor.hexFocused && System.currentTimeMillis() % 1000 < 500 ? "|" : "");
        text(g, font, value, x + 29, y + 220, colorEditor.hex.length() == 6 ? TEXT : 0xFFFFC66B);
        hit("hex", x + 18, y + 210, 141, 27, () -> { colorEditor.hexFocused = true; colorEditor.replaceHex = true; });
        surface(g, x + w - 111, y + 210, 93, 27, 6, alpha(config.accentColor, 1), 0.62f);
        int accent = config.accentColor;
        int ink = config.clickGuiStyle.liquidGlass ? TEXT :
                ((accent >> 16 & 255) * .2126 + (accent >> 8 & 255) * .7152 + (accent & 255) * .0722) > 150 ? PANEL : TEXT;
        text(g, font, "Done", x + w - 80, y + 220, ink);
        hit("colorDone", x + w - 111, y + 210, 93, 27, this::closeColor);
    }

    private void colorChannel(GuiGraphics g, String label, int shift, int tint, int x, int y) {
        int value = (colorEditor.getter.getAsInt() >> shift) & 255;
        text(g, font, label, x + 18, y, tint);
        right(g, font, Integer.toString(value), x + 298, y, MUTED);
        int sx = x + 76, sw = 181;
        round(g, sx, y + 3, sw, 4, 2, BORDER);
        round(g, sx, y + 3, Math.max(4, (int) (sw * value / 255.0)), 4, 2, tint);
        round(g, sx + (int) (sw * value / 255.0) - 4, y, 9, 10, 4, TEXT);
        dragHit("rgb" + shift, sx, y - 5, sw, 20, t -> {
            int channel = (int) Math.round(Math.clamp(t, 0, 1) * 255);
            int next = (colorEditor.getter.getAsInt() & ~(255 << shift)) | channel << shift;
            colorEditor.set(next);
        }, false, direction -> {
            int channel = Math.clamp(((colorEditor.getter.getAsInt() >> shift) & 255) + direction, 0, 255);
            colorEditor.set((colorEditor.getter.getAsInt() & ~(255 << shift)) | channel << shift);
            flush();
        });
    }

    private void closeColor() { colorEditor = null; dragging = null; keyboardFocus = null; flush(); }
    private String hex(int color) { return String.format(Locale.ROOT, "#%06X", color & 0xFFFFFF); }

    private double ease(double current, double target, double speed) {
        if (config.clickGuiStyle.animationSpeed == 0) return target;
        double result = current + (target - current) * (1 - Math.exp(-speed * frameSeconds * config.clickGuiStyle.animationSpeed));
        return Math.abs(result - target) < .001 ? target : result;
    }

    private double advance(double value, boolean showing, double duration) {
        if (config.clickGuiStyle.animationSpeed == 0) return showing ? 1 : 0;
        return Math.clamp(value + (showing ? 1 : -1) * frameSeconds * config.clickGuiStyle.animationSpeed / duration, 0, 1);
    }

    private static double smooth(double value) { return value * value * (3 - 2 * value); }

    private double animate(String id, double target) {
        double result = ease(animations.getOrDefault(id, target), target, 16);
        animations.put(id, result);
        return result;
    }

    private boolean inside(int x, int y, int w, int h) {
        return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
    }

    private void hit(String id, int x, int y, int w, int h, Runnable action) {
        hit(id, x, y, w, h, action, null);
    }

    private void hit(String id, int x, int y, int w, int h, Runnable action, Runnable secondary) {
        if (!contentInteractive || closing) return;
        int top = collectingClip ? Math.max(y, clipTop) : y;
        int bottom = collectingClip ? Math.min(y + h, clipBottom) : y + h;
        int left = collectingClip ? Math.max(x, clipLeft) : x;
        int right = collectingClip ? Math.min(x + w, clipRight) : x + w;
        if (top >= bottom || left >= right) return;
        hits.add(new Hit(id, left, top, right - left, bottom - top, action, secondary, null, false, null));
    }

    private void dragHit(String id, int x, int y, int w, int h, DoubleConsumer action, boolean vertical) {
        dragHit(id, x, y, w, h, action, vertical, null);
    }

    private void dragHit(String id, int x, int y, int w, int h, DoubleConsumer action, boolean vertical, IntConsumer nudge) {
        if (!contentInteractive || closing) return;
        int top = collectingClip ? Math.max(y, clipTop) : y;
        int bottom = collectingClip ? Math.min(y + h, clipBottom) : y + h;
        int left = collectingClip ? Math.max(x, clipLeft) : x;
        int right = collectingClip ? Math.min(x + w, clipRight) : x + w;
        if (top >= bottom || left >= right) return;
        hits.add(new Hit(id, left, top, right - left, bottom - top, null, null, action, vertical, nudge));
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubled) {
        if (closing) return true;
        if (binding >= 0) {
            ModuleKeybinds.setKey(minecraft, binding, InputConstants.Type.MOUSE.getOrCreate(event.button()));
            binding = -1;
            return true;
        }
        boolean rightClick = event.button() == GLFW.GLFW_MOUSE_BUTTON_RIGHT;
        if (event.button() != GLFW.GLFW_MOUSE_BUTTON_LEFT && !rightClick) return false;
        commitBasesFound();
        if (!commitTimerDuration()) cancelTimerDuration();
        blockDraft = null;
        double x = (event.x() - originX) / scale, y = (event.y() - originY) / scale;
        keyboardFocus = null;
        searchFocused = false;
        if (colorEditor != null) colorEditor.hexFocused = false;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(x, y)) continue;
            if (rightClick) {
                // A module tile also supports right-click selection.
                if (h.secondary == null) continue;
                h.secondary.run();
            } else if (h.drag != null) { dragging = h; h.move(x, y); }
            else h.action.run();
            return true;
        }

        scannerMethodMenu = false;
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (closing) return true;
        if (dragging == null) return false;
        dragging.move((event.x() - originX) / scale, (event.y() - originY) / scale);
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging != null) { dragging = null; flush(); return true; }
        return false;
    }

    @Override
    public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
        if (closing || colorEditor != null || scannerMethodMenu || binding >= 0) return true;
        double localX = (x - originX) / scale, localY = (y - originY) / scale;
        if (localX >= detailX && localX <= detailX + detailW && localY >= detailTop && localY <= detailBottom) {
            commitBasesFound();
            if (!commitTimerDuration()) cancelTimerDuration();
            detailScrollTarget = Math.clamp(detailScrollTarget - vertical * s(40), 0,
                    Math.max(0, detailContentHeight - (detailBottom - detailTop)));
            keyboardFocus = null;
            return true;
        }
        if (tab == 8 && localX >= bodyX && localX <= detailX - 20 && localY >= configListTop && localY <= configListBottom) {
            configScrollTarget = Math.clamp(configScrollTarget - vertical * s(40), 0,
                    Math.max(0, configListHeight - (configListBottom - configListTop)));
            return true;
        }
        if (!specialTab() && localX >= CX && localX <= CX + CW && localY >= TOP && localY <= BOTTOM) {
            commitBasesFound();
            if (!commitTimerDuration()) cancelTimerDuration();
            scrollTarget = Math.clamp(scrollTarget - vertical * 31, 0, Math.max(0, contentHeight - (BOTTOM - TOP)));
            keyboardFocus = null;
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (closing) return true;
        // A held capture/cancel key must not repeat into ordinary GUI navigation.
        InputConstants.Key pressed = InputConstants.getKey(event);
        if (pressed.equals(openingKey)) return true;
        if (pressed.equals(capturedKey)) return true;
        if (binding >= 0) {
            capturedKey = pressed;
            if (event.key() != GLFW.GLFW_KEY_ESCAPE) {
                InputConstants.Key key = event.key() == GLFW.GLFW_KEY_DELETE || event.key() == GLFW.GLFW_KEY_BACKSPACE
                        ? InputConstants.UNKNOWN : pressed;
                ModuleKeybinds.setKey(minecraft, binding, key);
            }
            binding = -1;
            return true;
        }
        if (editingTimer >= 0) {
            if (event.key() == GLFW.GLFW_KEY_ESCAPE) {
                capturedKey = pressed;
                cancelTimerDuration();
                timerError = -1;
                keyboardFocus = null;
                return true;
            }
            if (event.key() == GLFW.GLFW_KEY_ENTER || event.key() == GLFW.GLFW_KEY_KP_ENTER) {
                if (commitTimerDuration()) keyboardFocus = null;
                return true;
            }
            if (event.key() == GLFW.GLFW_KEY_TAB) {
                if (!commitTimerDuration()) return true;
            } else {
                if (event.key() == GLFW.GLFW_KEY_A && event.hasControlDown()) replaceTimerDuration = true;
                else if (event.key() == GLFW.GLFW_KEY_V && event.hasControlDown()) {
                    String pasted = minecraft.keyboardHandler.getClipboard().trim();
                    if (pasted.matches("[0-9:]{1,8}")) {
                        String next = (replaceTimerDuration ? "" : timerDurationDraft) + pasted;
                        if (next.length() <= 8) { timerDurationDraft = next; replaceTimerDuration = false; timerError = -1; }
                    } else timerError = editingTimer;
                } else if (event.key() == GLFW.GLFW_KEY_BACKSPACE || event.key() == GLFW.GLFW_KEY_DELETE) {
                    timerDurationDraft = replaceTimerDuration ? "" : removeLastCharacter(timerDurationDraft);
                    replaceTimerDuration = false;
                    timerError = -1;
                }
                return true;
            }
        }
        if (configNameDraft != null && tab == 8) {
            if (event.key() == GLFW.GLFW_KEY_ESCAPE) { capturedKey = pressed; configNameDraft = null; return true; }
            if (event.key() == GLFW.GLFW_KEY_ENTER || event.key() == GLFW.GLFW_KEY_KP_ENTER) { saveConfigDraft(); return true; }
            if (event.key() == GLFW.GLFW_KEY_BACKSPACE || event.key() == GLFW.GLFW_KEY_DELETE) { configNameDraft = removeLastCharacter(configNameDraft); return true; }
            if (event.key() == GLFW.GLFW_KEY_A && event.hasControlDown()) { configNameDraft = ""; return true; }
            if (event.key() == GLFW.GLFW_KEY_V && event.hasControlDown()) {
                configNameDraft = dev.donut.client.config.SharedConfigs.cleanName(configNameDraft + minecraft.keyboardHandler.getClipboard());
                return true;
            }
            return true;
        }
        if (blockDraft != null) {
            if (event.key() == GLFW.GLFW_KEY_ESCAPE) { capturedKey = pressed; blockDraft = null; return true; }
            if (event.key() == GLFW.GLFW_KEY_ENTER || event.key() == GLFW.GLFW_KEY_KP_ENTER) { commitBlockDraft(); return true; }
            if (event.key() == GLFW.GLFW_KEY_BACKSPACE || event.key() == GLFW.GLFW_KEY_DELETE) { blockDraft = removeLastCharacter(blockDraft); return true; }
            if (event.key() == GLFW.GLFW_KEY_A && event.hasControlDown()) { blockDraft = ""; return true; }
            if (event.key() == GLFW.GLFW_KEY_V && event.hasControlDown()) {
                String pasted = minecraft.keyboardHandler.getClipboard().replaceAll("[\\p{Cntrl}]", "");
                blockDraft = (blockDraft + pasted).substring(0, Math.min(48, blockDraft.length() + pasted.length()));
                return true;
            }
            return true;
        }
        if (basesFoundDraft != null) {
            if (event.key() == GLFW.GLFW_KEY_ESCAPE) {
                capturedKey = pressed;
                basesFoundDraft = null;
                replaceBasesFound = false;
                keyboardFocus = null;
                return true;
            }
            if (event.key() == GLFW.GLFW_KEY_ENTER || event.key() == GLFW.GLFW_KEY_KP_ENTER) {
                commitBasesFound();
                keyboardFocus = null;
                return true;
            }
            if (event.key() == GLFW.GLFW_KEY_TAB) commitBasesFound();
            else {
                if (event.key() == GLFW.GLFW_KEY_A && event.hasControlDown()) replaceBasesFound = true;
                else if (event.key() == GLFW.GLFW_KEY_V && event.hasControlDown()) {
                    String pasted = minecraft.keyboardHandler.getClipboard().trim();
                    if (pasted.matches("[0-9]+")) {
                        String next = (replaceBasesFound ? "" : basesFoundDraft) + pasted;
                        // Remove leading zeroes before bounding long input to a safe integer.
                        next = next.replaceFirst("^0+(?!$)", "");
                        basesFoundDraft = next.length() > 18 ? Integer.toString(ProgressBarSettings.MAX_BASES_FOUND) : next;
                        replaceBasesFound = false;
                    }
                } else if (event.key() == GLFW.GLFW_KEY_BACKSPACE || event.key() == GLFW.GLFW_KEY_DELETE) {
                    basesFoundDraft = replaceBasesFound ? "" : removeLastCharacter(basesFoundDraft);
                    replaceBasesFound = false;
                }
                return true;
            }
        }
        KeyMapping open = KeyMapping.get("key.donut.open_gui");
        if (open != null && !open.isUnbound() && pressed.equals(InputConstants.getKey(open.saveString()))) {
            onClose();
            return true;
        }
        if (event.key() == GLFW.GLFW_KEY_ESCAPE) {
            if (scannerMethodMenu) { scannerMethodMenu = false; }
            else if (colorEditor != null) closeColor();
            else if (searchFocused) { searchFocused = false; query = ""; contentProgress = 0; }
            else onClose();
            return true;
        }
        if (colorEditor == null && !scannerMethodMenu && !specialTab() && event.key() == GLFW.GLFW_KEY_F && event.hasControlDown()) {
            searchFocused = true;
            keyboardFocus = null;
            return true;
        }
        if (colorEditor != null && colorEditor.hexFocused) {
            if (event.key() == GLFW.GLFW_KEY_V && event.hasControlDown()) {
                String pasted = minecraft.keyboardHandler.getClipboard().trim().replaceFirst("^#", "");
                if (pasted.matches("(?i)[0-9a-f]{6}")) { colorEditor.set(Integer.parseInt(pasted, 16)); flush(); }
                return true;
            }
            if (event.key() == GLFW.GLFW_KEY_C && event.hasControlDown()) {
                minecraft.keyboardHandler.setClipboard("#" + colorEditor.hex); return true;
            }
            if (event.key() == GLFW.GLFW_KEY_BACKSPACE) {
                colorEditor.hex = colorEditor.replaceHex ? "" : colorEditor.hex.substring(0, Math.max(0, colorEditor.hex.length() - 1));
                colorEditor.replaceHex = false;
                return true;
            }
            if (event.key() == GLFW.GLFW_KEY_ENTER) { closeColor(); return true; }
            if (event.key() == GLFW.GLFW_KEY_A && (event.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0) {
                colorEditor.replaceHex = true; return true;
            }
        }
        if (searchFocused) {
            if (event.key() == GLFW.GLFW_KEY_V && event.hasControlDown()) {
                String pasted = minecraft.keyboardHandler.getClipboard().replaceAll("[\\p{Cntrl}]", "");
                query = (query + pasted).substring(0, Math.min(64, query.length() + pasted.length())); contentProgress = 0; return true;
            }
            if (event.key() == GLFW.GLFW_KEY_BACKSPACE) { query = removeLastCharacter(query); contentProgress = 0; return true; }
            if (event.key() == GLFW.GLFW_KEY_ENTER) { searchFocused = false; return true; }
            if (event.key() == GLFW.GLFW_KEY_A && (event.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0) { query = ""; contentProgress = 0; return true; }
        }
        if (event.key() == GLFW.GLFW_KEY_TAB && !hits.isEmpty()) {
            int index = -1;
            for (int i = 0; i < hits.size(); i++) if (hits.get(i).id.equals(keyboardFocus)) index = i;
            int direction = (event.modifiers() & GLFW.GLFW_MOD_SHIFT) != 0 ? -1 : 1;
            keyboardFocus = hits.get(Math.floorMod(index + direction, hits.size())).id;
            searchFocused = false;
            return true;
        }
        if (keyboardFocus != null && (event.key() == GLFW.GLFW_KEY_ENTER || event.key() == GLFW.GLFW_KEY_SPACE)) {
            hits.stream().filter(h -> h.id.equals(keyboardFocus)).findFirst().ifPresent(h -> {
                if (h.secondary != null && (event.modifiers() & GLFW.GLFW_MOD_SHIFT) != 0) h.secondary.run();
                else if (h.action != null) h.action.run();
            });
            // Enter/Space that opens capture is not itself the new binding on repeat.
            if (binding >= 0) capturedKey = pressed;
            return true;
        }
        if (keyboardFocus != null && (event.key() == GLFW.GLFW_KEY_LEFT || event.key() == GLFW.GLFW_KEY_RIGHT)) {
            hits.stream().filter(h -> h.id.equals(keyboardFocus)).findFirst().ifPresent(h -> {
                if (h.nudge != null) h.nudge.accept(event.key() == GLFW.GLFW_KEY_RIGHT ? 1 : -1);
            });
            return true;
        }
        if (colorEditor == null && !scannerMethodMenu && !searchFocused) {
            if (event.key() == GLFW.GLFW_KEY_PAGE_DOWN || event.key() == GLFW.GLFW_KEY_PAGE_UP) {
                if (selectedModule >= 0 || specialTab()) detailScrollTarget = Math.clamp(detailScrollTarget + (event.key() == GLFW.GLFW_KEY_PAGE_DOWN ? s(170) : -s(170)), 0, Math.max(0, detailContentHeight - (detailBottom - detailTop)));
                else scrollTarget = Math.clamp(scrollTarget + (event.key() == GLFW.GLFW_KEY_PAGE_DOWN ? 170 : -170), 0, Math.max(0, contentHeight - (BOTTOM - TOP)));
                keyboardFocus = null; return true;
            }
            if (event.key() == GLFW.GLFW_KEY_HOME) { if (selectedModule >= 0 || specialTab()) detailScrollTarget = 0; else scrollTarget = 0; return true; }
            if (event.key() == GLFW.GLFW_KEY_END) { if (selectedModule >= 0 || specialTab()) detailScrollTarget = Math.max(0, detailContentHeight - (detailBottom - detailTop)); else scrollTarget = Math.max(0, contentHeight - (BOTTOM - TOP)); return true; }
        }
        return false;
    }

    @Override
    public boolean keyReleased(KeyEvent event) {
        if (InputConstants.getKey(event).equals(openingKey)) openingKey = null;
        if (InputConstants.getKey(event).equals(capturedKey)) capturedKey = null;
        return super.keyReleased(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (closing || binding >= 0 || capturedKey != null) return true;
        if (editingTimer >= 0) {
            if (event.codepoint() >= '0' && event.codepoint() <= '9' || event.codepoint() == ':') {
                if (replaceTimerDuration) { timerDurationDraft = ""; replaceTimerDuration = false; }
                if (timerDurationDraft.length() < 8) timerDurationDraft += event.codepointAsString();
                timerError = -1;
            }
            return true;
        }
        if (basesFoundDraft != null) {
            if (event.codepoint() >= '0' && event.codepoint() <= '9') {
                if (replaceBasesFound) { basesFoundDraft = ""; replaceBasesFound = false; }
                if (basesFoundDraft.length() < 18) basesFoundDraft += event.codepointAsString();
            }
            return true;
        }
        if (colorEditor != null && colorEditor.hexFocused) {
            int c = event.codepoint();
            if (Character.digit(c, 16) >= 0 && c < 128) {
                if (colorEditor.replaceHex) { colorEditor.hex = ""; colorEditor.replaceHex = false; }
                if (colorEditor.hex.length() < 6) colorEditor.hex += Character.toString(c).toUpperCase(Locale.ROOT);
                if (colorEditor.hex.length() == 6) { colorEditor.setter.accept(Integer.parseInt(colorEditor.hex, 16)); dirty = true; flush(); }
            }
            return true;
        }
        if (blockDraft != null) {
            if (event.isAllowedChatCharacter() && blockDraft.length() < 48) blockDraft += event.codepointAsString();
            return true;
        }
        if (configNameDraft != null && tab == 8) {
            if (event.isAllowedChatCharacter() && configNameDraft.length() < dev.donut.client.config.SharedConfigs.MAX_NAME) configNameDraft += event.codepointAsString();
            return true;
        }
        if (searchFocused && event.isAllowedChatCharacter() && query.length() < 64) {
            query += event.codepointAsString();
            contentProgress = 0;
            return true;
        }
        return false;
    }

    private void change(Runnable action) { action.run(); dirty = true; flush(); }
    private void flush() { if (dirty) { save.run(); dirty = false; } }
    private String removeFirstCharacter(String value) { return value.isEmpty() ? value : value.substring(value.offsetByCodePoints(0, 1)); }
    private String removeLastCharacter(String value) { return value.isEmpty() ? value : value.substring(0, value.offsetByCodePoints(value.length(), -1)); }

    @Override
    public void tick() {
        // Complete removal during the input tick so cleanup cannot consume the next fresh key press.
        if (closing && screenProgress == 0 && minecraft.screen == this) minecraft.setScreen(null);
    }

    @Override
    public void onClose() {
        if (closing) return;
        commitBasesFound();
        if (!commitTimerDuration()) cancelTimerDuration();
        flush();
        closing = true;
        dragging = null;
        binding = -1;
        keyboardFocus = null;
        searchFocused = false;
    }

    @Override
    public void removed() {
        commitBasesFound();
        if (!commitTimerDuration()) cancelTimerDuration();
        binding = -1;
        capturedKey = null;
        ModuleKeybinds.suppressUntilReleased(minecraft);
        flush();
    }

    @Override
    public boolean isPauseScreen() { return false; }

    private record Hit(String id, int x, int y, int w, int h, Runnable action, Runnable secondary, DoubleConsumer drag, boolean vertical, IntConsumer nudge) {
        boolean contains(double mx, double my) { return mx >= x && my >= y && mx < x + w && my < y + h; }
        void move(double mx, double my) { drag.accept(vertical ? (my - y) / h : (mx - x) / w); }
    }

    private record Clip(int left, int right, int top, int bottom) { }

    private final class ColorEditor {
        final String title;
        final IntSupplier getter;
        final IntConsumer setter;
        String hex;
        boolean hexFocused;
        boolean replaceHex;
        ColorEditor(String title, IntSupplier getter, IntConsumer setter) {
            this.title = title;
            this.getter = getter;
            this.setter = setter;
            this.hex = DonutScreen.this.hex(getter.getAsInt()).substring(1);
        }
        void set(int color) {
            setter.accept(color & 0xFFFFFF);
            hex = DonutScreen.this.hex(color).substring(1);
            dirty = true;
        }
    }
}
