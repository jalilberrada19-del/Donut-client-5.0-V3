package dev.donut.client.rtp;

import dev.donut.client.config.ClientConfig;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.phys.Vec3;

/**
 * Sends the server's random-teleport command, waits for the teleport, checks the biome under the player,
 * and repeats after the cooldown until a chosen biome is found. It types the command exactly like a player
 * would and waits the configured cooldown between attempts.
 */
public final class RtpBiomeFinder {
    private enum State { IDLE, SEND, WAITING, SETTLING, COOLDOWN }
    /** A teleport moves the player at least this far (or to another dimension). */
    private static final double TELEPORT_DISTANCE = 96;
    private static final int SETTLE_TICKS = 40;
    private static RtpBiomeFinder instance;

    private final ClientConfig config;
    private final Runnable save;
    private State state = State.IDLE;
    private int attempts, settle;
    private long deadline;
    private Vec3 origin;
    private Object originLevel;
    private String status = "Choose biomes, then turn the module on to start.";

    public RtpBiomeFinder(ClientConfig config, Runnable save) {
        this.config = config;
        this.save = save;
        instance = this;
    }

    public static RtpBiomeFinder get() { return instance; }
    public String status() { return status; }
    public int attempts() { return attempts; }

    public void tick(Minecraft mc) {
        var settings = config.rtpFinder;
        if (!settings.enabled) {
            if (state != State.IDLE) { state = State.IDLE; status = "Stopped after " + attempts + (attempts == 1 ? " attempt." : " attempts."); }
            return;
        }
        if (mc.player == null || mc.level == null || mc.getConnection() == null) { stop("Join a server to search."); return; }
        long now = System.nanoTime();
        switch (state) {
            case IDLE -> {
                if (settings.biomes.isEmpty()) { stop("Add at least one biome first."); chat(mc, "Add at least one biome in the module settings first.", false); return; }
                attempts = 0;
                state = State.SEND;
            }
            case SEND -> {
                if (attempts >= settings.maxAttempts) {
                    stop("No match after " + attempts + " attempts.");
                    chat(mc, "No chosen biome after " + attempts + " attempts. Stopped.", false);
                    return;
                }
                origin = mc.player.position();
                originLevel = mc.level;
                attempts++;
                mc.getConnection().sendCommand(settings.command);
                deadline = now + seconds(settings.timeoutSeconds);
                status = "Attempt " + attempts + ": waiting for the teleport...";
                state = State.WAITING;
            }
            case WAITING -> {
                boolean moved = mc.level != originLevel || mc.player.position().distanceTo(origin) >= TELEPORT_DISTANCE;
                if (moved) { settle = SETTLE_TICKS; state = State.SETTLING; status = "Attempt " + attempts + ": landed, loading terrain..."; }
                else if (now >= deadline) {
                    chat(mc, "No teleport after " + settings.timeoutSeconds + " s. Retrying after the cooldown.", false);
                    cooldown(now, settings.cooldownSeconds);
                }
            }
            case SETTLING -> {
                if (--settle > 0) return;
                String biome = mc.level.getBiome(mc.player.blockPosition()).unwrapKey()
                        .map(key -> key.identifier().toString()).orElse("unknown");
                if (settings.biomes.contains(biome)) {
                    var pos = mc.player.blockPosition();
                    String found = "Found " + label(biome) + " at " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ()
                            + " after " + attempts + (attempts == 1 ? " attempt." : " attempts.");
                    chat(mc, found, true);
                    if (settings.sound) mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.PLAYER_LEVELUP, 1f));
                    settings.enabled = false;
                    save.run();
                    state = State.IDLE;
                    status = found;
                    if (settings.disconnectOnFind) mc.level.disconnect(Component.literal("[Donut] RTP Biome Finder: " + found));
                    return;
                }
                if (settings.chat) chat(mc, "Attempt " + attempts + ": " + label(biome) + ", not a match.", false);
                cooldown(now, settings.cooldownSeconds);
            }
            case COOLDOWN -> {
                if (now >= deadline) state = State.SEND;
                else status = "Attempt " + attempts + " done. Next /" + settings.command + " in "
                        + Math.max(1, (deadline - now + 999_999_999) / 1_000_000_000) + " s.";
            }
        }
    }

    private void cooldown(long now, int seconds) {
        deadline = now + seconds(seconds);
        state = State.COOLDOWN;
    }

    private void stop(String message) {
        config.rtpFinder.enabled = false;
        save.run();
        state = State.IDLE;
        status = message;
    }

    /** Called on disconnect: a search never continues on the next server. */
    public void disconnect() {
        if (state != State.IDLE) { config.rtpFinder.enabled = false; save.run(); }
        state = State.IDLE;
    }

    private void chat(Minecraft mc, String message, boolean success) {
        if (mc.player == null || !config.rtpFinder.chat && !success) return;
        mc.gui.getChat().addMessage(Component.literal("[RTP Finder] ").withColor(config.rtpFinder.color)
                .append(Component.literal(message).withStyle(success ? ChatFormatting.GREEN : ChatFormatting.GRAY)));
    }

    private static long seconds(int value) { return value * 1_000_000_000L; }

    /** Every vanilla biome ID, for the picker. Works without a world loaded. */
    private static List<String> biomeCache;

    public static List<String> allBiomes() {
        if (biomeCache != null) return biomeCache;
        var result = new ArrayList<String>();
        for (var field : Biomes.class.getFields()) {
            if (!Modifier.isStatic(field.getModifiers()) || field.getType() != ResourceKey.class) continue;
            try { result.add(((ResourceKey<?>) field.get(null)).identifier().toString()); }
            catch (IllegalAccessException ignored) { }
        }
        result.sort(String::compareTo);
        biomeCache = List.copyOf(result);
        return biomeCache;
    }

    /** "minecraft:cherry_grove" becomes the game's own name for the biome, e.g. "Cherry Grove". */
    public static String label(String id) {
        int colon = id.indexOf(':');
        String key = "biome." + (colon < 0 ? "minecraft" : id.substring(0, colon)) + "." + id.substring(colon + 1);
        String translated = Component.translatable(key).getString();
        if (!translated.equals(key)) return translated;
        String path = id.substring(colon + 1).replace('_', ' ');
        return path.isEmpty() ? id : path.substring(0, 1).toUpperCase(Locale.ROOT) + path.substring(1);
    }
}
