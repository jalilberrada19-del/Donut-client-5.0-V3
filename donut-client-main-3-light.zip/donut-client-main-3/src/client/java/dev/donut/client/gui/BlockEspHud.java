package dev.donut.client.gui;

import dev.donut.client.blockesp.BlockEspController;
import dev.donut.client.config.ClientConfig;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.level.block.Block;

public final class BlockEspHud {
    private static final int MAX_LINES = 8;

    private BlockEspHud() { }

    public static void render(GuiGraphics graphics, ClientConfig config, BlockEspController controller) {
        Minecraft client = Minecraft.getInstance();
        var settings = config.blockEsp;
        if (!settings.enabled || !settings.showHud || !config.showHud || client.options.hideGui || client.player == null || client.screen != null) return;
        var text = new ArrayList<String>();
        var colors = new ArrayList<Integer>();
        text.add("BlockESP | Predicted"); colors.add(0xFFE5EFF9);
        text.add(controller.status()); colors.add(0xFFB3C3D3);
        if (settings.showMined && !controller.mined().isEmpty()) {
            text.add("Already mined: " + controller.mined().size()); colors.add(0xFF000000 | settings.minedColor);
        }
        // Count per block and remember the nearest one (the snapshot is sorted nearest first).
        var counts = new LinkedHashMap<Block, int[]>();
        var nearest = new LinkedHashMap<Block, net.minecraft.core.BlockPos>();
        for (var marker : controller.snapshot()) {
            counts.computeIfAbsent(marker.block(), key -> new int[1])[0]++;
            nearest.putIfAbsent(marker.block(), marker.pos());
        }
        int shown = 0;
        for (var entry : controller.shownColors().entrySet()) {
            if (shown++ >= MAX_LINES) { text.add("+" + (controller.shownColors().size() - MAX_LINES) + " more"); colors.add(0xFFB3C3D3); break; }
            Block block = entry.getKey();
            int count = counts.containsKey(block) ? counts.get(block)[0] : 0;
            String label = block.getName().getString() + ": " + count;
            var pos = nearest.get(block);
            if (pos != null) {
                int distance = (int) Math.round(Math.sqrt(pos.distToCenterSqr(client.player.position())));
                label += " | " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ() + " | " + distance + "m";
            }
            text.add(label); colors.add(0xFF000000 | entry.getValue());
        }
        int maxWidth = Math.max(80, graphics.guiWidth() - 24);
        int w = text.stream().mapToInt(client.font::width).max().orElse(100) + 16;
        w = Math.min(w, maxWidth);
        int h = text.size() * 12 + 12, x = 8, y = graphics.guiHeight() - h - 8;
        UiPaint.round(graphics, x, y, w, h, 5, 0xC0141C27);
        for (int i = 0; i < text.size(); i++) graphics.drawString(client.font,
                client.font.plainSubstrByWidth(text.get(i), w - 16), x + 8, y + 7 + i * 12, colors.get(i), false);
    }
}
