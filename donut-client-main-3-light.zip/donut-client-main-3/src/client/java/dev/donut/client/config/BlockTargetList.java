package dev.donut.client.config;

import java.util.List;

/** A user-editable list of block targets, each with its own switch and color. */
public interface BlockTargetList {
    List<BlockEspSettings.Target> targets();

    /** Restores the list's default blocks. */
    void resetTargets();

    default BlockEspSettings.Target find(String id) {
        String key = BlockEspSettings.normalize(id);
        for (var target : targets()) if (target.block.equals(key)) return target;
        return null;
    }

    default boolean isEnabled(String id) {
        var target = find(id);
        return target != null && target.enabled;
    }

    default boolean addTarget(String id) {
        String key = BlockEspSettings.normalize(id);
        if (key == null || find(key) != null || targets().size() >= BlockEspSettings.MAX_TARGETS) return false;
        targets().add(new BlockEspSettings.Target(key, true, BlockEspSettings.defaultColor(key)));
        return true;
    }

    default void removeTarget(String id) {
        String key = BlockEspSettings.normalize(id);
        targets().removeIf(target -> target.block.equals(key));
    }

    /** Drops malformed or duplicate entries and caps the list. */
    static List<BlockEspSettings.Target> clean(List<BlockEspSettings.Target> targets) {
        var seen = new java.util.HashSet<String>();
        var result = new java.util.ArrayList<BlockEspSettings.Target>();
        for (var target : targets) {
            if (target == null) continue;
            String key = BlockEspSettings.normalize(target.block);
            if (key == null || !seen.add(key) || result.size() >= BlockEspSettings.MAX_TARGETS) continue;
            target.block = key;
            target.color &= 0xFFFFFF;
            result.add(target);
        }
        return result;
    }
}
