package dev.donut.client.gui;

import dev.donut.client.config.ClientConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Midnight / violet styling for vanilla widgets inside Donut screens. */
public final class DonutTheme {
    private static ClientConfig config;
    private static final int FIELD = 0xF00A0C18, BUTTON = 0xFF161A36, BUTTON_HOVER = 0xFF1E2246, DISABLED = 0xFF101326;

    private DonutTheme() { }

    public static void use(ClientConfig value) { config = value; }

    /** True while a themed Donut screen is open. */
    public static boolean active() { return config != null && Minecraft.getInstance().screen instanceof ThemedScreen; }

    private static int accent() { return config == null ? 0xFF6C5CFF : 0xFF000000 | config.accentColor; }

    public static void button(GuiGraphics g, int x, int y, int w, int h, boolean hovered, boolean enabled) {
        float r = Math.min(6, h / 2f);
        int fill = !enabled ? DISABLED : hovered ? UiPaint.blend(BUTTON_HOVER, accent(), .28) : BUTTON;
        UiPaint.round(g, x, y, w, h, r, fill);
        UiPaint.outline(g, x, y, w, h, r, !enabled ? 0x10FFFFFF : hovered ? UiPaint.alpha(accent(), .85) : 0x1EFFFFFF);
    }

    public static void field(GuiGraphics g, int x, int y, int w, int h, boolean focused) {
        UiPaint.round(g, x, y, w, h, 5, FIELD);
        UiPaint.outline(g, x, y, w, h, 5, focused ? UiPaint.alpha(accent(), .9) : 0x26FFFFFF);
    }

    /** Navy wash over the blurred world, with a soft accent glow at the top. */
    public static void background(GuiGraphics g, int width, int height) {
        g.fillGradient(0, 0, width, height, 0xE00B0D1A, 0xF0080A14);
        g.fillGradient(0, 0, width, Math.max(1, height / 3), UiPaint.alpha(accent(), .10), 0x00000000);
    }
}
