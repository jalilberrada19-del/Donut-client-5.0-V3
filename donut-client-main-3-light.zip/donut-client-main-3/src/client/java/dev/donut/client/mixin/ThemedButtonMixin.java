package dev.donut.client.mixin;

import dev.donut.client.gui.DonutTheme;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Inside Donut screens, buttons get the flat midnight style instead of the stone sprite. */
@Mixin(AbstractButton.class)
abstract class ThemedButtonMixin {
    @Inject(method = "renderDefaultSprite", at = @At("HEAD"), cancellable = true)
    private void donut$themedSprite(GuiGraphics graphics, CallbackInfo ci) {
        if (!DonutTheme.active()) return;
        var self = (AbstractButton) (Object) this;
        DonutTheme.button(graphics, self.getX(), self.getY(), self.getWidth(), self.getHeight(), self.isHoveredOrFocused(), self.isActive());
        ci.cancel();
    }
}
