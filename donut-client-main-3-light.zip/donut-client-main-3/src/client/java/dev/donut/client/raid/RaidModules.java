package dev.donut.client.raid;

import dev.donut.client.blockesp.BlockEspController;
import dev.donut.client.config.ClientConfig;
import dev.donut.client.config.RaidSettings;
import dev.donut.client.config.RaidSettings.EntityGroup;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundForgetLevelChunkPacket;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import net.minecraft.network.protocol.game.ClientboundLightUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundLightUpdatePacketData;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.piston.MovingPistonBlock;
import net.minecraft.world.level.block.piston.PistonBaseBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;

/**
 * Client-side detection for the Base Raid / Donut modules. Everything here only reads data the server
 * already sent (chunks, light and block updates); nothing is requested or sent back.
 */
public final class RaidModules {
    /** A box to draw: world bounds, RGB color, fill and outline opacity, and whether it may get a tracer. */
    public record Marker(AABB bounds, int rgb, double fill, double outline, boolean tracer) { }

    private record Hit(BlockPos pos, int rgb) { }
    private record EntityHit(BlockPos pos, EntityGroup group, String label, boolean trial) { }
    private record Flag(int chunkX, int chunkZ, int minY, int maxY, String reason, long time) { }

    private static final int CHUNKS_PER_TICK = 6, MAX_FLAGS = 256, MAX_PER_CHUNK = 512, TRACERS = 64;
    private static final long BASELINE_SETTLE_MS = 10_000;
    private static RaidModules instance;

    private final ClientConfig config;
    private ClientLevel level;
    private final Map<Long, List<Hit>> unnatural = new HashMap<>();
    private final Map<Long, List<EntityHit>> entities = new HashMap<>();
    private final Map<Long, List<BlockPos>> cobbled = new HashMap<>();
    // Chunks holding ancient city blocks; cobbled deepslate there (and next door) is natural.
    private final Set<Long> cityChunks = new HashSet<>();
    private final ArrayDeque<Long> queue = new ArrayDeque<>();
    private final Set<Long> queued = new HashSet<>();
    private final Set<Long> notifiedSpawners = new HashSet<>();
    private final LinkedHashMap<Long, Flag> hiddenBases = new LinkedHashMap<>();
    private final LinkedHashMap<Long, Flag> activity = new LinkedHashMap<>();
    private final Map<Long, Map<Integer, byte[]>> blockLight = new HashMap<>();
    private final Map<Long, Long> loadedAt = new HashMap<>();
    private final Map<net.minecraft.world.level.block.Block, Integer> unnaturalColors = new HashMap<>();
    private String scanKey = "";
    private List<Marker> markers = List.of();
    private boolean dirty = true;
    private int rebuildCooldown, refreshTick;
    private long lastPlayerChunk = Long.MIN_VALUE;
    // Chunk Refresh state.
    private boolean refreshArmed = true;
    private int refreshTimer = -1, savedDistance = -1;

    public RaidModules(ClientConfig config) {
        this.config = config;
        instance = this;
    }

    public static RaidModules get() { return instance; }
    /** The settings this engine reads (used by in-game tests). */
    public ClientConfig config() { return config; }
    public List<Marker> markers() { return markers; }

    public int unnaturalCount() { return unnatural.values().stream().mapToInt(List::size).sum(); }
    public int cobbledCount() { return cobbled.values().stream().mapToInt(List::size).sum(); }
    public int entityCount() { return entities.values().stream().mapToInt(List::size).sum(); }
    public int spawnerCount() {
        return (int) entities.values().stream().flatMap(List::stream).filter(hit -> hit.group() == EntityGroup.SPAWNERS).count();
    }
    public int hiddenBaseCount() { return hiddenBases.size(); }
    public int activityCount() { return activity.size(); }
    public void clearFlags() { hiddenBases.clear(); activity.clear(); dirty = true; }

    // ---------------------------------------------------------------- packet hooks (client thread)

    public static void chunkLoaded(ClientboundLevelChunkWithLightPacket packet) {
        if (instance != null) instance.onChunk(packet.getX(), packet.getZ(), packet.getLightData());
    }

    public static void lightUpdated(ClientboundLightUpdatePacket packet) {
        if (instance != null) instance.onLight(packet.getX(), packet.getZ(), packet.getLightData(), false);
    }

    public static void blockUpdated(ClientboundBlockUpdatePacket packet) {
        if (instance != null) instance.onBlock(packet.getPos(), packet.getBlockState());
    }

    public static void sectionUpdated(ClientboundSectionBlocksUpdatePacket packet) {
        if (instance != null) packet.runUpdates((pos, state) -> instance.onBlock(pos.immutable(), state));
    }

    public static void chunkForgotten(ClientboundForgetLevelChunkPacket packet) {
        if (instance == null) return;
        long key = packet.pos().toLong();
        instance.unnatural.remove(key);
        instance.cobbled.remove(key);
        instance.cityChunks.remove(key);
        instance.entities.remove(key);
        instance.blockLight.remove(key);
        instance.loadedAt.remove(key);
        instance.dirty = true;
    }

    private void onChunk(int x, int z, ClientboundLightUpdatePacketData light) {
        if (!sync()) return;
        long key = ChunkPos.asLong(x, z);
        loadedAt.put(key, System.currentTimeMillis());
        blockLight.remove(key);
        if (scanning()) enqueue(key);
        onLight(x, z, light, true);
    }

    private void onLight(int x, int z, ClientboundLightUpdatePacketData light, boolean fresh) {
        if (!sync() || light == null) return;
        long key = ChunkPos.asLong(x, z);
        int bottom = level.getMinSectionY() - 1;
        if (config.hiddenBase.enabled) checkHiddenBase(x, z, key, light, bottom);
        if (config.liveActivity.enabled && config.liveActivity.lightChanges) compareBlockLight(x, z, key, light, bottom, fresh);
    }

    private void onBlock(BlockPos pos, BlockState state) {
        if (!sync()) return;
        long key = ChunkPos.asLong(pos.getX() >> 4, pos.getZ() >> 4);
        var live = config.liveActivity;
        if (live.enabled && live.redstone && pos.getY() < 0 && isRedstone(state) && !ownArea(key)) {
            flagActivity(key, pos.getY(), pos.getY() + 1, "Redstone changed at " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ());
        }
        if (!scanning()) return;
        // Re-evaluate just this block for the block scans.
        var list = unnatural.get(key);
        if (list != null) {
            list.removeIf(hit -> hit.pos().equals(pos));
            int rgb = unnaturalColor(state, pos.getY());
            if (rgb >= 0 && !mineshaftTorch(state, pos) && list.size() < MAX_PER_CHUNK) list.add(new Hit(pos, rgb));
        }
        var deepslate = cobbled.get(key);
        if (deepslate != null) {
            deepslate.removeIf(hit -> hit.equals(pos));
            if (isCobbled(state, pos.getY()) && deepslate.size() < MAX_PER_CHUNK) deepslate.add(pos);
        }
        var found = entities.get(key);
        if (found != null) {
            found.removeIf(hit -> hit.pos().equals(pos));
            BlockEntity entity = level.getBlockEntity(pos);
            if (entity != null) acceptEntity(found, entity);
        }
        dirty = true;
    }

    // ---------------------------------------------------------------- tick

    public void tick(Minecraft mc) {
        tickRefresh(mc);
        if (!sync()) { markers = List.of(); return; }
        String key = currentScanKey();
        if (!key.equals(scanKey)) {
            scanKey = key;
            unnatural.clear();
        cobbled.clear();
        cityChunks.clear();
            entities.clear();
            queue.clear();
            queued.clear();
            rebuildUnnaturalColors();
            if (scanning()) queueLoaded(mc);
            dirty = true;
        }
        for (int i = 0; i < CHUNKS_PER_TICK && !queue.isEmpty(); i++) {
            long chunk = queue.removeFirst();
            queued.remove(chunk);
            scanChunk(chunk);
        }
        long now = System.currentTimeMillis();
        if (activity.values().removeIf(flag -> now - flag.time() > config.liveActivity.keepSeconds * 1000L)) dirty = true;
        if (mc.player != null) {
            long playerChunk = mc.player.chunkPosition().toLong();
            if (playerChunk != lastPlayerChunk) { lastPlayerChunk = playerChunk; dirty = true; }
        }
        // Refresh twice a second so setting changes (colors, filters, switches) show up quickly.
        if (++refreshTick % 10 == 0) dirty = true;
        // Rebuild at most every 5 ticks: block updates can arrive every tick.
        if (rebuildCooldown > 0) rebuildCooldown--;
        else if (dirty) { rebuildMarkers(mc); rebuildCooldown = 5; }
    }

    /** Called on disconnect and world change. */
    public void clear() {
        level = null;
        unnatural.clear();
        cobbled.clear();
        cityChunks.clear();
        entities.clear();
        queue.clear();
        queued.clear();
        notifiedSpawners.clear();
        hiddenBases.clear();
        activity.clear();
        blockLight.clear();
        loadedAt.clear();
        markers = List.of();
        scanKey = "";
        restoreDistance(Minecraft.getInstance());
    }

    private boolean sync() {
        var current = Minecraft.getInstance().level;
        if (current == null) { if (level != null) clear(); return false; }
        if (current != level) {
            clear();
            level = current;
        }
        return true;
    }

    private boolean scanning() {
        return config.unnaturalBlocks.enabled || config.blockEntityEsp.enabled || config.spawnerNotifier.enabled
                || config.cobbledDeepslate.enabled;
    }

    private String currentScanKey() {
        var u = config.unnaturalBlocks;
        var e = config.blockEntityEsp;
        var b = new StringBuilder();
        b.append(u.enabled).append(u.maxY).append(u.rotatedDeepslate).append(u.color);
        for (var target : u.targets()) if (target.enabled) b.append(target.block).append(target.color);
        b.append('|').append(e.enabled).append(config.spawnerNotifier.enabled).append(config.spawnerNotifier.trialSpawners);
        var c = config.cobbledDeepslate;
        b.append('|').append(u.ignoreMineshafts).append(c.enabled).append(c.maxY).append(c.variants);
        return b.toString();
    }

    private void queueLoaded(Minecraft mc) {
        if (mc.player == null) return;
        int radius = Math.max(2, mc.options.getEffectiveRenderDistance()) + 1;
        var center = mc.player.chunkPosition();
        var candidates = new ArrayList<Long>();
        for (int dz = -radius; dz <= radius; dz++) for (int dx = -radius; dx <= radius; dx++) {
            int x = center.x + dx, z = center.z + dz;
            if (level.getChunkSource().getChunk(x, z, false) != null) candidates.add(ChunkPos.asLong(x, z));
        }
        candidates.sort(Comparator.comparingInt(chunk -> {
            int dx = ChunkPos.getX(chunk) - center.x, dz = ChunkPos.getZ(chunk) - center.z;
            return dx * dx + dz * dz;
        }));
        candidates.forEach(this::enqueue);
    }

    private void enqueue(long key) { if (queued.add(key)) queue.addLast(key); }

    // ---------------------------------------------------------------- block scans

    private void rebuildUnnaturalColors() {
        unnaturalColors.clear();
        for (var target : config.unnaturalBlocks.targets()) {
            if (!target.enabled) continue;
            var block = BlockEspController.resolve(target.block);
            if (block != null) unnaturalColors.putIfAbsent(block, target.color);
        }
    }

    /** RGB for a block that counts as unnatural at this height, or -1. */
    private int unnaturalColor(BlockState state, int y) {
        var settings = config.unnaturalBlocks;
        if (!settings.enabled || y >= settings.maxY) return -1;
        Integer color = unnaturalColors.get(state.getBlock());
        if (color != null) return color;
        if (settings.rotatedDeepslate && state.is(Blocks.DEEPSLATE)
                && state.getValue(BlockStateProperties.AXIS) != Direction.Axis.Y) return settings.color;
        return -1;
    }

    private void scanChunk(long key) {
        LevelChunk chunk = level.getChunkSource().getChunk(ChunkPos.getX(key), ChunkPos.getZ(key), false);
        if (chunk == null) return;
        var mc = Minecraft.getInstance();
        if (config.unnaturalBlocks.enabled) {
            var hits = new ArrayList<Hit>();
            var sections = chunk.getSections();
            var cursor = new BlockPos.MutableBlockPos();
            boolean rotated = config.unnaturalBlocks.rotatedDeepslate;
            outer:
            for (int index = 0; index < sections.length; index++) {
                var section = sections[index];
                int bottom = chunk.getSectionYFromSectionIndex(index) * 16;
                if (bottom >= config.unnaturalBlocks.maxY) break;
                if (section.hasOnlyAir() || !section.maybeHas(state -> unnaturalColors.containsKey(state.getBlock())
                        || rotated && state.is(Blocks.DEEPSLATE))) continue;
                for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
                    var blockState = section.getBlockState(x, y, z);
                    int rgb = unnaturalColor(blockState, bottom + y);
                    if (rgb < 0) continue;
                    cursor.set(chunk.getPos().getMinBlockX() + x, bottom + y, chunk.getPos().getMinBlockZ() + z);
                    if (mineshaftTorch(blockState, cursor)) continue;
                    hits.add(new Hit(cursor.immutable(), rgb));
                    if (hits.size() >= MAX_PER_CHUNK) break outer;
                }
            }
            unnatural.put(key, hits);
        }
        if (config.cobbledDeepslate.enabled) {
            var settings = config.cobbledDeepslate;
            var hits = new ArrayList<BlockPos>();
            var sections = chunk.getSections();
            boolean city = false;
            outer:
            for (int index = 0; index < sections.length; index++) {
                var section = sections[index];
                int bottom = chunk.getSectionYFromSectionIndex(index) * 16;
                if (section.hasOnlyAir()) continue;
                if (!city && section.maybeHas(RaidModules::isAncientCityBlock)) {
                    for (int y = 0; y < 16 && !city; y++) for (int z = 0; z < 16 && !city; z++) for (int x = 0; x < 16 && !city; x++)
                        city = isAncientCityBlock(section.getBlockState(x, y, z));
                }
                if (bottom >= settings.maxY || !section.maybeHas(state -> isCobbled(state, Integer.MIN_VALUE))) continue;
                for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
                    if (!isCobbled(section.getBlockState(x, y, z), bottom + y)) continue;
                    hits.add(new BlockPos(chunk.getPos().getMinBlockX() + x, bottom + y, chunk.getPos().getMinBlockZ() + z));
                    if (hits.size() >= MAX_PER_CHUNK) break outer;
                }
            }
            if (city) cityChunks.add(key); else cityChunks.remove(key);
            cobbled.put(key, hits);
        }
        if (config.blockEntityEsp.enabled || config.spawnerNotifier.enabled) {
            var found = new ArrayList<EntityHit>();
            for (BlockEntity entity : chunk.getBlockEntities().values()) acceptEntity(found, entity);
            entities.put(key, found);
        }
        dirty = true;
    }

    /** Cobbled deepslate or, when enabled, its stairs, slabs and walls, below the chosen height. */
    private boolean isCobbled(BlockState state, int y) {
        var settings = config.cobbledDeepslate;
        if (y != Integer.MIN_VALUE && y >= settings.maxY) return false;
        if (state.is(Blocks.COBBLED_DEEPSLATE)) return true;
        return settings.variants && (state.is(Blocks.COBBLED_DEEPSLATE_STAIRS) || state.is(Blocks.COBBLED_DEEPSLATE_SLAB)
                || state.is(Blocks.COBBLED_DEEPSLATE_WALL));
    }

    /** Blocks only ancient cities place, which also use cobbled deepslate naturally. */
    static boolean isAncientCityBlock(BlockState state) {
        return state.is(Blocks.REINFORCED_DEEPSLATE) || state.is(Blocks.SCULK_SHRIEKER) || state.is(Blocks.SCULK_CATALYST)
                || state.is(Blocks.DEEPSLATE_TILES) || state.is(Blocks.CRACKED_DEEPSLATE_TILES) || state.is(Blocks.SOUL_LANTERN);
    }

    private boolean nearCity(long key) {
        int cx = ChunkPos.getX(key), cz = ChunkPos.getZ(key);
        for (int dz = -1; dz <= 1; dz++) for (int dx = -1; dx <= 1; dx++) if (cityChunks.contains(ChunkPos.asLong(cx + dx, cz + dz))) return true;
        return false;
    }

    /** A torch on, or right next to, mineshaft supports, rails or cobwebs is part of a natural mineshaft. */
    private boolean mineshaftTorch(BlockState state, BlockPos pos) {
        if (!config.unnaturalBlocks.ignoreMineshafts || !(state.is(Blocks.TORCH) || state.is(Blocks.WALL_TORCH))) return false;
        var cursor = new BlockPos.MutableBlockPos();
        for (int dy = -2; dy <= 2; dy++) for (int dz = -2; dz <= 2; dz++) for (int dx = -2; dx <= 2; dx++) {
            var near = level.getBlockState(cursor.set(pos.getX() + dx, pos.getY() + dy, pos.getZ() + dz));
            if (near.is(Blocks.OAK_FENCE) || near.is(Blocks.DARK_OAK_FENCE) || near.is(Blocks.OAK_PLANKS)
                    || near.is(Blocks.DARK_OAK_PLANKS) || near.is(Blocks.RAIL) || near.is(Blocks.COBWEB)) return true;
        }
        return false;
    }

    private static boolean withinRadius(Minecraft mc, long key, int radius) {
        if (mc.player == null) return false;
        var center = mc.player.chunkPosition();
        return Math.abs(ChunkPos.getX(key) - center.x) <= radius && Math.abs(ChunkPos.getZ(key) - center.z) <= radius;
    }

    private void acceptEntity(List<EntityHit> found, BlockEntity entity) {
        if (found.size() >= MAX_PER_CHUNK) return;
        var group = group(entity.getBlockState());
        String label = group == EntityGroup.SPAWNERS ? spawnerLabel(entity) : "";
        boolean trial = entity.getBlockState().getBlock() instanceof TrialSpawnerBlock;
        var hit = new EntityHit(entity.getBlockPos().immutable(), group, label, trial);
        found.add(hit);
        if (group == EntityGroup.SPAWNERS) notifySpawner(hit);
    }

    public static EntityGroup group(BlockState state) {
        var b = state.getBlock();
        if (b instanceof EnderChestBlock) return EntityGroup.ENDER_CHESTS;
        if (b instanceof ShulkerBoxBlock) return EntityGroup.SHULKERS;
        if (b instanceof AbstractChestBlock<?> || b instanceof BarrelBlock) return EntityGroup.CHESTS;
        if (b instanceof AbstractFurnaceBlock) return EntityGroup.FURNACES;
        if (b instanceof HopperBlock) return EntityGroup.HOPPERS;
        if (b instanceof DispenserBlock || b instanceof CrafterBlock) return EntityGroup.DISPENSERS;
        if (b instanceof BrewingStandBlock) return EntityGroup.BREWING;
        if (b instanceof BedBlock) return EntityGroup.BEDS;
        if (b instanceof SignBlock) return EntityGroup.SIGNS;
        if (b instanceof SpawnerBlock || b instanceof TrialSpawnerBlock) return EntityGroup.SPAWNERS;
        if (b instanceof MovingPistonBlock) return EntityGroup.PISTONS;
        return EntityGroup.OTHER;
    }

    private String spawnerLabel(BlockEntity entity) {
        if (entity instanceof SpawnerBlockEntity spawner) {
            try {
                var shown = spawner.getSpawner().getOrCreateDisplayEntity(level, entity.getBlockPos());
                if (shown != null) return shown.getType().getDescription().getString() + " spawner";
            } catch (RuntimeException ignored) { }
            return "Spawner";
        }
        return "Trial spawner";
    }

    private void notifySpawner(EntityHit hit) {
        var settings = config.spawnerNotifier;
        if (!settings.enabled || hit.trial() && !settings.trialSpawners || !notifiedSpawners.add(hit.pos().asLong())) return;
        var mc = Minecraft.getInstance();
        if (settings.chat) {
            String distance = mc.player == null ? "" : " (" + Math.round(Math.sqrt(hit.pos().distToCenterSqr(mc.player.position()))) + "m)";
            chat(mc, "Spawner Notifier", hit.label() + " at " + hit.pos().getX() + ", " + hit.pos().getY() + ", "
                    + hit.pos().getZ() + distance, settings.color);
        }
        if (settings.sound) ping(mc);
    }

    // ---------------------------------------------------------------- light-based detection

    /**
     * Vanilla sends an all-dark sky light section as "empty". A section that is present but fully zeroed
     * below Y 62 is how some servers (DonutSMP) hide what is underground, so it marks a likely base.
     */
    private void checkHiddenBase(int x, int z, long key, ClientboundLightUpdatePacketData light, int bottom) {
        var mask = light.getSkyYMask();
        var updates = light.getSkyUpdates();
        int data = 0, lowest = Integer.MAX_VALUE, highest = Integer.MIN_VALUE;
        for (int i = mask.nextSetBit(0); i >= 0; i = mask.nextSetBit(i + 1)) {
            if (data >= updates.size()) break;
            byte[] bytes = updates.get(data++);
            int sectionBottom = (bottom + i) * 16;
            if (sectionBottom + 15 >= 62 || !allZero(bytes)) continue;
            lowest = Math.min(lowest, sectionBottom);
            highest = Math.max(highest, sectionBottom + 16);
        }
        if (lowest == Integer.MAX_VALUE || hiddenBases.containsKey(key)) return;
        while (hiddenBases.size() >= MAX_FLAGS) hiddenBases.remove(hiddenBases.keySet().iterator().next());
        hiddenBases.put(key, new Flag(x, z, lowest, highest, "Hidden base signal", System.currentTimeMillis()));
        dirty = true;
        var settings = config.hiddenBase;
        var mc = Minecraft.getInstance();
        if (settings.chat) chat(mc, "Hidden Base", settings.showCoordinates
                ? "Possible base in chunk at " + (x * 16 + 8) + ", " + (z * 16 + 8) + " (below Y " + highest + ")"
                : "Possible base detected nearby", settings.color);
        if (settings.sound) ping(mc);
    }

    private static boolean allZero(byte[] bytes) {
        if (bytes == null || bytes.length != 2048) return false;
        for (byte value : bytes) if (value != 0) return false;
        return true;
    }

    /** Compares block light below Y 0 with the last copy; bright changes mean torches or lamps changed. */
    private void compareBlockLight(int x, int z, long key, ClientboundLightUpdatePacketData light, int bottom, boolean fresh) {
        var sections = blockLight.computeIfAbsent(key, ignored -> new HashMap<>());
        long loaded = loadedAt.getOrDefault(key, 0L);
        boolean settled = !fresh && System.currentTimeMillis() - loaded > BASELINE_SETTLE_MS && !ownArea(key);
        var mask = light.getBlockYMask();
        var updates = light.getBlockUpdates();
        int data = 0, changedY = Integer.MAX_VALUE;
        for (int i = mask.nextSetBit(0); i >= 0; i = mask.nextSetBit(i + 1)) {
            if (data >= updates.size()) break;
            byte[] next = updates.get(data++);
            int sectionBottom = (bottom + i) * 16;
            if (sectionBottom >= 0 || next == null || next.length != 2048) continue;
            byte[] previous = sections.put(i, next.clone());
            if (settled && previous != null && brightChange(previous, next)) changedY = Math.min(changedY, sectionBottom);
        }
        var empty = light.getEmptyBlockYMask();
        for (int i = empty.nextSetBit(0); i >= 0; i = empty.nextSetBit(i + 1)) {
            int sectionBottom = (bottom + i) * 16;
            if (sectionBottom >= 0) continue;
            byte[] previous = sections.put(i, new byte[2048]);
            if (settled && previous != null && brightChange(previous, new byte[2048])) changedY = Math.min(changedY, sectionBottom);
        }
        if (changedY != Integer.MAX_VALUE) flagActivity(key, changedY, changedY + 16,
                "Light changed near " + (x * 16 + 8) + ", " + (changedY + 8) + ", " + (z * 16 + 8));
    }

    private boolean brightChange(byte[] before, byte[] after) {
        int threshold = config.liveActivity.minLight;
        for (int i = 0; i < 2048; i++) {
            if (before[i] == after[i]) continue;
            for (int shift = 0; shift <= 4; shift += 4) {
                int a = before[i] >> shift & 15, b = after[i] >> shift & 15;
                if (a != b && Math.max(a, b) >= threshold) return true;
            }
        }
        return false;
    }

    private boolean ownArea(long key) {
        var player = Minecraft.getInstance().player;
        if (player == null || !config.liveActivity.ignoreOwnArea) return false;
        var center = player.chunkPosition();
        return Math.abs(ChunkPos.getX(key) - center.x) <= 1 && Math.abs(ChunkPos.getZ(key) - center.z) <= 1;
    }

    private void flagActivity(long key, int minY, int maxY, String reason) {
        boolean known = activity.containsKey(key);
        while (activity.size() >= MAX_FLAGS && !known) activity.remove(activity.keySet().iterator().next());
        activity.put(key, new Flag(ChunkPos.getX(key), ChunkPos.getZ(key), minY, maxY, reason, System.currentTimeMillis()));
        dirty = true;
        if (known) return;
        var settings = config.liveActivity;
        var mc = Minecraft.getInstance();
        if (settings.chat) chat(mc, "Live Activity", reason, settings.color);
        if (settings.sound) ping(mc);
    }

    private static boolean isRedstone(BlockState state) {
        var b = state.getBlock();
        return b instanceof RedStoneWireBlock || b instanceof DiodeBlock || b instanceof RedstoneTorchBlock
                || b instanceof LeverBlock || b instanceof ButtonBlock || b instanceof BasePressurePlateBlock
                || b instanceof PistonBaseBlock || b instanceof MovingPistonBlock || b instanceof ObserverBlock
                || b instanceof DispenserBlock || b instanceof HopperBlock || b instanceof RedstoneLampBlock
                || b instanceof DaylightDetectorBlock || b instanceof TripWireHookBlock || b instanceof TargetBlock
                || b instanceof DoorBlock || b instanceof TrapDoorBlock || b instanceof FenceGateBlock;
    }

    // ---------------------------------------------------------------- Chunk Refresh

    /** Lowers render distance for half a second so the server resends nearby chunks. */
    public void refreshNow(Minecraft mc) {
        if (mc.player == null || refreshTimer >= 0) return;
        savedDistance = mc.options.renderDistance().get();
        applyDistance(mc, Math.min(savedDistance, config.chunkRefresh.lowDistance));
        refreshTimer = 10;
        if (config.chunkRefresh.chat) chat(mc, "Chunk Refresh", "Reloading chunks...", 0x7D6FFF);
    }

    private void tickRefresh(Minecraft mc) {
        var settings = config.chunkRefresh;
        if (refreshTimer >= 0) {
            if (refreshTimer-- == 0) restoreDistance(mc);
            return;
        }
        if (!settings.enabled || mc.player == null) return;
        double y = mc.player.getY();
        if (y >= settings.triggerY + 2) refreshArmed = true;
        else if (refreshArmed && y < settings.triggerY) {
            refreshArmed = false;
            refreshNow(mc);
        }
    }

    private void restoreDistance(Minecraft mc) {
        if (savedDistance > 0) applyDistance(mc, savedDistance);
        savedDistance = -1;
        refreshTimer = -1;
    }

    private static void applyDistance(Minecraft mc, int distance) {
        mc.options.renderDistance().set(distance);
        mc.options.broadcastOptions();
    }

    // ---------------------------------------------------------------- output

    private void rebuildMarkers(Minecraft mc) {
        dirty = false;
        var result = new ArrayList<Marker>();
        var player = mc.player;
        if (config.unnaturalBlocks.enabled) {
            var hits = new ArrayList<Hit>();
            for (var entry : unnatural.entrySet()) if (withinRadius(mc, entry.getKey(), config.unnaturalBlocks.radius)) hits.addAll(entry.getValue());
            if (player != null) hits.sort(Comparator.comparingDouble(hit -> hit.pos().distToCenterSqr(player.position())));
            for (int i = 0; i < Math.min(hits.size(), RaidSettings.UnnaturalBlocks.MAX_MARKERS); i++)
                result.add(new Marker(new AABB(hits.get(i).pos()).inflate(.004), hits.get(i).rgb(), .14, .9, config.unnaturalBlocks.tracers));
        }
        var esp = config.blockEntityEsp;
        int ceiling = esp.depthCeiling();
        for (var list : entities.values()) for (var hit : list) {
            var notifier = config.spawnerNotifier;
            boolean spawner = hit.group() == EntityGroup.SPAWNERS && (!hit.trial() || notifier.trialSpawners);
            if (spawner && notifier.enabled && notifier.render) {
                result.add(new Marker(new AABB(hit.pos()).inflate(.01), config.spawnerNotifier.color, .18, 1, config.spawnerNotifier.tracers));
                continue;
            }
            if (!esp.enabled || hit.pos().getY() >= ceiling || !esp.groupEnabled(hit.group())) continue;
            result.add(new Marker(new AABB(hit.pos()).inflate(.006), esp.groupColor(hit.group()), esp.opacity / 255.0 * .25,
                    esp.opacity / 255.0, esp.tracers));
        }
        if (config.cobbledDeepslate.enabled) {
            var settings = config.cobbledDeepslate;
            var hits = new ArrayList<BlockPos>();
            for (var entry : cobbled.entrySet()) {
                if (!withinRadius(mc, entry.getKey(), settings.radius)) continue;
                if (settings.ignoreAncientCities && nearCity(entry.getKey())) continue;
                hits.addAll(entry.getValue());
            }
            if (player != null) hits.sort(Comparator.comparingDouble(pos -> pos.distToCenterSqr(player.position())));
            for (int i = 0; i < Math.min(hits.size(), RaidSettings.UnnaturalBlocks.MAX_MARKERS); i++)
                result.add(new Marker(new AABB(hits.get(i)).inflate(.004), settings.color, .14, .9, settings.tracers));
        }
        if (config.hiddenBase.enabled) for (var flag : hiddenBases.values()) result.add(chunkMarker(flag, config.hiddenBase.color, config.hiddenBase.tracers));
        if (config.liveActivity.enabled) for (var flag : activity.values()) result.add(chunkMarker(flag, config.liveActivity.color, config.liveActivity.tracers));
        if (player != null) result.sort(Comparator.comparingDouble(marker -> marker.bounds().getCenter().distanceToSqr(player.position())));
        // Only the nearest markers keep their tracer to avoid a wall of lines.
        int tracers = 0;
        for (int i = 0; i < result.size(); i++) {
            var marker = result.get(i);
            if (marker.tracer() && tracers++ >= TRACERS) result.set(i, new Marker(marker.bounds(), marker.rgb(), marker.fill(), marker.outline(), false));
        }
        markers = List.copyOf(result);
    }

    private static Marker chunkMarker(Flag flag, int rgb, boolean tracer) {
        double x = flag.chunkX() * 16, z = flag.chunkZ() * 16;
        return new Marker(new AABB(x, flag.minY(), z, x + 16, flag.maxY(), z + 16), rgb, .06, .95, tracer);
    }

    private static void chat(Minecraft mc, String module, String message, int rgb) {
        if (mc.player == null) return;
        mc.gui.getChat().addMessage(Component.literal("[" + module + "] ").withColor(rgb)
                .append(Component.literal(message).withStyle(ChatFormatting.GRAY)));
    }

    private static void ping(Minecraft mc) {
        mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_PLING, 1.6f));
    }
}
