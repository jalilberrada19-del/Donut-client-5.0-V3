package dev.donut.client.config;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Preferences for the Base Raid / Donut detection modules. */
public final class RaidSettings {
    private RaidSettings() { }

    /** Common switches every detection module shares. */
    public abstract static class Module {
        public boolean enabled, favorite;
        public boolean tracers = false, sound = true, chat = true;
        public int color;

        void sanitizeCommon() { color &= 0xFFFFFF; }
    }

    /** Blocks that terrain generation does not place deep underground. */
    public static final class UnnaturalBlocks extends Module implements BlockTargetList {
        public static final List<String> DEFAULTS = List.of(
                "minecraft:crafting_table", "minecraft:furnace", "minecraft:blast_furnace", "minecraft:smoker",
                "minecraft:glass", "minecraft:glass_pane", "minecraft:torch", "minecraft:wall_torch",
                "minecraft:spruce_planks", "minecraft:birch_planks", "minecraft:jungle_planks", "minecraft:acacia_planks",
                "minecraft:mangrove_planks", "minecraft:cherry_planks", "minecraft:bamboo_planks",
                "minecraft:crimson_planks", "minecraft:warped_planks", "minecraft:stone_bricks", "minecraft:bricks",
                "minecraft:smooth_stone", "minecraft:scaffolding", "minecraft:hay_block", "minecraft:slime_block",
                "minecraft:honey_block", "minecraft:iron_block", "minecraft:gold_block", "minecraft:diamond_block",
                "minecraft:emerald_block", "minecraft:netherite_block", "minecraft:redstone_block", "minecraft:red_bed",
                "minecraft:white_bed", "minecraft:sandstone", "minecraft:terracotta");
        public static final int MAX_MARKERS = 4096;
        /** Only blocks below this height count; surface villages and ruins are full of these blocks. */
        public int maxY = 0;
        public boolean rotatedDeepslate = true;
        /** Natural mineshafts hang torches on their oak or dark oak supports; skip those. */
        public boolean ignoreMineshafts = true;
        public int radius = 8;
        public List<BlockEspSettings.Target> targets;

        public UnnaturalBlocks() { color = 0xFF8A3D; chat = false; }

        @Override public List<BlockEspSettings.Target> targets() {
            if (targets == null) resetTargets();
            return targets;
        }

        @Override public void resetTargets() {
            targets = new ArrayList<>();
            for (String id : DEFAULTS) targets.add(new BlockEspSettings.Target(id, true, color));
        }

        public void sanitize() {
            sanitizeCommon();
            maxY = Math.clamp(maxY, -64, 320);
            radius = Math.clamp(radius, 2, 16);
            targets = BlockTargetList.clean(targets());
        }
    }

    /** Cobbled deepslate (and its stairs, slabs and walls): it only appears where players mined and placed blocks. */
    public static final class CobbledDeepslate extends Module {
        public int maxY = 16, radius = 8;
        public boolean variants = true, ignoreAncientCities = true;
        public CobbledDeepslate() { color = 0x8FA3C7; chat = false; sound = false; }
        public void sanitize() {
            sanitizeCommon();
            maxY = Math.clamp(maxY, -64, 320);
            radius = Math.clamp(radius, 2, 16);
        }
    }

    /** Repeats /rtp until you land in one of the chosen biomes, then optionally disconnects. */
    /** Boxes and optional tracers on other players, plus a list of the nearest ones. */
    public static final class PlayerEsp extends Module {
        public int range = 128, listRows = 6;
        public boolean showList = true, includeInvisible = true, staffColor = true;
        public PlayerEsp() { color = 0x6C9BFF; tracers = true; chat = false; sound = false; }
        public void sanitize() {
            sanitizeCommon();
            range = Math.clamp(range, 16, 512);
            listRows = Math.clamp(listRows, 1, 12);
        }
    }

    public static final class RtpFinder extends Module {
        public static final List<String> COMMANDS = List.of("rtp", "rtp overworld", "wild", "randomtp");
        public String command = "rtp";
        public List<String> biomes = new ArrayList<>();
        public int cooldownSeconds = 12, maxAttempts = 40, timeoutSeconds = 20;
        public boolean disconnectOnFind = true;
        public RtpFinder() { color = 0x3DD68C; }

        public boolean addBiome(String id) {
            String key = BlockEspSettings.normalize(id);
            if (key == null || biomes.contains(key) || biomes.size() >= 64) return false;
            biomes.add(key);
            return true;
        }

        public void sanitize() {
            sanitizeCommon();
            if (command == null || !COMMANDS.contains(command)) command = COMMANDS.getFirst();
            if (biomes == null) biomes = new ArrayList<>();
            var clean = new ArrayList<String>();
            for (String biome : biomes) { String key = BlockEspSettings.normalize(biome); if (key != null && !clean.contains(key)) clean.add(key); }
            biomes = clean;
            cooldownSeconds = Math.clamp(cooldownSeconds, 3, 300);
            maxAttempts = Math.clamp(maxAttempts, 1, 500);
            timeoutSeconds = Math.clamp(timeoutSeconds, 5, 120);
        }
    }

    /** Block entity groups, from the block that owns the block entity. */
    public enum EntityGroup {
        CHESTS("Chests & barrels", 0xFFCA54), SHULKERS("Shulker boxes", 0xC77DFF), ENDER_CHESTS("Ender chests", 0x8F6BFF),
        FURNACES("Furnaces & smokers", 0xFF944D), HOPPERS("Hoppers", 0x51E5FF), DISPENSERS("Dispensers & droppers", 0xFF6B6B),
        BREWING("Brewing stands", 0xF38BA8), BEDS("Beds", 0xFF4D6A), SIGNS("Signs", 0xD9C7A3),
        SPAWNERS("Spawners", 0xFF63F1), PISTONS("Moving pistons", 0x9BE564), OTHER("Everything else", 0xB0B8D0);

        public final String label;
        public final int color;
        EntityGroup(String label, int color) { this.label = label; this.color = color; }
        public String id() { return name().toLowerCase(java.util.Locale.ROOT).replace('_', '-'); }
    }

    /** Shows every block entity the server sends, so hidden storage shows through walls. */
    public static final class BlockEntityEsp extends Module {
        public static final List<String> DEPTHS = List.of("Everywhere", "Below Y 0", "Below Y -20", "Below Y -30");
        // Surface villages and structures are full of chests; bases hide underground.
        public String depth = "Below Y 0";
        public Map<String, Boolean> groups = new LinkedHashMap<>();
        public Map<String, Integer> colors = new LinkedHashMap<>();
        public int opacity = 200;

        public BlockEntityEsp() { sound = false; chat = false; }

        public boolean groupEnabled(EntityGroup group) {
            Boolean value = groups.get(group.id());
            return value == null ? group != EntityGroup.SIGNS : value;
        }

        public int groupColor(EntityGroup group) {
            Integer value = colors.get(group.id());
            return (value == null ? group.color : value) & 0xFFFFFF;
        }

        /** Highest Y (exclusive) allowed by the depth filter. */
        public int depthCeiling() {
            return switch (depth) { case "Below Y 0" -> 0; case "Below Y -20" -> -20; case "Below Y -30" -> -30; default -> Integer.MAX_VALUE; };
        }

        public void sanitize() {
            sanitizeCommon();
            if (!DEPTHS.contains(depth)) depth = "Below Y 0";
            if (groups == null) groups = new LinkedHashMap<>();
            if (colors == null) colors = new LinkedHashMap<>();
            opacity = Math.clamp(opacity, 0, 255);
        }
    }

    /** Spawners and trial spawners, with a chat message for each new one. */
    public static final class SpawnerNotifier extends Module {
        // Trial spawners are natural structures, not player farms.
        public boolean render = true, trialSpawners = false;
        public SpawnerNotifier() { color = 0xFF63F1; tracers = true; }
        public void sanitize() { sanitizeCommon(); }
    }

    /** Chunks where the server sends blanked sky light underground, a sign of a protected base. */
    public static final class HiddenBase extends Module {
        public boolean showCoordinates = true;
        public HiddenBase() { color = 0xFF4D6A; tracers = true; }
        public void sanitize() { sanitizeCommon(); }
    }

    /** Light or redstone changing below Y 0 while you watch: someone is active there now. */
    public static final class LiveActivity extends Module {
        public boolean lightChanges = true, redstone = true, ignoreOwnArea = true;
        /** Minimum brightness of a changed light for it to count (torches are 14, redstone ore glows at 9). */
        public int minLight = 10;
        public int keepSeconds = 300;
        public LiveActivity() { color = 0x3DD68C; }
        public void sanitize() {
            sanitizeCommon();
            minLight = Math.clamp(minLight, 1, 15);
            keepSeconds = Math.clamp(keepSeconds, 10, 3600);
        }
    }

    /** Briefly lowers render distance when you go underground, so the server resends fresh chunks. */
    public static final class ChunkRefresh extends Module {
        public int triggerY = 0, lowDistance = 2;
        public ChunkRefresh() { sound = false; chat = true; }
        public void sanitize() {
            sanitizeCommon();
            triggerY = Math.clamp(triggerY, -64, 320);
            lowDistance = Math.clamp(lowDistance, 2, 8);
        }
    }
}
