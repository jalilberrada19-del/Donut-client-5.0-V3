package dev.donut.client.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import dev.donut.client.gui.DonutTheme;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Inside Donut screens, text fields get a dark rounded box with an accent outline when focused. */
@Mixin(EditBox.class)
abstract class ThemedEditBoxMixin {
    @WrapOperation(method = "renderWidget", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIII)V"))
    private void donut$themedField(GuiGraphics graphics, RenderPipeline pipeline, Identifier sprite, int x, int y, int w, int h, Operation<Void> original) {
        if (!DonutTheme.active()) { original.call(graphics, pipeline, sprite, x, y, w, h); return; }
        DonutTheme.field(graphics, x, y, w, h, ((EditBox) (Object) this).isFocused());
    }
}
