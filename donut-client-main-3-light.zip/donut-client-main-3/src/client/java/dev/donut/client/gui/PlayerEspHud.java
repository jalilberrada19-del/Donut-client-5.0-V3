package dev.donut.client.gui;

import dev.donut.client.config.ClientConfig;
import java.util.ArrayList;
import java.util.Comparator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;

/** Nearest players with their distance, on the right edge (below the module list). */
public final class PlayerEspHud {
    private PlayerEspHud() { }

    public static void render(GuiGraphics g, ClientConfig config) {
        var mc = Minecraft.getInstance();
        var settings = config.playerEsp;
        if (!settings.enabled || !settings.showList || !config.showHud || mc.player == null || mc.level == null
                || mc.screen != null || mc.options.hideGui) return;
        var players = new ArrayList<Player>();
        for (var player : mc.level.players()) {
            if (player == mc.player) continue;
            if ((player.isInvisible() || player.isSpectator()) && !settings.includeInvisible) continue;
            if (player.distanceToSqr(mc.player) > (double) settings.range * settings.range) continue;
            players.add(player);
        }
        players.sort(Comparator.comparingDouble(player -> player.distanceToSqr(mc.player)));
        var lines = new ArrayList<String>();
        lines.add("Players nearby | " + players.size());
        for (int i = 0; i < Math.min(players.size(), settings.listRows); i++) {
            var player = players.get(i);
            String name = config.nameHider.enabled ? "Player" : player.getGameProfile().name();
            String flags = player.isSpectator() ? " (spectator)" : player.isInvisible() ? " (invisible)" : "";
            lines.add(name + flags + " | " + Math.round(Math.sqrt(player.distanceToSqr(mc.player))) + "m");
        }
        if (players.size() > settings.listRows) lines.add("+" + (players.size() - settings.listRows) + " more");
        int w = Math.min(g.guiWidth() - 16, lines.stream().mapToInt(mc.font::width).max().orElse(80) + 16);
        int h = 12 + lines.size() * 12, x = g.guiWidth() - w - 8, y = Math.max(8, (g.guiHeight() - h) / 2);
        UiPaint.round(g, x, y, w, h, 5, 0xC0141C27);
        for (int i = 0; i < lines.size(); i++) {
            int color = i == 0 ? 0xFFE5EFF9 : 0xFF000000 | settings.color;
            g.drawString(mc.font, mc.font.plainSubstrByWidth(lines.get(i), w - 16), x + 8, y + 7 + i * 12, color, false);
        }
    }
}
