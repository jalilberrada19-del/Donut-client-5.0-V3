package dev.donut.client.config;

public final class ClientConfig {
    public int schemaVersion = 1;
    public FreecamSettings freecam = new FreecamSettings();
    public AutoBuilderSettings autoBuilder = new AutoBuilderSettings();
    public ChunkFinderSettings chunkFinder = new ChunkFinderSettings();
    public LightDebugSettings lightDebug = new LightDebugSettings();
    public BlockEspSettings blockEsp = new BlockEspSettings();
    public SoundDetectorSettings soundDetector = new SoundDetectorSettings();
    public StaffDetectorSettings staffDetector = new StaffDetectorSettings();
    public RaidSettings.UnnaturalBlocks unnaturalBlocks = new RaidSettings.UnnaturalBlocks();
    public RaidSettings.BlockEntityEsp blockEntityEsp = new RaidSettings.BlockEntityEsp();
    public RaidSettings.SpawnerNotifier spawnerNotifier = new RaidSettings.SpawnerNotifier();
    public RaidSettings.HiddenBase hiddenBase = new RaidSettings.HiddenBase();
    public RaidSettings.LiveActivity liveActivity = new RaidSettings.LiveActivity();
    public RaidSettings.ChunkRefresh chunkRefresh = new RaidSettings.ChunkRefresh();
    public RaidSettings.CobbledDeepslate cobbledDeepslate = new RaidSettings.CobbledDeepslate();
    public RaidSettings.RtpFinder rtpFinder = new RaidSettings.RtpFinder();
    public RaidSettings.PlayerEsp playerEsp = new RaidSettings.PlayerEsp();
    public AmethystSettings amethyst = new AmethystSettings();
    public FullbrightSettings fullbright = new FullbrightSettings();
    public FlySettings fly = new FlySettings();
    public ProgressBarSettings progressBar = new ProgressBarSettings();
    public NameHiderSettings nameHider = new NameHiderSettings();
    public HotbarSettings hotbar = new HotbarSettings();
    public int accentColor = 0x6C5CFF;
    public ClickGuiStyle clickGuiStyle = new ClickGuiStyle();
    public boolean clickGuiParticles = true;
    public boolean showHud = true;


    public void sanitize() {
        if (clickGuiStyle == null) clickGuiStyle = new ClickGuiStyle();
        clickGuiStyle.sanitize();
        if (freecam == null) freecam = new FreecamSettings();
        if (autoBuilder == null) autoBuilder = new AutoBuilderSettings();
        if (chunkFinder == null) chunkFinder = new ChunkFinderSettings();
        if (amethyst == null) amethyst = new AmethystSettings();
        if (fullbright == null) fullbright = new FullbrightSettings();
        if (fly == null) fly = new FlySettings();
        if (progressBar == null) progressBar = new ProgressBarSettings();
        if (nameHider == null) nameHider = new NameHiderSettings();
        if (hotbar == null) hotbar = new HotbarSettings();
        freecam.sanitize();
        autoBuilder.sanitize();
        chunkFinder.sanitize();
        amethyst.sanitize();
        if (lightDebug == null) lightDebug = new LightDebugSettings();
        lightDebug.sanitize();
        if (blockEsp == null) blockEsp = new BlockEspSettings();
        blockEsp.sanitize();
        if (soundDetector == null) soundDetector = new SoundDetectorSettings();
        soundDetector.sanitize();
        if (staffDetector == null) staffDetector = new StaffDetectorSettings();
        staffDetector.sanitize();
        if (unnaturalBlocks == null) unnaturalBlocks = new RaidSettings.UnnaturalBlocks();
        unnaturalBlocks.sanitize();
        if (blockEntityEsp == null) blockEntityEsp = new RaidSettings.BlockEntityEsp();
        blockEntityEsp.sanitize();
        if (spawnerNotifier == null) spawnerNotifier = new RaidSettings.SpawnerNotifier();
        spawnerNotifier.sanitize();
        if (hiddenBase == null) hiddenBase = new RaidSettings.HiddenBase();
        hiddenBase.sanitize();
        if (liveActivity == null) liveActivity = new RaidSettings.LiveActivity();
        liveActivity.sanitize();
        if (chunkRefresh == null) chunkRefresh = new RaidSettings.ChunkRefresh();
        chunkRefresh.sanitize();
        if (cobbledDeepslate == null) cobbledDeepslate = new RaidSettings.CobbledDeepslate();
        cobbledDeepslate.sanitize();
        if (rtpFinder == null) rtpFinder = new RaidSettings.RtpFinder();
        rtpFinder.sanitize();
        if (playerEsp == null) playerEsp = new RaidSettings.PlayerEsp();
        playerEsp.sanitize();
        progressBar.sanitize();
        hotbar.sanitize();
        accentColor &= 0xFFFFFF;
    }
}
