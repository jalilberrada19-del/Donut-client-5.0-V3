package dev.donut.client.gui;

/** Marks Donut screens whose vanilla buttons, text fields and background use the Donut theme. */
public interface ThemedScreen {
    /** Positioning editors keep the world visible behind them and only theme their widgets. */
    default boolean themedBackground() { return true; }
}
