package dev.donut.client.config;

import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class BlockEspSettingsTest {
    @TempDir Path directory;

    @Test void missingAndNullPreferencesUseTheRequestedSeedAndDefaultTargets() throws Exception {
        Path file = directory.resolve("settings.json");
        for (String json : new String[] {"{}", "{\"blockEsp\":null}"}) {
            Files.writeString(file, json);
            var value = new ConfigStore(file).load().blockEsp;
            assertEquals("6608149111735331168", value.seed);
            assertEquals(3, value.targets().size());
            assertTrue(value.isEnabled(BlockEspSettings.COAL) && value.isEnabled(BlockEspSettings.EMERALD)
                    && value.isEnabled(BlockEspSettings.DEBRIS));
            assertFalse(value.enabled);
        }
    }

    @Test void legacyTogglesAndColorsMigrateToTargets() throws Exception {
        Path file = directory.resolve("legacy.json");
        Files.writeString(file, "{\"blockEsp\":{\"coal\":false,\"emerald\":true,\"emeraldColor\":1193046}}");
        var value = new ConfigStore(file).load().blockEsp;
        assertFalse(value.isEnabled(BlockEspSettings.COAL));
        assertTrue(value.isEnabled(BlockEspSettings.EMERALD) && value.isEnabled(BlockEspSettings.DEBRIS));
        assertEquals(0x123456, value.find(BlockEspSettings.EMERALD).color);
        assertNull(value.coal);
    }

    @Test void anyBlockCanBeAddedOnceAndRemoved() {
        var value = new BlockEspSettings();
        assertTrue(value.addTarget("Diamond_Ore"));
        assertNotNull(value.find("minecraft:diamond_ore"));
        assertFalse(value.addTarget("minecraft:diamond_ore"), "Duplicate target");
        assertFalse(value.addTarget("not valid!"), "Malformed ID");
        value.removeTarget("diamond_ore");
        assertNull(value.find("minecraft:diamond_ore"));
        assertEquals(3, value.targets().size());
    }

    @Test void full64BitSeedAndIndependentPreferencesSurviveJson() throws Exception {
        var config = new ClientConfig();
        config.blockEsp.seed = "6608149111735331168";
        config.blockEsp.enabled = config.blockEsp.favorite = config.blockEsp.tracers = true;
        config.blockEsp.find(BlockEspSettings.COAL).enabled = false;
        config.blockEsp.radius = 999;
        config.blockEsp.opacity = -1;
        config.blockEsp.find(BlockEspSettings.EMERALD).color = 0xAA123456;
        config.blockEsp.addTarget("minecraft:diamond_ore");
        var store = new ConfigStore(directory.resolve("settings.json"));
        store.save(config);
        var value = store.load().blockEsp;
        assertEquals(6608149111735331168L, BlockEspSettings.parseSeed(value.seed));
        assertTrue(value.enabled && value.favorite && value.tracers && value.isEnabled(BlockEspSettings.EMERALD));
        assertFalse(value.isEnabled(BlockEspSettings.COAL));
        assertTrue(value.isEnabled("minecraft:diamond_ore"));
        assertEquals(16, value.radius);
        assertEquals(0, value.opacity);
        assertEquals(0x123456, value.find(BlockEspSettings.EMERALD).color);
        assertTrue(Files.readString(directory.resolve("settings.json")).contains("\"6608149111735331168\""));
    }


    @Test void numericValidationCoversSignedLimitsAndRejectsLossyOrMalformedSeeds() {
        assertEquals(Long.MIN_VALUE, BlockEspSettings.parseSeed("-9223372036854775808"));
        assertEquals(Long.MAX_VALUE, BlockEspSettings.parseSeed("9223372036854775807"));
        assertEquals(0, BlockEspSettings.parseSeed(" 0 "));
        for (String invalid : new String[] {"", "-", "9223372036854775808", "-9223372036854775809", "1.2", "6.6E18", "hello", "12 34"})
            assertThrows(IllegalArgumentException.class, () -> BlockEspSettings.parseSeed(invalid), invalid);
        var settings = new BlockEspSettings(); settings.seed = "invalid"; settings.sanitize();
        assertEquals("invalid", settings.seed, "Invalid persisted input must not become another valid seed");
    }
}
