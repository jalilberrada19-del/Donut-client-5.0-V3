package dev.donut.client.config;

import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class SharedConfigsTest {
    @TempDir Path directory;

    private static ClientConfig personalConfig() {
        var config = new ClientConfig();
        config.accentColor = 0x123456;
        config.blockEntityEsp.enabled = true;
        config.unnaturalBlocks.maxY = -20;
        config.blockEsp.seed = "424242";
        config.staffDetector.rosters.put("play.example.net", new java.util.ArrayList<>(List.of(new StaffDetectorSettings.Member("", "SomeMod"))));
        config.progressBar.basesFound = 7;
        return config;
    }

    @Test void shareCodesRoundTripWithoutPersonalData() throws Exception {
        String code = SharedConfigs.shareCode("My raid setup", personalConfig());
        assertTrue(code.startsWith(SharedConfigs.CODE_PREFIX));
        var shared = SharedConfigs.decode("Here you go: " + code + "  ");
        assertEquals("My raid setup", shared.name());
        assertEquals(0x123456, shared.config().accentColor);
        assertTrue(shared.config().blockEntityEsp.enabled);
        assertEquals(-20, shared.config().unnaturalBlocks.maxY);
        assertTrue(shared.config().staffDetector.rosters.isEmpty(), "Staff lists name servers and must not be shared");
        assertEquals(0, shared.config().progressBar.basesFound);
        assertEquals(BlockEspSettings.DEFAULT_SEED, shared.config().blockEsp.seed);
    }

    @Test void applyingKeepsPersonalDataAndObjectIdentity() throws Exception {
        var mine = personalConfig();
        var esp = mine.blockEntityEsp;
        var theirs = new ClientConfig();
        theirs.accentColor = 0xABCDEF;
        theirs.blockEntityEsp.enabled = false;
        theirs.blockEntityEsp.depth = "Below Y -30";
        theirs.unnaturalBlocks.addTarget("cobblestone");
        SharedConfigs.apply(SharedConfigs.decode(SharedConfigs.shareCode("Theirs", theirs)).config(), mine);
        assertSame(esp, mine.blockEntityEsp, "Modules keep their settings object");
        assertEquals(0xABCDEF, mine.accentColor);
        assertFalse(mine.blockEntityEsp.enabled);
        assertEquals("Below Y -30", mine.blockEntityEsp.depth);
        assertTrue(mine.unnaturalBlocks.isEnabled("minecraft:cobblestone"));
        assertEquals("424242", mine.blockEsp.seed);
        assertEquals(1, mine.staffDetector.roster("play.example.net").size());
        assertEquals(7, mine.progressBar.basesFound);
    }

    @Test void savedConfigsCanBeListedReadAndDeleted() throws Exception {
        var store = new SharedConfigs(directory.resolve("donut-configs"));
        var entry = store.save("  PvP   setup  ", personalConfig());
        assertEquals("PvP setup", entry.name());
        store.save("PvP setup", new ClientConfig());
        assertEquals(1, store.list().size(), "Saving with the same name replaces the config");
        assertEquals(0, store.read(store.list().getFirst()).accentColor == 0x6C5CFF ? 0 : 1);
        assertThrows(java.io.IOException.class, () -> store.save("   ", new ClientConfig()));
        store.delete(store.list().getFirst());
        assertTrue(store.list().isEmpty());
    }

    @Test void damagedCodesAreRejected() {
        for (String bad : new String[] {"", "hello", SharedConfigs.CODE_PREFIX, SharedConfigs.CODE_PREFIX + "!!!!", SharedConfigs.CODE_PREFIX + "aGVsbG8"})
            assertThrows(java.io.IOException.class, () -> SharedConfigs.decode(bad), bad);
    }
}
