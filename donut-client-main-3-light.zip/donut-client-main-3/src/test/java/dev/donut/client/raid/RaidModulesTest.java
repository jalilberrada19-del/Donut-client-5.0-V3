package dev.donut.client.raid;

import dev.donut.client.config.RaidSettings.EntityGroup;
import net.minecraft.SharedConstants;
import net.minecraft.server.Bootstrap;
import net.minecraft.world.level.block.Blocks;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RaidModulesTest {
    @BeforeAll static void bootstrap() { SharedConstants.tryDetectVersion(); Bootstrap.bootStrap(); }

    @Test void blockEntitiesAreGroupedByTheirBlock() {
        assertEquals(EntityGroup.CHESTS, RaidModules.group(Blocks.CHEST.defaultBlockState()));
        assertEquals(EntityGroup.CHESTS, RaidModules.group(Blocks.BARREL.defaultBlockState()));
        assertEquals(EntityGroup.ENDER_CHESTS, RaidModules.group(Blocks.ENDER_CHEST.defaultBlockState()));
        assertEquals(EntityGroup.SHULKERS, RaidModules.group(Blocks.RED_SHULKER_BOX.defaultBlockState()));
        assertEquals(EntityGroup.FURNACES, RaidModules.group(Blocks.BLAST_FURNACE.defaultBlockState()));
        assertEquals(EntityGroup.HOPPERS, RaidModules.group(Blocks.HOPPER.defaultBlockState()));
        assertEquals(EntityGroup.DISPENSERS, RaidModules.group(Blocks.DROPPER.defaultBlockState()));
        assertEquals(EntityGroup.SPAWNERS, RaidModules.group(Blocks.SPAWNER.defaultBlockState()));
        assertEquals(EntityGroup.SPAWNERS, RaidModules.group(Blocks.TRIAL_SPAWNER.defaultBlockState()));
        assertEquals(EntityGroup.BEDS, RaidModules.group(Blocks.WHITE_BED.defaultBlockState()));
        assertEquals(EntityGroup.SIGNS, RaidModules.group(Blocks.OAK_SIGN.defaultBlockState()));
        assertEquals(EntityGroup.OTHER, RaidModules.group(Blocks.BEACON.defaultBlockState()));
    }

    @Test void ancientCityBlocksAndBiomeListAreRecognised() {
        assertTrue(RaidModules.isAncientCityBlock(Blocks.REINFORCED_DEEPSLATE.defaultBlockState()));
        assertTrue(RaidModules.isAncientCityBlock(Blocks.DEEPSLATE_TILES.defaultBlockState()));
        assertFalse(RaidModules.isAncientCityBlock(Blocks.COBBLED_DEEPSLATE.defaultBlockState()));
        var biomes = dev.donut.client.rtp.RtpBiomeFinder.allBiomes();
        assertTrue(biomes.contains("minecraft:plains") && biomes.contains("minecraft:cherry_grove") && biomes.size() > 50);
        assertFalse(dev.donut.client.rtp.RtpBiomeFinder.label("minecraft:cherry_grove").isBlank());
    }
}
