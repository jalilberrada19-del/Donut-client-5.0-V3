package dev.donut.client.config;

import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class RaidSettingsTest {
    @TempDir Path directory;

    @Test void freshAndOldConfigsGetSafeDefaults() throws Exception {
        Path file = directory.resolve("old.json");
        Files.writeString(file, "{\"unnaturalBlocks\":null,\"liveActivity\":{\"minLight\":99,\"keepSeconds\":1}}");
        var config = new ConfigStore(file).load();
        assertFalse(config.unnaturalBlocks.enabled || config.blockEntityEsp.enabled || config.spawnerNotifier.enabled
                || config.hiddenBase.enabled || config.liveActivity.enabled || config.chunkRefresh.enabled);
        assertEquals(RaidSettings.UnnaturalBlocks.DEFAULTS.size(), config.unnaturalBlocks.targets().size());
        assertEquals(15, config.liveActivity.minLight);
        assertEquals(10, config.liveActivity.keepSeconds);
        assertEquals(0, config.unnaturalBlocks.maxY);
    }

    @Test void unnaturalBlockListIsEditableAndPersists() {
        var store = new ConfigStore(directory.resolve("config.json"));
        var config = new ClientConfig();
        assertTrue(config.unnaturalBlocks.addTarget("cobblestone"));
        config.unnaturalBlocks.removeTarget("minecraft:glass");
        config.unnaturalBlocks.maxY = 999;
        store.save(config);
        var loaded = store.load().unnaturalBlocks;
        assertTrue(loaded.isEnabled("minecraft:cobblestone"));
        assertNull(loaded.find("minecraft:glass"));
        assertEquals(320, loaded.maxY);
        loaded.resetTargets();
        assertNotNull(loaded.find("minecraft:glass"));
        assertNull(loaded.find("minecraft:cobblestone"));
    }

    @Test void blockEntityFilterDefaultsAndDepths() {
        var esp = new RaidSettings.BlockEntityEsp();
        assertTrue(esp.groupEnabled(RaidSettings.EntityGroup.CHESTS));
        assertFalse(esp.groupEnabled(RaidSettings.EntityGroup.SIGNS), "Signs are noisy and start hidden");
        assertEquals(0, esp.depthCeiling(), "Default shows only what is below Y 0");
        esp.depth = "Everywhere";
        assertEquals(Integer.MAX_VALUE, esp.depthCeiling());
        esp.depth = "Below Y -20";
        assertEquals(-20, esp.depthCeiling());
        esp.depth = "nonsense";
        esp.sanitize();
        assertEquals("Below Y 0", esp.depth);
        esp.colors.put(RaidSettings.EntityGroup.HOPPERS.id(), 0xFF123456);
        assertEquals(0x123456, esp.groupColor(RaidSettings.EntityGroup.HOPPERS));
    }

    @Test void cobbledDeepslateAndRtpFinderSettingsAreSafe() {
        var cobbled = new RaidSettings.CobbledDeepslate();
        assertTrue(cobbled.variants && cobbled.ignoreAncientCities);
        cobbled.maxY = 9999; cobbled.radius = 0; cobbled.sanitize();
        assertEquals(320, cobbled.maxY);
        assertEquals(2, cobbled.radius);

        var rtp = new RaidSettings.RtpFinder();
        assertTrue(rtp.biomes.isEmpty(), "No biome is chosen for the user");
        assertTrue(rtp.addBiome("Cherry_Grove"));
        assertFalse(rtp.addBiome("minecraft:cherry_grove"), "Duplicate biome");
        assertFalse(rtp.addBiome("not a biome!"), "Malformed ID");
        rtp.command = "op "; rtp.cooldownSeconds = 0; rtp.maxAttempts = 0; rtp.sanitize();
        assertEquals("rtp", rtp.command, "Only the listed teleport commands can be sent");
        assertEquals(3, rtp.cooldownSeconds);
        assertEquals(1, rtp.maxAttempts);
        assertEquals(java.util.List.of("minecraft:cherry_grove"), rtp.biomes);
        assertTrue(new RaidSettings.UnnaturalBlocks().ignoreMineshafts);
    }

    @Test void playerEspDefaultsAndLimits() {
        var esp = new RaidSettings.PlayerEsp();
        assertFalse(esp.enabled);
        assertTrue(esp.tracers && esp.showList && esp.includeInvisible && esp.staffColor);
        esp.range = 5; esp.listRows = 99; esp.color = 0xFF123456; esp.sanitize();
        assertEquals(16, esp.range);
        assertEquals(12, esp.listRows);
        assertEquals(0x123456, esp.color);
    }
}
