package dev.donut.client.gametest;

import dev.donut.client.raid.RaidModules;
import dev.donut.client.staff.StaffDetectorController;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.gamerules.GameRules;

/** Single-player checks for the spectator, mineshaft-torch and cobbled-deepslate fixes. */
public final class RaidFixesGameTest implements FabricClientGameTest {
    private static final BlockPos LONE_TORCH = new BlockPos(4, -39, 4), MINESHAFT_TORCH = new BlockPos(11, -40, 4);
    private static final BlockPos COBBLED = new BlockPos(4, -40, 10), CITY_COBBLED = new BlockPos(41, -40, 41);

    @Override public void runTest(ClientGameTestContext context) {
        try (var world = context.worldBuilder().create()) {
            var server = world.getServer();
            server.runOnServer(mc -> mc.overworld().getGameRules().set(GameRules.SEND_COMMAND_FEEDBACK, false, mc));
            server.runCommand("gamemode creative @a");
            server.runOnServer(mc -> {
                var player = mc.getPlayerList().getPlayers().getFirst();
                player.getAbilities().flying = true; player.onUpdateAbilities();
            });
            server.runCommand("tp @a 8.5 -30 8.5");
            for (String command : new String[] {
                    "setblock 4 -40 4 minecraft:stone", "setblock 4 -39 4 minecraft:torch",
                    "setblock 10 -41 4 minecraft:stone", "setblock 10 -40 4 minecraft:oak_fence",
                    "setblock 11 -41 4 minecraft:stone", "setblock 11 -40 4 minecraft:torch",
                    "setblock 4 -40 10 minecraft:cobbled_deepslate",
                    "setblock 40 -40 40 minecraft:reinforced_deepslate", "setblock 41 -40 41 minecraft:cobbled_deepslate"})
                server.runCommand(command);
            context.waitTicks(10);

            // Unnatural Blocks and Cobbled Deepslate, through the production engine.
            var raid = context.computeOnClient(mc -> RaidModules.get());
            var config = raid.config();
            boolean unnaturalBefore = config.unnaturalBlocks.enabled, cobbledBefore = config.cobbledDeepslate.enabled;
            try {
                context.runOnClient(mc -> { config.unnaturalBlocks.enabled = true; config.cobbledDeepslate.enabled = true; });
                context.waitFor(mc -> marked(raid, COBBLED) && marked(raid, LONE_TORCH), 400);
                context.waitTicks(20);
                context.runOnClient(mc -> {
                    require(marked(raid, LONE_TORCH), "A lone underground torch was not flagged");
                    require(!marked(raid, MINESHAFT_TORCH), "A torch on a mineshaft support was flagged");
                    require(marked(raid, COBBLED), "Cobbled deepslate was not flagged");
                    require(!marked(raid, CITY_COBBLED), "Cobbled deepslate next to an ancient city was flagged");
                });
            } finally {
                context.runOnClient(mc -> { config.unnaturalBlocks.enabled = unnaturalBefore; config.cobbledDeepslate.enabled = cobbledBefore; });
            }

            // Staff Detector: in single-player, test mode sees your own spectator mode.
            var staff = context.computeOnClient(mc -> StaffDetectorController.get());
            var settings = staff.settings();
            boolean enabled = settings.enabled, any = settings.anySpectator, self = settings.watchSelf;
            try {
                context.runOnClient(mc -> { settings.enabled = true; settings.anySpectator = true; settings.watchSelf = true; });
                server.runCommand("gamemode spectator @a");
                context.waitFor(mc -> !staff.spectators().isEmpty(), 200);
                server.runCommand("gamemode creative @a");
                context.waitFor(mc -> staff.spectators().isEmpty(), 200);
                context.runOnClient(mc -> settings.watchSelf = false);
                server.runCommand("gamemode spectator @a");
                context.waitTicks(30);
                require(context.computeOnClient(mc -> staff.spectators().isEmpty()), "Without test mode you must not watch yourself");
            } finally {
                server.runCommand("gamemode creative @a");
                context.runOnClient(mc -> { settings.enabled = enabled; settings.anySpectator = any; settings.watchSelf = self; });
            }
        }
    }

    private static boolean marked(RaidModules raid, BlockPos pos) {
        return raid.markers().stream().anyMatch(marker -> marker.bounds().contains(pos.getCenter()));
    }

    private static void require(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
