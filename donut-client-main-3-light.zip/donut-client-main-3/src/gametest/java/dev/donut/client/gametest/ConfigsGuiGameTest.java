package dev.donut.client.gametest;

import dev.donut.client.config.ClientConfig;
import dev.donut.client.config.SharedConfigs;
import dev.donut.client.gui.DonutScreen;
import java.nio.file.Files;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.client.gametest.v1.screenshot.TestScreenshotOptions;
import net.fabricmc.loader.api.FabricLoader;

/** Save, share, import and load a config from the Configs page. */
public final class ConfigsGuiGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext context) {
        var folder = FabricLoader.getInstance().getConfigDir().resolve("donut-configs");
        var store = new SharedConfigs(folder);
        context.runOnClient(mc -> { try { for (var entry : store.list()) store.delete(entry); } catch (Exception error) { throw new AssertionError(error); } });
        var config = new ClientConfig();
        config.accentColor = 0x3DD68C;
        config.unnaturalBlocks.enabled = true;
        context.getInput().resizeWindow(1280, 800);
        context.runOnClient(mc -> { mc.options.guiScale().set(1); mc.resizeDisplay(); });
        try (var world = context.worldBuilder().create()) {
            GuiTestInput.openAnimated(context, () -> new DonutScreen(config, () -> { }));
            GuiTestInput.click(context, "tab8");
            GuiTestInput.click(context, "configName");
            GuiTestInput.type(context, "Green raid");
            GuiTestInput.click(context, "configSave");
            require(store.list().size() == 1 && store.list().getFirst().name().equals("Green raid"), "Config was not saved");

            // Share it, change the live settings, then import and load it back.
            GuiTestInput.click(context, "configCode0");
            String code = context.computeOnClient(mc -> mc.keyboardHandler.getClipboard());
            require(code.startsWith(SharedConfigs.CODE_PREFIX), "Code was not copied: " + code);
            context.runOnClient(mc -> { config.accentColor = 0xFF0000; config.unnaturalBlocks.enabled = false; });
            GuiTestInput.click(context, "configImport");
            require(store.list().size() == 2, "Imported code was not saved as a config");
            context.takeScreenshot(TestScreenshotOptions.of("configs-01-page").withSize(1280, 800));
            GuiTestInput.click(context, "configLoad0");
            require(config.accentColor == 0x3DD68C && config.unnaturalBlocks.enabled, "Loading did not apply the config");

            // Deleting needs a second click.
            GuiTestInput.click(context, "configDelete0");
            require(store.list().size() == 2, "Delete did not ask for confirmation");
            GuiTestInput.click(context, "configDelete0");
            require(store.list().size() == 1, "Confirmed delete did not remove the config");
            GuiTestInput.closeAnimated(context);
        } finally {
            context.runOnClient(mc -> { mc.options.guiScale().set(0); mc.resizeDisplay(); });
            try { for (var entry : store.list()) store.delete(entry); Files.deleteIfExists(folder); } catch (Exception ignored) { }
        }
    }

    private static void require(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
