package dev.donut.client.gametest;

import dev.donut.client.config.ClientConfig;
import dev.donut.client.gui.DonutScreen;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.client.gametest.v1.screenshot.TestScreenshotOptions;

/** Several biomes can be picked and unpicked from the RTP Biome Finder grid. */
public final class RtpGuiGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext context) {
        var config = new ClientConfig();
        context.getInput().resizeWindow(1280, 800);
        context.runOnClient(mc -> { mc.options.guiScale().set(1); mc.resizeDisplay(); });
        try (var world = context.worldBuilder().create()) {
            GuiTestInput.openAnimated(context, () -> new DonutScreen(config, () -> { }));
            context.takeScreenshot(TestScreenshotOptions.of("gui-01-all-modules").withSize(1280, 800));
            GuiTestInput.click(context, "search"); GuiTestInput.type(context, "rtp");
            GuiTestInput.click(context, "module22");
            GuiTestInput.click(context, "m22.biome.plains");
            GuiTestInput.click(context, "m22.biome.cherry_grove");
            GuiTestInput.click(context, "m22.biome.mushroom_fields");
            require(config.rtpFinder.biomes.containsAll(java.util.List.of("minecraft:plains", "minecraft:cherry_grove", "minecraft:mushroom_fields")),
                    "Several biomes could not be selected: " + config.rtpFinder.biomes);
            GuiTestInput.click(context, "m22.biome.plains");
            require(!config.rtpFinder.biomes.contains("minecraft:plains") && config.rtpFinder.biomes.size() == 2,
                    "Clicking a selected biome did not unselect it: " + config.rtpFinder.biomes);
            context.takeScreenshot(TestScreenshotOptions.of("gui-02-rtp-biomes").withSize(1280, 800));
            GuiTestInput.click(context, "m22.biomeClear");
            require(config.rtpFinder.biomes.isEmpty(), "Clear all did not clear the biomes");
            GuiTestInput.closeAnimated(context);
        } finally {
            context.runOnClient(mc -> { mc.options.guiScale().set(0); mc.resizeDisplay(); });
        }
    }

    private static void require(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
