# Donut Client 5.0

A **vibecoded** client-side Fabric mod for **Minecraft 1.21.11** with visual tools, movement modules, schematic building and streaming overlays.

Base Raid and Donut modules (Unnatural Blocks, Block Entity ESP, Spawner Notifier, Hidden Base Detector, Live Activity, Chunk Refresh) are described in [Base Raid](docs/base-raid.md).

BlockESP uses the world seed to predict where any chosen block was generated (defaults: deepslate coal, deepslate emerald, ancient debris). See [BlockESP](docs/blockesp.md).

Download the built JAR from [Releases](https://github.com/NotRaindoots/donut-client/releases/latest). Requires Java 21+, Fabric Loader 0.18.4+ and Fabric API 0.141.4+1.21.11. To build from source, run `./gradlew build` (`gradlew.bat build` on Windows).

## License and credits

Original Donut code retains its [MIT notice](LICENSE). Spectre ports by **4ldenz** are **GPL-3.0-only**; Name Hider code is **CC0-1.0**; Geist and Inter fonts are **OFL-1.1**. See the [component notices](src/main/resources/licenses/) and [Inter font notice](src/main/resources/assets/donut/font/ofl.txt).
